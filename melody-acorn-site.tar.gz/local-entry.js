function contactAuthor() {
  const modal = document.querySelector('#modal');
  modal.innerHTML = `
    <h2>联系我</h2>
    <p>感谢您的使用～<br>有建议或其他合作可以联系我～</p>
    <p>邮箱：<a href="mailto:dajing4269@163.com">dajing4269@163.com</a><br>微信：dajing4269</p>
    <p>祝您能在这里留下美好的音乐回忆～</p>
    <form method="dialog"><button>关闭</button></form>
  `;
  modal.showModal();
}

function chooseChapter() {
  const modal = document.querySelector('#modal');
  modal.innerHTML = '<h2>自由选关</h2><p>选择一关，从上次保存的位置开始。</p>';
  CHAPTER_KEYS.slice(1).forEach((key, index) => {
    const level = index + 1;
    const button = document.createElement('button');
    button.textContent = '第 ' + level + ' 关 · ' + CHAPTER_TITLES[level];
    button.onclick = () => { modal.close(); startChapter(level); };
    modal.append(button);
  });
  modal.insertAdjacentHTML('beforeend', '<form method="dialog"><button>返回</button></form>');
  modal.showModal();
}

if (location.hash === '#choose-chapter') {
  window.addEventListener('load', () => { home(); chooseChapter(); }, {once: true});
}
