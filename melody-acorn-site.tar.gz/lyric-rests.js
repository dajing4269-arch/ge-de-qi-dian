/* Independent lyric-timeline gaps: never shorten or subdivide a sung note. */
function lyricGapParts(line,i){return line.melody?.[i]||[{d:line.durations[i]??(getRhythmPreference(project())==='regular'?regularDefaults(line,project())[i]:boundedLesson()?.5:1),p:line.pitches[i],staccato:!!line.staccato?.[i]}];}
function lyricGapChoices(line,p,replacing=0){
 const choices=[.25,.5,1,1.5,2,3,4];
 if(getRhythmPreference(p)!=='regular')return choices;
 const used=regularDefaults(line,p).reduce((total,d,i)=>total+d+(line.restsAfter?.[i]||0),0);
 return choices.filter(d=>used-replacing+d<=regularBudget(p)+1e-8);
}
function lyricGapIndex(line,i){return lyricGapParts(line,i).length;}
function openLyricGapMenu(li,i){
 const p=project(),l=p.lines[li],m=$('#modal'),current=l.restsAfter?.[i]||0,choices=lyricGapChoices(l,p,current);if(!restsEnabled(p))return;
 m.innerHTML=`<h2>在「${esc(lyricUnits(l.text)[i])}」后${current?'调整':'加入'}休止符</h2><p>休止符就是无声的空白音符。</p><p class="hint">在这个字后加一段空拍，后面的歌词顺延。原来的音符和时长保持不变。</p><button id="previewOriginalRest">▶ 原来的唱法</button><div class="choices rest-choices">${!choices.length?'<p>这句已排满，先缩短一个字再加空拍。</p>':''}${choices.map((d,j)=>`<div class="choice">${restOptionSVG(0,d)}<div>空${beatLabel(d)}</div><div class="option-actions"><button data-gap-preview="${j}">▶ 试听</button><button data-gap-use="${j}" class="primary">${current===d?'当前空拍':'空'+beatLabel(d)}</button></div></div>`).join('')}</div><div class="actions">${current?'<button id="removeLyricGap">删除这段空拍</button>':''}<button id="closeRestMenu">返回乐谱</button></div>`;
 const preview=d=>{const parts=clone(lyricGapParts(l,i));if(d)parts.push({d,p:null,rest:true});if(i+1<lyricUnits(l.text).length)parts.push(...clone(lyricGapParts(l,i+1)));playEvents(restPreviewEvents(parts));};
 $('#previewOriginalRest').onclick=()=>preview(0);
 $$('[data-gap-preview]').forEach(b=>b.onclick=()=>preview(choices[+b.dataset.gapPreview]));
 $$('[data-gap-use]').forEach(b=>b.onclick=()=>{mutate(()=>{l.restsAfter??={};l.restsAfter[i]=choices[+b.dataset.gapUse];});closeRestEdit({li,i,si:lyricGapIndex(l,i)});});
 if(current)$('#removeLyricGap').onclick=()=>{mutate(()=>delete l.restsAfter[i]);closeRestEdit();};
 $('#closeRestMenu').onclick=()=>{stop();m.close();};if(!m.open)m.showModal();
}
function installLyricRests(){
 const oldEvents=lineEvents,oldBeats=lineBeats,oldParts=restParts,oldHas=hasWrittenRest,oldRemove=removeWrittenRest,oldMenu=openRestMenu,oldSVG=engravingSVG,oldValid=validStudioData,oldCopy=copyPhraseData,oldGuide=restLessonGuideHTML;
 lineEvents=function(l){const events=oldEvents(l),out=[];let offset=0;events.forEach((e,k)=>{out.push({...e,t:e.t+offset});if(events[k+1]?.i!==e.i&&l.restsAfter?.[e.i]){const d=l.restsAfter[e.i];out.push({t:e.t+e.d+offset,d,p:null,i:e.i,si:lyricGapIndex(l,e.i),rest:true,addedGap:true,assigned:true,syllableFirst:false});offset+=d;}});return out.map((e,k)=>({...e,followedByRest:out[k+1]?.rest===true}));};
 lineBeats=function(l,p=project()){if(getRhythmPreference(p)==='regular')return regularBudget(p);const actual=l.durations.reduce((sum,d,i)=>sum+(l.melody?.[i]?.reduce((s,n)=>s+n.d,0)??d??(boundedLesson(p)?.5:1))+(l.restsAfter?.[i]||0),0);const needed=Math.max(1,Math.ceil((actual-1e-9)/barBeats(p)))*barBeats(p);return needed;};
 restParts=function(li,i,p=project()){const parts=oldParts(li,i,p),gap=p.lines[li]?.restsAfter?.[i];return gap?[...parts,{d:gap,p:null,rest:true,addedGap:true}]:parts;};
 hasWrittenRest=p=>{p??=project();return oldHas(p)||p.lines.some(l=>Object.values(l.restsAfter||{}).some(d=>d>0));};
 restOptions=function(li,i,si=0,p=project()){return restsEnabled(p)&&p.lines[li]&&i>=0&&i<lyricUnits(p.lines[li].text).length?lyricGapChoices(p.lines[li],p):[];};
 insertRestAfter=function(li,i,si,d,p=project()){if(!restOptions(li,i,si,p).includes(d))return false;const l=p.lines[li];l.restsAfter??={};l.restsAfter[i]=(l.restsAfter[i]||0)+d;return true;};
 removeWrittenRest=function(li,i,si,p=project()){if(si===lyricGapIndex(p.lines[li],i)&&p.lines[li].restsAfter?.[i]){delete p.lines[li].restsAfter[i];return true;}return oldRemove(li,i,si,p);};
 openLyricRestMenu=openLyricGapMenu;
 openRestMenu=function(li,i,si=0){return si===lyricGapIndex(project().lines[li],i)&&project().lines[li].restsAfter?.[i]?openLyricGapMenu(li,i):oldMenu(li,i,si);};
 restLessonGuideHTML=function(){return oldGuide().replace('点击休止符可以恢复发声。','点击空拍可以调整时长或删除。');};
 validStudioData=function(p){return oldValid(p)&&p.lines.every(l=>!l.restsAfter||Object.entries(l.restsAfter).every(([i,d])=>Number.isInteger(+i)&&+i>=0&&+i<lyricUnits(l.text).length&&Number.isFinite(d)&&d>=.25&&d<=64&&d*4%1===0));};
 copyPhraseData=function(from,to){oldCopy(from,to);to.restsAfter={};for(const [i,d] of Object.entries(from.restsAfter||{}))if(+i<lyricUnits(to.text).length)to.restsAfter[i]=d;};
 engravingSVG=function(row,mode='combined',editable=true){let svg=oldSVG(row,mode,editable);if(mode!=='combined')return svg;let extra='';for(const n of row.measures.flatMap(m=>m.notes)){if(!n.addedGap)continue;const active=editable?`class="user-rest lyric-gap" role="button" tabindex="0" data-li="${n.li}" data-i="${n.i}" data-si="${n.si}"`:'';extra+=`<g ${active} aria-label="歌词节奏中的空拍" color="#657653"><rect x="${n.x-19}" y="9" width="38" height="65" rx="8" fill="#f4eddb"/>${glyph(n.d>=4?'restWhole':n.d>=2?'restHalf':n.d>=1?'restQuarter':n.d>=.5?'rest8':'rest16',n.x-5,43)}${dot(n.d,n.x+5,43)}</g>`;}return svg.replace('</g></svg>',extra+'</g></svg>');};
}
