(() => {
 const app = document.querySelector('#app');
 const quiet = matchMedia('(prefers-reduced-motion: reduce)');
 const studioArt = ['assets/studio-headings/kite.png', 'assets/studio-headings/dragonfly.png', 'assets/studio-headings/squirrel.png'];
 let lastArt = '';
 let composingKey = null;
 let previous;
 function sync() {
   const page = db.view;
   const p = project();
   const mode = page === 'home' ? '' : page === 'advanced-review' || p?.advancedReview != null && page === 'editor' ? 'advanced' : page === 'library' || p?.level === 0 && page === 'editor' ? 'studio' : 'journey';
   if (mode) document.body.dataset.paper = mode;
   else delete document.body.dataset.paper;
   const composing = mode === 'studio' && page === 'editor' && app.querySelector('.studio-score');
   if (composing && composingKey !== db.active) {
     const choices = studioArt.filter(path => path !== lastArt);
     lastArt = choices[Math.floor(Math.random() * choices.length)];
     app.style.setProperty('--studio-heading-art', 'url("' + lastArt + '")');
   }
   composingKey = composing ? db.active : null;
   const next = [page,db.active,page === 'editor' ? p?.step : db.coverLevel].join('/');
   if (previous && previous !== next && !quiet.matches) {
     const entry = mode === 'studio' ? 'translate(8px,3px)' : mode === 'advanced' ? 'translateY(-6px)' : 'translateY(7px)';
     app.animate([{opacity:.7,transform:entry},{opacity:1,transform:'none'}],{duration:220,easing:'ease-out'});
   }
   previous = next;
 }
 new MutationObserver(sync).observe(app,{childList:true,subtree:true});
 sync();
 document.addEventListener('click', event => {
   const b = event.target.closest('button');
   if (!b || b.disabled || quiet.matches) return;
   if (b.matches('#playAll,[data-rhythm-line],[data-play]')) b.animate([{boxShadow:'0 0 0 0 #52735780'},{boxShadow:'0 0 0 8px transparent'}],260);
   else if (b.matches('#backup,#undo,#redo,.step')) b.animate([{filter:'brightness(.84)'},{filter:'brightness(1)'}],180);
 },true);
})();
