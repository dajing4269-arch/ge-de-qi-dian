const interfaceClips = new Map();
for (const name of ['dong', 'dada']) {
  const clip = new Audio();
  clip.preload = 'auto';
  clip.src = 'assets/ui-sounds/' + name + '.mp3';
  interfaceClips.set(name, clip);
}

let activeInterfaceClip = null;

function stopInterfaceSound() {
  if (!activeInterfaceClip) return;
  activeInterfaceClip.pause();
  if (activeInterfaceClip.currentTime > 0) activeInterfaceClip.currentTime = 0;
  activeInterfaceClip = null;
}

function playInterfaceSound(name) {
  const clip = interfaceClips.get(name);
  if (!clip) return;
  stopInterfaceSound();
  activeInterfaceClip = clip;
  // Starting inside the original tap keeps playback available on mobile browsers.
  clip.play().catch(() => {});
}

window.addEventListener('pagehide', stopInterfaceSound);

// Only navigation and interface commands get a click sound. New score controls stay silent.
(() => {
  const pageNavigation = [
    'header .brand', 'header .brand-signature', '#journey', '#studio', '#back', '#libraryBack',
    '#continue', '#chooseChapter', '.chapter-options button', '#restartJourney',
    '#currentChapter', '#previousLevel', '#nextLevel', '#returnTwo',
    '#coverHome', '#coverCurrent', '#coverPrevious', '#coverNext', '#coverBegin',
    '#homeStudio', '#homeNew', '#newSong', '#create', 'button[data-song]',
  ].join(',');

  const interfaceCommands = [
    // Settings, help, song management, and exports.
    'button[data-home-control]', 'button[data-lang]', '#openGuide', '#contact', '#import',
    '#aboutSongOrigin', '#closeSongAbout', 'button[data-guide-tab]', '#closeOperationGuide',
    '#modal form[method="dialog"] button', '#cancel', '#cancelImport', '#confirmImport',
    '#rewriteWork', '#backup', '#oldRhythm', '#restoreJourney', 'button[data-export]',
    'button[data-delete-song]', 'button[data-restore-song]', '#cancelDeleteSong', '#confirmDeleteSong',
    // Steps within an open song use the lighter sound, including the mirrored toolbar.
    'button[data-step]', '#topPreviousStep', '#topNextStep', '#previousStep', '#prev', '#next',
    '#sentenceBack', '#sentenceNext', '#taskBack', '#taskNext', '#creditBack', '#creditNext',
    '#editAgain', 'button[data-sentence-phase]', 'button[data-section-compose-stage]',
    'button[data-pair-tape-done]',
  ].join(',');

  document.addEventListener('click', event => {
    // The top step buttons and home menu forward their action with .click().
    // A trusted click also covers keyboard activation without playing the forwarded click twice.
    if (!event.isTrusted) return;
    const control = event.target.closest?.('button, a');
    if (!control || control.matches(':disabled, [aria-disabled="true"]')) return;
    if (control.matches(pageNavigation)) playInterfaceSound('dong');
    else if (control.matches(interfaceCommands)) playInterfaceSound('dada');
  }, true);
})();
