/* Uncompressed MusicXML 4.0, retaining the editable notes and lyric underlay. */
function musicXML(p=project()){
 const xml=s=>esc(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,''),measures=measureModel(p),[beats,unit]=meterParts(p),fifths=Math.max(-7,Math.min(7,keySignatureFifths(p)));
 const key=`<key><fifths>${fifths}</fifths></key>`;
 const systemStarts=new Set(systemModel(p).map(r=>r.measures[0].number));
 const starts=new Set(),stops=new Set();
 for(const run of phraseSlurRuns(measures.flatMap(m=>m.notes).filter(n=>n.p!==null))){
  starts.add(run[0]);stops.add(run.at(-1));
 }
 let out=`<?xml version="1.0" encoding="UTF-8"?>\n<score-partwise version="4.0"><work><work-title>${xml(p.title)}</work-title></work><movement-title>${xml(p.title)}</movement-title><identification><creator type="composer">${xml(p.composer||'未署名')}</creator><creator type="lyricist">${xml(p.lyricist||'未署名')}</creator><encoding><software>歌的起点</software></encoding></identification><part-list><score-part id="P1"><part-name>旋律</part-name><score-instrument id="I1"><instrument-name>${xiaoMode(p)?'洞箫':'钢琴'}</instrument-name></score-instrument><midi-instrument id="I1"><midi-channel>1</midi-channel><midi-program>${xiaoMode(p)?78:1}</midi-program></midi-instrument></score-part></part-list><part id="P1">`;
 measures.forEach((m,mi)=>{
 out+=`<measure number="${m.pickup?0:mi+(p.pickupBeats?0:1)}"${m.incomplete?' implicit="yes"':''}>`;if(mi&&systemStarts.has(m.number))out+='<print new-system="yes"/>';
 if(!mi)out+=`<attributes><divisions>12</divisions>${key}<time><beats>${beats}</beats><beat-type>${unit}</beat-type></time><clef><sign>G</sign><line>2</line></clef></attributes><direction placement="above"><direction-type><metronome><beat-unit>quarter</beat-unit><per-minute>${p.bpm}</per-minute></metronome></direction-type><sound tempo="${p.bpm}"/></direction>`;
 const tuplets=new Map();
 const beams=new Map();beamGroups(m.notes).forEach(group=>{
  if(group.some(n=>n.p===null))return;
  if(eighthTriplet(group)){tuplets.set(group[0],'start');tuplets.set(group[2],'stop');}
  group.forEach((n,i)=>{
   let markup=`<beam number="1">${i===0?'begin':i===group.length-1?'end':'continue'}</beam>`;
   if(n.d<=.25){const before=i>0&&group[i-1].d<=.25,after=i+1<group.length&&group[i+1].d<=.25;
    markup+=`<beam number="2">${before?(after?'continue':'end'):after?'begin':i===0?'forward hook':'backward hook'}</beam>`;
   }
   beams.set(n,markup);
  });
 });
 m.notes.forEach(n=>{
 const rest=n.rest||n.p===null,pitch=n.p,written=writtenNoteDuration(n.d),type=written>=4?'whole':written>=2?'half':written>=1?'quarter':written>=.5?'eighth':written>=.25?'16th':'32nd',dotted=[3,1.5,.75].includes(n.d);
 out+='<note>';
 if(rest)out+='<rest/>';else{const natural=12*(Math.floor(pitch/7)+1)+SEMI[pitch%7],alter=n.alter??(studioMidi(pitch,p)-natural);out+=`<pitch><step>${NAMES[pitch%7]}</step>${alter?`<alter>${alter}</alter>`:''}<octave>${Math.floor(pitch/7)}</octave></pitch>`;}
 out+=`<duration>${Math.round(n.d*12)}</duration>`;
 if(!rest){if(!n.first)out+='<tie type="stop"/>';if(!n.last)out+='<tie type="start"/>';}
 out+=`<type>${type}</type>${dotted?'<dot/>':''}${!rest&&n.explicitAccidental?'<accidental>'+({1:'sharp',0:'natural','-1':'flat'}[n.alter])+'</accidental>':''}${written!==n.d?'<time-modification><actual-notes>3</actual-notes><normal-notes>2</normal-notes></time-modification>':''}${!rest?beams.get(n)||'':''}`;
 if(!rest){const notations=[];if(tuplets.has(n))notations.push(`<tuplet type="${tuplets.get(n)}" bracket="no"/>`);if(!n.first)notations.push('<tied type="stop"/>');if(!n.last)notations.push('<tied type="start"/>');if(starts.has(n))notations.push('<slur type="start" number="1"/>');if(stops.has(n))notations.push('<slur type="stop" number="1"/>');if(n.staccato&&n.first)notations.push('<articulations><staccato/></articulations>');if(notations.length)out+='<notations>'+notations.join('')+'</notations>';
 const l=p.lines[n.li],parts=melodyEnabled(p)?l.melody?.[n.i]:null,endOfSyllable=n.last&&(n.si??0)===(parts?parts.findLastIndex(v=>!v.rest):0),begin=n.first&&n.syllableFirst!==false;
 if(begin)out+=`<lyric number="1"><syllabic>${lyricSyllabic(l.text,n.i)}</syllabic><text>${xml(lyricUnits(l.text)[n.i])}</text>${!endOfSyllable?'<extend type="start"/>':''}</lyric>`;
 else out+=`<lyric number="1"><extend type="${endOfSyllable?'stop':'continue'}"/></lyric>`;
 }
 out+='</note>';
 });
 if(mi===measures.length-1)out+='<barline location="right"><bar-style>light-heavy</bar-style></barline>';out+='</measure>';
 });return out+'</part></score-partwise>';
}
function exportMusicXML(){download(new Blob([musicXML()],{type:'application/vnd.recordare.musicxml+xml;charset=utf-8'}),project().title+'.musicxml');toast('MusicXML 乐谱已下载，可在其他制谱软件中继续编辑');}
