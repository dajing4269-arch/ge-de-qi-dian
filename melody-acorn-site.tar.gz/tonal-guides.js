/* Optional opening-tone suggestions; never used by composition validation. */
function tonalGuideKind(p=project()){return [16,17,18,19].includes(p.level)?'tonic':[20,21,22,26,27].includes(p.level)?'chord':null;}
function tonalGuideDegrees(p=project()){const degrees=modeDegrees(p);return tonalGuideKind(p)==='chord'?[degrees[0],degrees[2],degrees[4]]:[0];}
function tonalGuidePitches(p=project()){
 const root=STUDIO_TONICS[p.tonic||'C'][0],degrees=tonalGuideDegrees(p);
 return Array.from({length:19},(_,i)=>25+i).filter(pitch=>degrees.includes(((pitch-root)%7+7)%7));
}
function tonicChordDiagram(p=project()){
 const notes=scalePitches(p),signature=keySignatureEntries(p),key=studioKeyAccidentals(p);let cursor=85+signature.length*17;
 const layout=notes.map(pitch=>{const alter=scorePitchAlter(pitch,p);if(alter!==(key.get(pitch%7)||0))cursor+=MUSIC_GLYPHS[scaleAccidentalName(alter)].width+5;const x=cursor;cursor+=38;return {pitch,x};});
 const targets=[layout[0],layout[2],layout[4]],cx=targets[1].x;
 let svg=studioScaleSVG(p).replace(/viewBox="0 55 ([\d.]+) 215"/,'viewBox="0 55 $1 365"');
 let extra='<g class="tonic-chord-diagram" color="#64755c">';
 for(let y=310;y<=358;y+=12)extra+=`<path d="M15 ${y}H${cx+18}" stroke="#a4af9a"/>`;
 extra+=`<g transform="translate(0 180)">${glyph('clef',28,scaleNoteY(32))+scaleKeySignatureSVG(p)}</g>`;
 targets.forEach(({pitch,x},i)=>{
  const y=scaleNoteY(pitch)+180;
  const lane=cx+64+i*24,turnY=294-i*10,tip=cx+25;
  extra+=`<text x="${x}" y="267" text-anchor="middle" font-size="13">第${[1,3,5][i]}音</text><path class="chord-elbow-arrow" d="M${x} 274 V${turnY-4} Q${x} ${turnY} ${x+4} ${turnY} H${lane-5} Q${lane} ${turnY} ${lane} ${turnY+5} V${y-5} Q${lane} ${y} ${lane-5} ${y} H${tip} m6 -4 l-6 4 6 4" fill="none" stroke="#9daa92" stroke-width="1.2" stroke-linejoin="round"/>`;
  for(let ly=370;ly<=y;ly+=12)extra+=`<path d="M${cx-14} ${ly}h28" stroke="currentColor"/>`;
  extra+=glyph('whole',cx-MUSIC_GLYPHS.whole.width/2,y);
  const alter=scorePitchAlter(pitch,p);if(alter!==(key.get(pitch%7)||0))extra+=glyph(scaleAccidentalName(alter),cx-30,y);
 });
 extra+=`<text x="${cx}" y="410" text-anchor="middle" font-size="14">主和弦</text></g>`;
 return svg.replace('</svg>',extra+'</svg>');
}
function installTonalGuides(){
 const oldMode=renderCurriculumMode,oldNineteen=renderNineteenMode,oldDorian=renderDorianMode,oldSVG=engravingSVG;
 function annotateMode(){
  const p=project(),kind=tonalGuideKind(p);if(!kind)return;
  if(kind==='tonic'){
   const label=document.querySelector('#stage .mode-fields label');if(!label)return;
   label.classList.add('tonic-choice-target');const hint=document.createElement('p');hint.className='tonic-choice-explanation';hint.textContent='这个位置选择的是作品的“主音”，选择后它就是作品里最重要的音，指明了音乐的方向。多使用“主音”，作品的调就会更明确。';label.append(hint);
  }else if(p.level===20){
   const panel=document.querySelector('#stage .score-scroll');if(!panel)return;
   panel.innerHTML=tonicChordDiagram(p);const hint=document.createElement('p');hint.className='hint tonic-chord-explanation';hint.textContent='调式音阶的第1、3、5个音构成调式的“主和弦”，多使用主和弦的音也可以让调式更清晰。';panel.before(hint);
  }
 }
 renderCurriculumMode=function(){oldMode();annotateMode();};
 renderNineteenMode=function(){oldNineteen();annotateMode();};
 renderDorianMode=function(){oldDorian();annotateMode();};
 engravingSVG=function(row,mode='combined',editable=true){
  let svg=oldSVG(row,mode,editable);const p=project(),kind=tonalGuideKind(p);if(!kind||!editable||mode!=='combined')return svg;
  const starts=new Set(sectionRanges(p).map(lines=>lines[0]));let marks='';
  for(const m of row.measures){
   if(!starts.has(m.li)||!m.notes.some(n=>n.i===0&&n.first&&n.local===0))continue;
   const x=m.notes.find(n=>n.i===0&&n.first).x;
   marks+=`<g class="section-opening-guide" data-li="${m.li}" pointer-events="none" color="#a7aea4" opacity=".58">`;
   for(const pitch of tonalGuidePitches(p)){
    const y=noteY(pitch);for(let ly=210;ly<=y;ly+=12)marks+=`<path d="M${x-13} ${ly}h26" stroke="currentColor"/>`;for(let ly=138;ly>=y;ly-=12)marks+=`<path d="M${x-13} ${ly}h26" stroke="currentColor"/>`;
    marks+=`<g data-guide-pitch="${pitch}">${head(4,x,y)}</g>`;
   }
   marks+='</g>';
   const text=kind==='tonic'?'主音':'主和弦音',tx=m.x+8;
   marks+=`<text class="section-opening-hint" x="${tx}" y="91" font-size="11" fill="#899181" pointer-events="none"><tspan x="${tx}">重拍多使用调里的${text}</tspan><tspan x="${tx}" dy="15">可以加强调式的感觉哦（不强制选择）～</tspan></text>`;
  }
  // Behind actual notes, leaving click/drag targets intact.
  return svg.replace(/(<g font-family="[^"]+" color="#263e35">)/, '$1'+marks);
 };
}
