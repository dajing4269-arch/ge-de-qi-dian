/* Lessons 16–23. Times remain in quarter-note units, including 6/8 and pickups. */
const LATER_LESSONS={
 16:{title:'渡口',author:'Chat gpt',lines:['芦花轻轻过渡口','一篙秋水向东流','旧船靠在青石岸','晚风吹过谁衣袖','我把心事交明月','月光陪我慢慢走'],sections:[0,0,0,1,1,1]},
 17:{title:'夜行',author:'Chat gpt',lines:['晚风翻过旧围墙','路灯点亮小街巷','有人推窗听夜雨','有人收伞望月光','我把脚步轻轻放','走过长街到天亮'],sections:[0,0,0,1,1,1]},
 18:{title:'海风',author:'Chat gpt',lines:['海风推着小船摇','白帆追着浪花跑','一片云从肩上过','几声鸥鸣落树梢','我把心愿轻轻抛','明天随潮慢慢到'],sections:[0,0,0,1,1,1]},
 19:{title:'卜算子·送鲍浩然之浙东',author:'王观',lines:['水是眼波横','山是眉峰聚','欲问行人去那边','眉眼盈盈处','才始送春归','又送君归去','若到江南赶上春','千万和春住'],punctuation:['，','。','？','。','，','。','，','。']},
 20:{title:'远灯',author:'Chat gpt',lines:['远灯亮在小桥旁','晚风送来饭菜香','一条归路穿过巷','半扇窗里有月光','这些年走过四方','也曾追着风流浪','如今坐在老门旁','听你说起旧时光'],sections:[0,0,0,0,1,1,1,1]},
 21:{title:'山海来信',author:'Chat gpt',lines:['风吹过山岗','掠过屋后那道旧围墙','我把思念写在信纸上','寄向有你的远方','潮涌进海港','漫过船边那片碎月光','你把风景画在信纸上','寄回等你的故乡'],sections:[0,0,0,0,1,1,1,1],defaultSections:true},
 22:{title:'如梦令·常记溪亭日暮',author:'李清照',lines:['常记溪亭日暮','沉醉不知归路','兴尽晚回舟','误入藕花深处','争渡争渡','惊起一滩鸥鹭'],punctuation:['，','。','，','。','，','。']},
 23:{title:'趁风出发',author:'Chat gpt',lines:['趁风吹过旧街巷','背起行囊向远方','晨光落在我肩上','脚步追着云影晃','还未开口先向往','一路把心事轻唱','等到晚霞铺满江','再将故事慢慢讲'],sections:[0,0,0,0,1,1,1,1]}
 ,24:{title:'A Different Sky',author:'Chat gpt',lines:['Morning light across the bay','Little boats drift far away','I can hear the ocean call','Like a song beyond the wall','Evening stars above the bay','Silver waves now lead the way','Let me hear a different call','Let one note surprise us all'],sections:[0,0,0,0,1,1,1,1],defaultSections:true}
 ,25:{title:'转角的风',author:'Chat gpt',lines:['风穿过小巷','吹开窗边半页旧时光','我把寻常的日子轻轻唱','转个弯又见晴朗','灯照着长廊','映出墙上摇晃的月亮','你把未完的心事慢慢讲','换个音也像远方'],sections:[0,0,0,0,1,1,1,1],defaultSections:true}
 ,26:{title:'夜窗',author:'Chat gpt',lines:['雨停在窗外','一盏灯还陪着我等待','远处的脚步穿过青石街','像谁披着月色归来','风停在门外','一封信还留着旧对白','昨日的笑声绕过旧楼台','等我轻轻把门打开'],sections:[0,0,0,0,1,1,1,1],defaultSections:true}
 ,27:{title:'回声',author:'Chat gpt',lines:['走过旧长街','晚风翻动昨日那一页','有句话到了嘴边又停歇','留给窗前一轮明月','回到旧长街','灯光照亮未写那一页','有首歌唱到这里轻轻歇','等你接起下一轮明月'],sections:[0,0,0,0,1,1,1,1],defaultSections:true}
 ,28:{"title": "饮酒·其五", "author": "陶渊明", "lines": ["结庐在人境", "而无车马喧", "问君何能尔", "心远地自偏", "采菊东篱下", "悠然见南山", "山气日夕佳", "飞鸟相与还", "此中有真意", "欲辨已忘言"]}
 ,29:{"title": "The Road Back Home", "author": "Chat gpt", "lines": ["We leave the town before the light", "And watch the hills turn gold and white", "Your laughter warms the morning air", "I turn and find you standing there", "We cross the bridge above the stream", "The water shines as in a dream", "You hum a song I used to know", "And let the quiet river flow", "When evening brings the stars in sight", "We take the road of silver light", "No matter where our footsteps roam", "Your voice will always lead me home"]}
 ,30:{"title": "把远方唱给你听", "author": "Chat gpt", "lines": ["风吹过山冈", "把旧日名字轻轻摇晃", "我沿着河流走过了村庄", "听见你把往事唱", "雨落在船窗", "把一路灯火慢慢拉长", "我捧着来信望向了远方", "想起你笑的模样", "月升在身旁", "把归途照得明明亮亮", "我带着故事回到了家乡", "等你来听这一场"]}
};
function laterLesson(p=project()){return p.level>=16&&p.level<=30;}
const NINETEEN_MODE='宫调式（六声·加变宫）';
function applyNineteenMode(p){
 if(!p||p.level!==19)return;
 // Keep saved notes intact. Old F notes remain visible for the player to adjust.
 p.tonic='C';p.scale=NINETEEN_MODE;p.mode='C '+modeDisplayName(NINETEEN_MODE);
}
function nineteenModeIssue(li,p=project()){
 if(p.level!==19)return '';
 const l=p.lines[li];if(!l)return '';
 const index=l.pitches.findIndex((pitch,i)=>{
  const parts=l.melody?.[i]||[{p:pitch}];
  return parts.some(n=>!n.rest&&n.p!==null&&n.p!==undefined&&((n.p%7)+7)%7===3);
 });
 return index<0?'':`「${lyricUnits(l.text)[index]}」的 F 音不在这次的调式中，请调整为 C、D、E、G、A、B 中的音。`;
}
function syncNineteenGate(){
 const p=project();if(p?.level!==19||!['pair','review'].includes(advancedStep(p)?.kind)||!$('#next'))return;
 const ids=advancedStep(p).lines||p.lines.map((_,i)=>i);$('#next').disabled=ids.some(li=>!!sentenceError(li));
}
function renderNineteenMode(){
 const p=project();applyNineteenMode(p);
 $('#stage').innerHTML=heading('选择调式','给五声音阶添一个 B 音','')+`<div class="mode-fields"><label>主音<select disabled aria-label="主音"><option>C</option></select></label><label>调式<select disabled aria-label="调式"><option>${modeDisplayName(NINETEEN_MODE)}</option></select></label></div><div class="mode-info"><p>C、D、E、G、A、B，共六个音。B 是“变宫”音，尽量少用在正拍。</p><p class="hint">谱面会框出强拍和次强拍的位置，可以边写边试听。</p></div><div class="score-scroll">${studioScaleSVG(p)}</div><button id="hearNineteen">▶ 试听音阶</button>`;
 $('#hearNineteen').onclick=async()=>{scalePreview=true;try{await playEvents(scalePitches(p).map((v,i)=>({t:i,d:.9,p:v})),false,180);}finally{scalePreview=false;}};
 nav(true,'',()=>{mutate(()=>applyNineteenMode(p));advanceAdvanced();});
}
// Use actual melody events, so subdivisions count and engraving ties do not.
function dorianCadences(p=project()){
 if(p.level!==16)return [];
 return sectionRanges(p).map((lines,section)=>({section,li:lines.at(-1),notes:lines.flatMap(li=>p.lines[li].durations.flatMap((d,i)=>{
  const parts=p.lines[li].melody?.[i]||[{d,p:p.lines[li].pitches[i]}];
  return parts.map((n,si)=>({li,i,si,p:n.p,assigned:d!==null}));
 })).slice(-4)}));
}
function dorianCadenceIssue(p,li){
 const cadence=dorianCadences(p).find(c=>c.li===li);if(!cadence)return '';
 const notes=cadence.notes,pitches=notes.map(n=>n.p),end=pitches.at(-1);
 if(notes.length<4||notes.some(n=>!n.assigned||!Number.isInteger(n.p)))return '这一段结尾需要至少4个音；可以拆分音符，再调整框出的音高';
 if(![29,36].includes(end))return '这一段最后一个音请回到 D 音';
 const direction=pitches[1]-pitches[0];
 return Math.abs(direction)===1&&pitches.every((v,i)=>!i||v-pitches[i-1]===direction)?'':'把框出的4个音写成连续逐级上行或下行，最后回到 D 音';
}
function dorianCadenceNote(p,n){return !n.rest&&n.last&&dorianCadences(p).some(c=>c.notes.some(v=>v.li===n.li&&v.i===n.i&&v.si===(n.si??0)));}
function dorianCadenceEnd(p,n){return !n.rest&&n.last&&dorianCadences(p).some(c=>{const v=c.notes.at(-1);return v&&v.li===n.li&&v.i===n.i&&v.si===(n.si??0);});}
function syncDorianGate(){
 const p=project(),step=p.level===16?advancedStep(p):null;if(!['pair','review'].includes(step?.kind)||!$('#next'))return;
 $('#next').disabled=(step.lines||p.lines.map((_,i)=>i)).some(li=>!!sentenceError(li));
}
// Preserve exact lines, and unchanged characters within an edited line, without
// silently assigning the old melody to newly inserted syllables.
function reconcileLyricLine(old,entry){
 if(old?.text===entry.text)return {...clone(old),punct:entry.punct||old.punct,section:entry.section};
 const freshLine=fresh(0,[entry.text]).lines[0];freshLine.cuts=freshLine.cuts.map((_,i)=>(i+1)%2===0);Object.assign(freshLine,{section:entry.section,punct:entry.punct,staccato:Array(lyricUnits(entry.text).length).fill(false),melody:{}});
 if(old){const a=lyricUnits(old.text),b=lyricUnits(entry.text),dp=Array.from({length:a.length+1},()=>Array(b.length+1).fill(0));for(let i=a.length-1;i>=0;i--)for(let j=b.length-1;j>=0;j--)dp[i][j]=a[i]===b[j]?1+dp[i+1][j+1]:Math.max(dp[i+1][j],dp[i][j+1]);let i=0,j=0;while(i<a.length&&j<b.length){if(a[i]===b[j]){freshLine.durations[j]=old.durations[i];freshLine.pitches[j]=old.pitches[i];freshLine.staccato[j]=!!old.staccato?.[i];if(old.melody?.[i])freshLine.melody[j]=clone(old.melody[i]);if(old.accidentals?.[i]!==undefined){freshLine.accidentals??={};freshLine.accidentals[j]=old.accidentals[i];}if(old.restsAfter?.[i]){freshLine.restsAfter??={};freshLine.restsAfter[j]=old.restsAfter[i];}i++;j++;}else if(dp[i+1][j]>=dp[i][j+1])i++;else j++;}}
 markCopyRepairs(freshLine);return freshLine;
}
function editedLessonLyrics(text,p=project()){
 const entries=parseLyrics(text);if(entries.length<6||entries.length>(p.level>=28?16:8))return {error:`保留 6～${p.level>=28?16:8} 句歌词；每句单独一行，段落之间空一行。`};
 if(entries.some(l=>lyricUnits(l.text).length>40||/[<>]/.test(l.text)))return {error:'每句请控制在 40 个字以内。'};
 const used=new Set(),sources=entries.map(e=>{const index=p.lines.findIndex((l,i)=>!used.has(i)&&l.text===e.text);if(index>=0)used.add(index);return index;});
 const lines=entries.map((e,i)=>{let from=sources[i];if(from<0&&!used.has(i)&&p.lines[i]){from=i;used.add(i);}return reconcileLyricLine(from>=0?p.lines[from]:null,e);});
 if(getRhythmPreference(p)==='regular'){
  const error=regularTimingError({...p,lines});
  if(error)return {error};
 }
 return {lines};
}
function lyricLineStructureChanged(before,after){
 if(before.length!==after.length)return true;
 // Reserve unchanged positions first: repeated lyrics and a single-line edit
 // must not look like a phrase moving merely because their text matches.
 const unchanged=new Set(before.map((line,i)=>line.text===after[i].text?i:-1));
 return after.some((line,i)=>!unchanged.has(i)&&before.some((old,j)=>j!==i&&!unchanged.has(j)&&old.text===line.text));
}
function applyEditedLessonLyrics(text,p=project()){
 const result=editedLessonLyrics(text,p);if(result.error)return result.error;
 p.sectionsByUser=true;
 const changed=JSON.stringify(p.lines)!==JSON.stringify(result.lines);if(!changed)return '';
 if(lyricLineStructureChanged(p.lines,result.lines))delete p.scoreLayout;
 p.lines=result.lines;p.sentenceStages=p.lines.map(l=>l.durations.every(d=>d!==null)?2:1);p.sentenceCompleted=p.lines.map(()=>false);p.sectionCopies={};p.complete=false;p.creditsConfirmed=false;p.maxStep=p.step;delete p.pickupBeats;delete p.pickupMeter;delete p.pickupDone;return '';
}
function renderEditableLessonLyrics(){const p=project();$('#stage').innerHTML=heading('编辑歌词与分段','把歌词改成你想唱的样子',`每句单独一行，段落之间空一行。保留 6～${p.level>=28?16:8} 句，可以改词，也可以重新分段。`)+`<textarea id="lessonLyrics" class="section-lyrics" aria-label="编辑歌词与分段" rows="12">${esc(p.lyricsEditDraft??sectionText(p))}</textarea><p class="hint">已有旋律会尽量保留；改动或新增的字，请再安排节奏和音高。</p>`;$('#lessonLyrics').oninput=e=>{p.lyricsEditDraft=e.target.value;save();};nav(true,'',()=>{const text=$('#lessonLyrics').value,result=editedLessonLyrics(text,p);if(result.error){toast(result.error);return;}mutate(()=>{applyEditedLessonLyrics(text,p);delete p.lyricsEditDraft;});advanceAdvanced();});}
// Course order v3 inserts the two-section lyric at 21. Older orders migrate
// directly to their current destinations, including JSON imports and backups.
function currentLessonOrderLevel(level,version=1){
 if(version>=3)return level;
 if(version<2&&level===19)return 20;
 if(version<2&&level===20)return 23;
 return level===21?22:level===22?23:level;
}
function normalizeLessonOrderProject(p){
 if(!p||typeof p!=='object'||p.lessonOrderVersion>=3||p.level<19||p.level>23)return p;
 const moved=clone(p),oldLevel=p.level;moved.level=currentLessonOrderLevel(oldLevel,p.lessonOrderVersion);moved.lessonOrderVersion=3;
 if(moved.coverSeenLevel===oldLevel)moved.coverSeenLevel=moved.level;
 return moved;
}
function migrateLessonOrderStore(store){
 if(!store||typeof store!=='object')return;
 const slots={19:'nineteen',20:'twenty',21:'twentyone',22:'twentytwo',23:'twentythree'},moves=[];
 for(const [level,from] of Object.entries(slots)){
  const p=store[from];if(!p||p.level!==+level)continue;
  const normalized=normalizeLessonOrderProject(p);if(normalized===p)continue;
  if(normalized.level===p.level)store[from]=normalized;
  else moves.push({from,to:slots[normalized.level],p:normalized});
 }
 // Collect both sources before writing: old 21 moves into old 22's slot.
 for(const move of moves)delete store[move.from];
 for(const move of moves){
  if(store[move.to]){store.lessonOrderRecovery??=[];store.lessonOrderRecovery.push({key:move.to,project:clone(store[move.to])});}
  store[move.to]=move.p;
 }
 const activeMove=moves.find(m=>m.from===store.active);if(activeMove)store.active=activeMove.to;
 if(Number.isInteger(store.coverLevel))store.coverLevel=currentLessonOrderLevel(store.coverLevel,store.lessonOrderVersion);
 store.lessonOrderVersion=3;
}
function migrateLessonOrder(){migrateLessonOrderStore(db);migrateLessonOrderStore(db.journeyBackup);migrateLessonOrderStore(db.rhythmBackups);}
// Refresh only the untouched default lyric. Any rhythm, grouping, lyric draft,
// or user-authored composition remains exactly as saved.
function refreshUnstartedLetterLyrics(p){
 const previous=[['清晨薄雾绕山岗','一溪春水过石梁','我把远方写纸上','寄给城里那扇窗','黄昏晚照映海港','一轮明月照船舱','你把归期写纸上','寄回山里那间房'],['风吹过山岗','掠过屋后那道旧围墙','我把没说完的话写满纸上','寄向有你的远方','潮涌进海港','漫过船边那片碎月光','你把一路的风景画满纸上','寄回等你的故乡']];
 if(!p||p.level!==21||p.lessonOrderVersion<3||p.complete||p.creditsConfirmed||p.sectionsByUser||p.lyricsEditDraft!==undefined||(p.step??0)>2||(p.maxStep??0)>2||p.lines.length!==8)return;
 if(!previous.some(lines=>p.lines.every((l,i)=>l.text===lines[i])))return;
 if(p.lines.some(l=>l.durations.some(d=>d!==null)||l.pitches.some(v=>v!==null)||Object.values(l.melody||{}).some(parts=>parts.length)||l.staccato?.some(Boolean)||l.cuts.some((cut,j)=>cut!==((j+1)%2===0))))return;
 p.lines=fresh(21,LATER_LESSONS[21].lines).lines.map((l,i)=>({...l,cuts:l.cuts.map((_,j)=>(j+1)%2===0),section:p.lines[i].section??LATER_LESSONS[21].sections[i],punct:p.lines[i].punct??(i%2?'。':'，')}));
}
function migrateLaterMeterTempo(p){
 if(!p||!laterLesson(p)||p.meterTempoVersion===1)return;
 const previousStep=p.step||0,previousMax=p.maxStep??previousStep;
 // Remap before older migrations clamp maxStep to the now-shorter step list.
 if(previousStep>0||previousMax>0)p.coverSeenLevel=p.level;
 p.step=Math.max(0,previousStep-1);p.maxStep=Math.max(p.step,previousMax-1,0);p.meterTempoVersion=1;
}
function renderLaterMeter(){
 const p=project(),meters=p.level>=18?['4/4','3/4','6/8']:['4/4','3/4'];
 $('#stage').innerHTML=heading('节拍和速度',p.level===18?'让旋律随着六八拍摇起来':'选个你喜欢的律动吧～','')+meterTempoHTML(p,{meters,tempos:[60,80,108,120,144],title:false})+(p.level===18?'<p>六个八分音符，三个一组：一二三、四五六。跟着两次轻轻的摇摆，听听它和三拍子的区别。</p><div class="actions meter-preview-actions"><button id="hearSixEight">▶ 对比 6/8 拍</button><button id="hearThreeFour">▶ 对比 3/4 拍</button></div>':'');
 bindMeterTempo(p,{onMeterChange:()=>{p.lines.forEach(l=>normalizeLessonLine(l,p));delete p.pickupBeats;delete p.pickupMeter;delete p.pickupDone;}});
 if(p.level===18){$('#hearSixEight').onclick=()=>previewMeterTempo('6/8',p.bpm);$('#hearThreeFour').onclick=()=>previewMeterTempo('3/4',p.bpm);}
 nav(true,'',()=>{if(p.level===18&&p.meter!=='6/8')return;mutate(()=>p.meterChosen=true);advanceAdvanced();});$('#next').disabled=p.level===18&&p.meter!=='6/8';
 if($('#next').disabled)markRequiredChoice($('[data-initial-meter="6/8"]'),'点选「6/8 拍」。');
}
function sixEightPreviewEvents(){return Array.from({length:24},(_,i)=>({t:i*.5,d:.2,p:28,kit:i%6===0?'kick':i%6===3?'snare':'hat'}));}
function previewSixEight(){return playEvents(sixEightPreviewEvents(),true,100);}
function renderDorianMode(){const p=project();$('#stage').innerHTML=heading('选择调式','这次从 D 出发，试试多利亚调式','听完音阶，再给自己的词写一段旋律。')+`<div class="mode-fields"><label>主音<select disabled aria-label="主音"><option>D</option></select></label><label>调式<select id="laterMode"><option value="">选择调式</option><option value="多利亚" ${p.scale==='多利亚'?'selected':''}>多利亚</option></select></label></div><p>D 多利亚用 D、E、F、G、A、B、C。从 D 出发，再回到 D；这次作品的最后一个音也停在 D。</p><div class="score-scroll">${studioScaleSVG({...p,tonic:'D',scale:'多利亚'})}</div><button id="hearDorian">▶ 试听 D 多利亚音阶</button>`;
 $('#laterMode').onchange=e=>{if(e.target.value){stop();mutate(()=>chooseMode(p,'多利亚'));render();}};
 $('#hearDorian').onclick=async()=>{// Preview uses the selected mode; stage entry already sets D Dorian.
 scalePreview=true;try{await playEvents(scalePitches({...p,tonic:'D',scale:'多利亚'}).map((v,t)=>({t,d:.9,p:v})),false,180);}finally{scalePreview=false;}};
 nav(true,'',()=>{mutate(()=>chooseMode(p,'多利亚'));advanceAdvanced();});
}
// The anchor is a position in the unmodified playback timeline. Regular boundaries
// extend backwards and forwards from it; the first/last bars may be incomplete.
function pickupPhase(anchor,p=project()){const bar=barBeats(p),v=Math.round(anchor*4)/4;return ((v%bar)+bar)%bar;}
function applyPickup(anchor,p=project()){const phase=pickupPhase(anchor,p);if(phase<.25)return false;p.pickupBeats=phase;p.pickupMeter=p.meter;p.pickupDone=true;return true;}
function pickupActive(p=project()){return Number.isFinite(p.pickupBeats)&&p.pickupBeats>0&&p.pickupBeats<barBeats(p)&&p.pickupMeter===p.meter;}
function pickupMeasures(p){
 const bar=barBeats(p),pickup=p.pickupBeats,events=[],starts=[];let total=0;
 p.lines.forEach((l,li)=>{starts.push(total);const ev=lineEvents(l),length=lineBeats(l,p);ev.forEach(e=>events.push({...e,li,abs:total+e.t,rest:!!e.rest}));const end=ev.reduce((s,e)=>Math.max(s,e.t+e.d),0);if(end<length)events.push({li,i:-1,abs:total+end,d:length-end,rest:true,syllableFirst:false});total+=length;});
 const boundaries=[0,pickup];while(boundaries.at(-1)+bar<total-.001)boundaries.push(boundaries.at(-1)+bar);if(boundaries.at(-1)<total)boundaries.push(total);
 const ms=boundaries.slice(0,-1).map((start,i)=>({start,end:boundaries[i+1],duration:boundaries[i+1]-start,li:0,bar:0,number:i,notes:[],pickup:i===0,incomplete:boundaries[i+1]-start<bar}));
 let measureIndex=0;
 events.forEach(e=>{while(measureIndex<ms.length-1&&ms[measureIndex].end<=e.abs+.00001)measureIndex++;let at=e.abs,remain=e.d,mi=measureIndex,parts=[];
 while(remain>.00001){const m=ms[mi],room=Math.min(remain,m.end-at),metric=at-m.start+(m.pickup?bar-pickup:0);spellRhythm(metric,room,bar).forEach(piece=>{const absolute=at+(piece.t-metric);parts.push({m,n:{...e,t:absolute-starts[e.li],abs:absolute,metric:piece.t,d:piece.d,local:absolute-m.start}});});at+=room;remain-=room;if(remain>.00001)mi++;}
 parts.forEach(({m,n},i)=>m.notes.push({...n,first:!e.rest&&i===0,last:!e.rest&&i===parts.length-1}));
 });
 const counts=new Map();ms.forEach(m=>{m.li=m.notes.find(n=>!n.rest)?.li??m.notes[0]?.li??0;m.bar=counts.get(m.li)||0;counts.set(m.li,m.bar+1);});return ms;
}
function pickupTeaching(p=project()){return p.level===23&&advancedStep(p)?.kind==='pickup';}
function barDraggingEnabled(p=project()){return p.level===0||p.level>=23&&['pickup','pair','section-compose','review','natural','accidentals'].includes(advancedStep(p)?.kind);}
function pickupQuestion(anchor,index=0){const p=project(),questions=['是否更改作品拍号？','是否更改相邻小节拍号？','是否重新分配作品节奏节拍？'],answer=index===2,modal=$('#modal');modal.innerHTML=`<h2>${questions[index]}</h2><div class="choices"><button id="pickupYes" class="${answer?'primary':''}" ${answer?'':'disabled'}>是</button><button id="pickupNo" class="${!answer?'primary':''}" ${answer?'disabled':''}>否</button></div><div class="actions"><button id="cancelPickup">取消</button></div>`;
 $('#cancelPickup').onclick=()=>modal.close();$(answer?'#pickupYes':'#pickupNo').onclick=()=>{if(index<2){pickupQuestion(anchor,index+1);return;}mutate(()=>applyPickup(anchor,p));stop();modal.close();render();};if(!modal.open)modal.showModal();
}
function renderPickupLesson(){const p=project(),done=pickupActive(p)&&p.pickupDone;$('#stage').innerHTML=heading('弱起小节',done?'听听这次不从第一拍出发的旋律':'拖动小节线，换一个出发的位置',done?'第一小节没有占满。这么操作可以不从小节的第一拍开始，称为弱起。':'把框出的小节线向左拖到音符之间，再完成三个选择。')+editingControls()+`<div class="pickup-status" role="status">${done?'已重新划分小节 · 作品拍号仍为 '+esc(p.meter):'按住谱子里的小节线拖动；松开后确认。'}</div><div id="scoreArea">${advancedScoreHTML()}</div>`;bindPlayback();nav(true,'',()=>{if(!pickupActive(p)||!p.pickupDone)return;for(let i=0;i<p.lines.length;i++){const issue=sentenceError(i);if(issue){toast(`第 ${i+1} 句：${issue}`);return;}}mutate(()=>p.complete=true);advanceAdvanced();});$('#next').disabled=!done;
}
function pickupRowPoints(row,p=project()){
 const offsets=[];let at=0;p.lines.forEach(l=>{offsets.push(at);at+=lineBeats(l,p);});
 return row.measures.flatMap(m=>{const start=m.start??offsets[m.li]+m.bar*barBeats(p),duration=m.duration??barBeats(p);return [...m.notes.map(n=>({x:n.x-18,t:n.abs??offsets[n.li]+n.t})),{x:m.x+m.width-5,t:start+duration}];}).sort((a,b)=>a.x-b.x);
}
function anchorAtX(row,x,p=project()){
 // Snap to a visible note/rest boundary instead of inventing tiny durations from pointer jitter.
 const points=pickupRowPoints(row,p),nearest=points.reduce((best,point)=>Math.abs(point.x-x)<Math.abs(best.x-x)?point:best);return nearest.t;
}
function bindBarDragging(){if(!barDraggingEnabled())return;
 $$('[data-drag-bar]').forEach(handle=>{handle.onpointerdown=e=>{if(e.button!==undefined&&e.button!==0)return;activeScoreDragCancel?.();e.preventDefault();e.stopPropagation();const p=project(),pointerId=e.pointerId,svg=handle.closest('svg'),row=typeof scoreLayoutRenderedRow==='function'?scoreLayoutRenderedRow(svg):systemModel(p).find(r=>r.measures[0].number===+svg.dataset.firstMeasure);if(!row)return;const rect=svg.getBoundingClientRect(),scale=svg.viewBox.baseVal.width/rect.width,startX=e.clientX;let x=+handle.dataset.x;
 const cleanup=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',end);window.removeEventListener('pointercancel',cancel);window.removeEventListener('blur',cancel);handle.removeAttribute('transform');if(activeScoreDragCancel===cancel)activeScoreDragCancel=null;};
 const move=ev=>{if(ev.pointerId!==pointerId)return;if(project()!==p){cancel();return;}x=Math.max(95,Math.min(row.endX-8,(ev.clientX-rect.left)*scale));handle.setAttribute('transform',`translate(${x-Number(handle.dataset.x)} 0)`);};
 const end=ev=>{if(ev?.pointerId!==pointerId)return;if(project()!==p){cancel();return;}cleanup();if(Math.abs(ev.clientX-startX)<5)return;const anchor=anchorAtX(row,x);if(pickupPhase(anchor)<.25){toast(pickupTeaching()?'再移开一点，让开头留下一个不满的小节':'请拖到不同的音符或休止边界');return;}pickupQuestion(anchor);};
 const cancel=ev=>{if(ev?.pointerId!==undefined&&ev.pointerId!==pointerId)return;cleanup();};
 activeScoreDragCancel=cancel;window.addEventListener('pointermove',move);window.addEventListener('pointerup',end);window.addEventListener('pointercancel',cancel);window.addEventListener('blur',cancel);
 };});
}
function installLaterLessons(){
 Object.assign(ADVANCED_LESSONS,LATER_LESSONS);CHAPTER_KEYS.push('sixteen','seventeen','eighteen','nineteen','twenty','twentyone','twentytwo','twentythree','twentyfour','twentyfive','twentysix','twentyseven','twentyeight','twentynine','thirty');for(let n=16;n<=30;n++)CHAPTER_TITLES[n]=LATER_LESSONS[n].title;
 const oldMigrate=migrateV2,oldProjectValid=validProject,oldChoose=chooseMode,oldModes=modeChoices,oldEnd=endingPitches,oldRender=renderOrderedLesson,oldSections=renderSections,oldLine=lineBeats,oldLimit=lessonGroupLimit,oldMeasure=measureModel,oldSVG=engravingSVG,oldBind=bindScore,oldValid=validStudioData,oldEndingIssue=endingIssue,oldCadence=cadenceRequirement,oldCadenceNote=isCadenceNote,oldReminder=cadenceStepReminder,oldRefresh=refreshScore,oldSentenceError=sentenceError,oldValidateComposition=validate,oldPageRender=render;
 migrateV2=function(){migrateLessonOrder();refreshUnstartedLetterLyrics(db.twentyone);for(const key of CHAPTER_KEYS)migrateLaterMeterTempo(db[key]);oldMigrate();applyNineteenMode(db.nineteen);};
 render=function(){applyNineteenMode(project());return oldPageRender();};
 sentenceError=function(li){return oldSentenceError(li)||nineteenModeIssue(li);};
 validate=function(p){return oldValidateComposition(p)||(p.level===19?p.lines.map((_,li)=>nineteenModeIssue(li,p)).find(Boolean)||'':'');};
 // Backups are validated before start() migrates them. Accept their old final
 // step without mutating the imported object or rejecting a completed work.
 validProject=function(p){p=normalizeLessonOrderProject(p);if(p&&laterLesson(p)&&p.meterTempoVersion!==1&&Number.isInteger(p.step)&&p.step>=0)p={...p,step:Math.max(0,p.step-1)};return oldProjectValid(p);};
 chooseMode=function(p,name){if(p.level===19){applyNineteenMode(p);return;}oldChoose(p,name);if(p.level>=16&&name==='多利亚'){p.tonic='D';p.mode=studioModeLabel(p);}};
 modeChoices=p=>p.level===19?[NINETEEN_MODE]:p.level>=16?(p.level===16?['多利亚']:['大调','宫调式（五声）','自然小调','羽调式（五声）','多利亚']):oldModes(p);
 endingPitches=p=>p.level>=16&&p.tonic==='D'?[29,36]:oldEnd(p);
 endingIssue=(p,li)=>p.level===16?dorianCadenceIssue(p,li):oldEndingIssue(p,li);
 cadenceRequirement=(p,li)=>p.level===16?(dorianCadences(p).some(c=>c.li===li)?{names:'D',ending:true}:null):oldCadence(p,li);
 isCadenceNote=(p,n)=>p.level===16?dorianCadenceNote(p,n):oldCadenceNote(p,n);
 cadenceStepReminder=function(k){
  const p=project();if(p.level===19){const step=advancedStep(p),ids=['pair','review'].includes(step?.kind)?step.lines||p.lines.map((_,i)=>i):[];return [oldReminder(k),...ids.map(li=>nineteenModeIssue(li,p))].filter(Boolean).join(' ');}if(p.level!==16)return oldReminder(k);
  const step=advancedStep(p);if(!['pair','review'].includes(step?.kind))return '';
  const ids=step.lines||p.lines.map((_,i)=>i),targets=dorianCadences(p).filter(c=>ids.includes(c.li));
  return targets.length?`第 ${targets.map(c=>c.section+1).join('、')} 段结尾：把框出的4个音连续逐级上行或下行到 D，例如 A—B—C—D 或 G—F—E—D。`:'';
 };
 lessonGroupLimit=p=>p.meter==='6/8'&&laterLesson(p)?3:oldLimit(p);
 lineBeats=function(l,p=project()){return laterLesson(p)&&p.meter==='6/8'?Math.max(6,Math.ceil(l.durations.reduce((s,d)=>s+(d??.5),0)/3)*3):oldLine(l,p);};
 renderSections=function(){return laterLesson()?renderEditableLessonLyrics():oldSections();};
 renderOrderedLesson=function(){const p=project();if(!laterLesson(p))return oldRender();const step=advancedStep(p);if(step.kind==='meter-tempo')return renderLaterMeter();if(step.kind==='mode'&&p.level===19)return renderNineteenMode();if(step.kind==='mode'&&p.level===16){if(p.tonic!=='D'||p.scale!=='多利亚'){chooseMode(p,'多利亚');save();}return renderDorianMode();}if(step.kind==='pickup')return renderPickupLesson();if(step.kind==='rests')return renderRestLesson();oldRender();syncDorianGate();syncNineteenGate();};
 refreshScore=function(){oldRefresh();syncDorianGate();syncNineteenGate();};
 measureModel=p=>pickupActive(p)?pickupMeasures(p):oldMeasure(p);
 engravingSVG=function(row,mode='combined',editable=true){let svg=oldSVG(row,mode,editable);const p=project();
 if(p.level===16&&editable&&mode==='combined'){
  svg=svg.replace(/<text class="ending-help"[\s\S]*?<\/text>/g,'').replace(/<rect class="cadence-target"[^>]*\/>/g,'');
  let labels='';for(const c of dorianCadences(p)){
   const targets=row.measures.flatMap(m=>m.notes).filter(n=>n.last&&c.notes.some(v=>v.li===n.li&&v.i===n.i&&v.si===(n.si??0)));
   if(!targets.length)continue;
   const x=Math.max(190,Math.min(row.width-190,(targets[0].x+targets.at(-1).x)/2));
   const ys=targets.map(n=>noteY(n.p??28)),left=targets[0].x-19,right=targets.at(-1).x+19,top=Math.min(...ys)-18,bottom=Math.max(...ys)+20;
   labels+=`<rect class="cadence-target scale-cadence-target" data-note-count="${targets.length}" aria-label="第 ${c.section+1} 段末音阶片段" pointer-events="none" x="${left}" y="${top}" width="${right-left}" height="${bottom-top}" rx="9" fill="none" stroke="#c58c2c" stroke-width="2"/><text class="scale-cadence-help" x="${x}" y="103" text-anchor="middle" font-size="13" fill="#8b641e">第 ${c.section+1} 段结尾：连续上行或下行到 D</text>`;
  }
  svg=svg.replace('</g></svg>',labels+'</g></svg>');
 }
 if(pickupActive(p)&&row.first)svg=svg.replace('</g></svg>',`<text x="${row.measures[0].x+20}" y="${mode==='jianpu'?145:mode==='combined'?100:128}" font-size="11" fill="#7d8977">弱起</text></g></svg>`);
 if(editable&&mode==='combined'&&barDraggingEnabled(p)){
  const teaching=pickupTeaching(p);let extra='';
  row.measures.forEach((m,i)=>{
   if(row.last&&i===row.measures.length-1)return;
   const x=m.x+m.width-5;
   extra+=`<g class="bar-drag-handle ${teaching&&m.number===0?'bar-drag-target':''} ${teaching?'bar-drag-teaching':'bar-drag-optional'}" data-drag-bar="${m.number}" data-x="${x}" role="button" aria-label="拖动第 ${m.number+1} 小节线重新划分小节"><rect x="${x-12}" y="136" width="24" height="76" rx="6" fill="${teaching?'#f5d897':'transparent'}" fill-opacity="${teaching?'.25':'0'}" stroke="${teaching?'#bc4141':'none'}"/>${teaching?`<path d="M${x} 148V200" stroke="#a2701e" stroke-width="2.5"/>`:''}</g>`;
   if(teaching&&m.number===0)extra+=`<text class="bar-drag-help" data-hint-li="${m.li}" x="${x-5}" y="130" text-anchor="end" font-size="12" fill="#926419">← 拖动这条小节线</text>`;
  });
  svg=svg.replace('</g></svg>',extra+'</g></svg>');
 }
 return svg;};
 bindScore=function(){oldBind();bindBarDragging();syncNineteenGate();};
 validStudioData=function(p){return oldValid(p)&&(p.pickupBeats===undefined||Number.isFinite(p.pickupBeats)&&p.pickupBeats>0&&p.pickupBeats<barBeats(p)&&p.pickupBeats*4%1===0&&p.pickupMeter===p.meter);};
}
