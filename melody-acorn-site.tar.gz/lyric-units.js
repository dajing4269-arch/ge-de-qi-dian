/* Stable lyric indexing: one sung syllable per entry, never one vowel letter. */
const ENGLISH_SYLLABLES={before:'be-fore',laughter:'laugh-ter',standing:'stand-ing',water:'wa-ter',quiet:'qui-et',river:'riv-er',matter:'mat-ter',footsteps:'foot-steps',always:'al-ways',morning:'morn-ing',across:'a-cross',little:'lit-tle',away:'a-way',ocean:'o-cean',beyond:'be-yond',evening:'eve-ning',above:'a-bove',silver:'sil-ver',different:'dif-fer-ent',surprise:'sur-prise'};
function lyricTokens(text){
 if(!/[A-Za-z]/.test(text))return [...text].map(text=>({text,syllabic:'single'}));
 const words=text.match(/[A-Za-z]+(?:['’-][A-Za-z]+)*|[\u3400-\u9fff]/g)||[];
 return words.flatMap(word=>{
  // Known lyrics are curated. New words stay intact until the author supplies
  // hyphens; spelling alone cannot reliably determine pronunciation.
  const parts=(word.includes('-')?word:(ENGLISH_SYLLABLES[word.toLowerCase()]||word)).split('-');
  if(/^[A-Z]/.test(word))parts[0]=parts[0][0].toUpperCase()+parts[0].slice(1);
  return parts.map((text,i)=>({text,syllabic:parts.length===1?'single':i===0?'begin':i===parts.length-1?'end':'middle'}));
 });
}
function lyricUnits(text){return lyricTokens(text).map(t=>t.text);}
function lyricSyllabic(text,i){return lyricTokens(text)[i]?.syllabic||'single';}
function englishSyllableDraft(text){return text.split(/(\s+)/).map(w=>ENGLISH_SYLLABLES[w.toLowerCase()]?( /^[A-Z]/.test(w)?ENGLISH_SYLLABLES[w.toLowerCase()][0].toUpperCase()+ENGLISH_SYLLABLES[w.toLowerCase()].slice(1):ENGLISH_SYLLABLES[w.toLowerCase()]):w).join('');}
