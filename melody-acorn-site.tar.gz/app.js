'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
let KEY='melody-garden-v1'; const POEM=['春眠不觉晓','处处闻啼鸟','夜来风雨声','花落知多少'];
const NAMES=['C','D','E','F','G','A','B'], SEMI=[0,2,4,5,7,9,11];
const midi=p=>typeof p==='object'&&p!==null?p.midi:(project().level===0||project().curriculumVersion===1)?studioMidi(p,project()):12*(Math.floor(p/7)+1)+SEMI[((p%7)+7)%7], pname=p=>NAMES[p%7]+Math.floor(p/7), clone=x=>JSON.parse(JSON.stringify(x));
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fresh=(level=1,lines=POEM.slice(0,2))=>({rhythmPreference:getRhythmPreference(),version:1,flowVersion:4,saveFlow:1,groupingVersion:1,controlOrder:2,sentenceFlow:level>0?1:0,level,title:level===0?'我的小作品':'春晓',step:0,bpm:80,lines:lines.map(text=>({text,cuts:lyricUnits(text).map((_,i)=>(i===1||i===3)).slice(0,-1),durations:Array(lyricUnits(text).length).fill(null),pitches:Array(lyricUnits(text).length).fill(null)})),complete:false});
let db={version:1,one:fresh(),two:null,studio:null,view:'home',active:'one'};
try{const raw=localStorage.getItem(KEY);if(raw){const x=JSON.parse(raw);if(x.version===1&&x.one)db=x;}}catch(e){}
let selected=null,groupIndex=0,undo=[],redo=[],audio=null,playState=null,playRequest=0,saveOK=true;
const project=()=>db[db.active];
function persistDB(value){localStorage.setItem(KEY,JSON.stringify(value));if(typeof window!=='undefined')window.accountSaved?.();}
function save(){try{persistDB(db);$('#saved').textContent='✓ 已保存到此设备';saveOK=true;}catch(e){saveOK=false;$('#saved').textContent='保存失败 · 请下载工程备份';toast('本机存储不可用，请及时下载工程文件');}}
function mutate(fn){
 const p=project(),before=JSON.stringify(p),oldMeter=p?.meter;
 fn();
 if(p&&getRhythmPreference(p)==='regular'){
  if(oldMeter!==p.meter)adaptUnwrittenRegularLines(p,JSON.parse(before));
  const error=regularTimingError(p);
  if(error){
   for(const key of Object.keys(p))delete p[key];
   Object.assign(p,JSON.parse(before));
   toast(error);
   return false;
  }
 }
 undo.push(before);
 if(undo.length>100)undo.shift();
 redo=[];save();
 return true;
}
function history(back){const a=back?undo:redo,b=back?redo:undo;if(!a.length)return;b.push(JSON.stringify(project()));db[db.active]=JSON.parse(a.pop());stop();save();render();}
function toast(msg){$('#toast').textContent=msg;$('#toast').classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>$('#toast').classList.remove('show'),3300);}
function groups(line){let out=[],start=0;lyricUnits(line.text).forEach((c,i)=>{if(line.cuts[i]||i===lyricUnits(line.text).length-1){out.push({start,end:i+1,text:lyricUnits(line.text).slice(start,i+1).join(/[A-Za-z]/.test(line.text)?' ':'')});start=i+1;}});return out;}
function allGroups(){return project().lines.flatMap((l,li)=>groups(l).map(g=>({...g,li})));}
function options(n){return ({1:[[1],[2],[4],[.5]],2:[[1,1],[2,2],[.5,.5],[1,2]],3:[[1,1,2],[.5,.5,1],[1,1,1],[2,1,1]],4:[[1,1,1,1],[.5,.5,.5,.5],[.5,.5,1,2],[1,1,.5,.5]]})[n]||[];}
function symbol(d){return d===.5?'♪':d===1?'♩':d===2?'𝅗𝅥':d===4?'𝅝':'♩·';}
function start(key){stop();db.active=key;migrateV2();db.view='editor';selected=null;groupIndex=0;undo=[];redo=[];save();render();}
function home(){stop();db.view='home';save();render();}
function render(){const p=project();$('#journey').classList.toggle('active',db.active!=='studio');$('#studio').classList.toggle('active',db.active==='studio');if(db.view==='home'){renderHome();return;}if(db.view==='library'){studioHome();return;}renderEditor();}
function pitchShortcutHint(k,p=project()){
 if(k!=='自由修改')return '';
 if(p.level===7)return '选中音符后，按 C、D、E、F、G、A、B 键，可输入 C4—B4 七个音。';
 if(p.level===10)return '选中音符后，按住 Shift，再按 C、D、E、F、G、A、B 键，可输入 C5—B5 七个音。';
 if(p.level===15)return '选中音符后，按 Shift + ↑／↓，可将音高升高／降低一个八度。';
 return '';
}
function keyboardPitch(code,shift,current){
 const letter=/^Key([CDEFGAB])$/.exec(code);
 if(letter)return (shift?35:28)+'CDEFGAB'.indexOf(letter[1]);
 if(code==='ArrowUp'||code==='ArrowDown'){const dir=code==='ArrowUp'?1:-1;return shift?(current??28)+dir*7:snapModePitch((current??28)+dir,dir);}
 return null;
}
// Heading callers and generated hints supply plain text, escaped once here.
function lessonIllustration(level, className, songTitle) {
  if (level === 11 && songTitle === '过山') return '';
  if (!(Number.isInteger(level) && level >= 1 && level <= 30)) return '';
  return `<img class="${className}" data-lesson="${level}" src="assets/songs/lesson-${level}.webp" alt="">`;
}
function heading(k,title,desc){desc=[desc,pitchShortcutHint(k),cadenceStepReminder(k)].filter(Boolean).join(' ');const songArt = lessonIllustration(project().level, 'song-heading-art', project().title);return `<div class="section-head"><div><div class="eyebrow">${esc(k)}</div>${title?`<h2${title===project().title?' class="song-title"':''}>${esc(title)}</h2>`:''}${desc?`<p>${esc(desc)}</p>`:''}</div>${songArt}</div>`;}
function nav(prev,next,fn){prev=prev&&project().step>0;const div=document.createElement('div');div.className='actions';div.innerHTML=`${prev?`<button id="prev">← 上一步：${stepNames()[project().step-1]}</button>`:''}<button class="primary" id="next">下一步：${stepNames()[project().step+1]||next} →</button>`;$('#stage').append(div);if(prev)$('#prev').onclick=()=>{stop();mutate(()=>project().step--);render();};$('#next').onclick=fn||(()=>{stop();mutate(()=>project().step++);render();});}
function renderFreeGroups(){const p=project();$('#stage').innerHTML=heading('划分词组','你感觉一句话里面的字/词该怎么划分？',p.level===0?'先划分成每组 1～4 个字。':'先划分成每组 1～2 个字。')+p.lines.map((l,li)=>`<div class="groups-line">${lyricUnits(l.text).map((c,i)=>`<span class="character ${/[A-Za-z]/.test(c)?'english-syllable':''}">${esc(c)}</span>${i<lyricUnits(l.text).length-1?`<button class="divider ${l.cuts[i]?'on':''}" data-line="${li}" data-cut="${i}" aria-label="${esc(c)}后${l.cuts[i]?'合并':'分组'}">│</button>`:''}`).join('')}</div>`).join('')+`<div class="guide">${p.level===0?'已把你的歌词按换行划成乐句，并进行了初步分组。你可以调整词组的分隔线。':'点击字与字之间的线，拆分或合并词组。每组 1～2 个字。'}</div>`;
$$('.divider').forEach(b=>{let sx; b.onpointerdown=e=>{sx=e.clientX;b.setPointerCapture(e.pointerId);};b.onpointerup=e=>{const li=+b.dataset.line,i=+b.dataset.cut,l=p.lines[li],cuts=[...l.cuts];if(Math.abs(e.clientX-sx)>20&&cuts[i]){cuts[i]=false;const j=Math.max(0,Math.min(cuts.length-1,i+Math.round((e.clientX-sx)/87)));cuts[j]=true;}else cuts[i]=!cuts[i];mutate(()=>{l.cuts=cuts;});render();};});nav(false,'选择节拍',()=>{if(!checkGroups())return;stop();mutate(()=>{if(p.level===1)p.lines.forEach(normalizeIntroLine);p.step++;});render();});}
function renderTempo(){const p=project();$('#stage').innerHTML=heading('选择速度','选个你想要的速度吧～',p.level===1?'速度可以决定音符进行的快慢，数越大，越快，数越小，越慢。':'')+`<div class="choices tempo-choices">${(p.level>=10?[60,80,108,120,144]:[80,120]).map(b=>`<div class="choice ${p.bpm===b?'selected':''}" data-bpm="${b}"><span class="eyebrow">${b<=80?'悠闲地':b<=108?'从容地':b<=120?'轻快地':'活泼地'}</span><h1>♩ = ${b}</h1><button data-tempo-play="${b}">▶ 听一听</button></div>`).join('')}</div>${p.level===0?`<p>自定义 BPM：<input id="customBpm" type="number" min="30" max="240" value="${p.bpm}"></p>`:''}${p.level > 0 ? tempoRhythmPreference(p) : ''}`;$$('[data-bpm]').forEach(b=>b.onclick=()=>{mutate(()=>p.bpm=+b.dataset.bpm);render();});$$('[data-tempo-play]').forEach(b=>b.onclick=e=>{e.stopPropagation();playEvents([0,1,2,3].map(t=>({t,d:.2,p:28})),true,+b.dataset.tempoPlay);});if($('#customBpm'))$('#customBpm').onchange=e=>{mutate(()=>p.bpm=Math.max(30,Math.min(240,+e.target.value||80)));render();};nav(true,'给歌词安排节奏');}
function durationPieces(d){const list=[4,3,2,1.5,1,.75,.5,.25],out=[];for(const v of list)while(d>=v-.001){out.push(v);d-=v;}return out;}
function lineEvents(l){
 const defaults=getRhythmPreference(project())==='regular'&&l.durations.includes(null)?regularDefaults(l,project()):null;
 let t=0;const events=l.durations.flatMap((d,i)=>{const parts=melodyEnabled()?l.melody?.[i]:null,notes=parts||[{d:d??(defaults?defaults[i]:boundedLesson()?.5:1),p:l.pitches[i]}],firstSound=notes.findIndex(n=>!n.rest);return notes.map((n,si)=>{const rest=n.rest===true,ev={t,d:n.d,p:rest?null:n.p,i,si,rest,staccato:rest?false:n.staccato??l.staccato?.[i]??false,assigned:d!==null,syllableFirst:si===firstSound,followedByRest:notes[si+1]?.rest===true};t=Math.round((t+n.d)*12)/12;return ev;});});return events.map((e,j)=>({...e,followedByRest:events[j+1]?.rest===true}));}
function allowed(li,i,pitch){const p=project();if(p.level===0)return pitch>=14&&pitch<=49;if(pitch<25||pitch>43)return false;const flat=p.lines.flatMap(l=>l.pitches),index=p.lines.slice(0,li).reduce((s,l)=>s+l.pitches.length,0)+i;return [flat[index-1],flat[index+1]].every(v=>v==null||Math.abs(v-pitch)<=11);}
function validate(p){const rhythmError=validateIntroRhythm(p);if(rhythmError)return rhythmError;if(p.lines.some(l=>l.pitches.some(v=>v===null)))return '还有浅色音符，给每个字选一个音高吧';if(p.level!==0){const last=p.lines.at(-1).pitches.at(-1);if(![28,35].includes(last))return '给整首最后一个字选择 C4 或 C5，让旋律落稳';if(p.level===2&&![1,4,6].includes(p.lines[1].pitches[4]%7))return '试着把“鸟”改成 G、B 或 D，完成这次变化';}return '';}
function showTheory(){const m=$('#modal');m.innerHTML=`<div class="eyebrow">A SMALL MUSICAL MAP</div><h2>从这里开始，数到那里。</h2><p>起点算作 1；每走到相邻的线或间，数字加 1。<br>同一个位置是一度，线到相邻间是二度，线到下一条线是三度。</p><svg viewBox="0 0 480 130" width="100%"><path d="M20 40H460 M20 60H460 M20 80H460 M20 100H460" stroke="#b1bca9"/><g fill="#365b45"><ellipse cx="70" cy="100" rx="9" ry="6"/><ellipse cx="170" cy="90" rx="9" ry="6"/><ellipse cx="270" cy="80" rx="9" ry="6"/></g><g font-size="14" fill="#365b45"><text x="50" y="125">起点 1</text><text x="150" y="125">二度 2</text><text x="250" y="125">三度 3</text></g></svg><p>这一关让相邻两音保持在十二度以内。暂时记不住也没关系，编辑器会帮你守住范围。</p><button id="octave">▶ 听听 C4 到 C5：八度</button><div class="actions"><button id="closeModal" class="primary">开始试试看</button></div>`;$('#octave').onclick=()=>playEvents([{t:0,d:1,p:28},{t:1.5,d:1,p:35}],false);$('#closeModal').onclick=()=>m.close();m.showModal();}
function getEvents(line=null){const p=project();let offset=0,out=[];p.lines.forEach((l,li)=>{const ev=lineEvents(l);if(line===null||line===li)out.push(...ev.map(e=>({...e,t:e.t+(line===null?offset:0),li})));offset+=lineBeats(l,p);});return out.map((e,j)=>({...e,followedByRest:out[j+1]?.rest===true&&Math.abs(out[j+1].t-e.t-e.d)<.001}));}
function rhythmChordMidi(p){
  const scale=STUDIO_MODES[p.scale||'大调'];
  const tonic=STUDIO_TONICS[p.tonic||'C'][1];
  const root=60+tonic-(tonic>6?12:0);
  const offsets=scale.length===5?scale.slice(0,4):[0,2,4].map(degree=>scale[modeDegrees(p).indexOf(degree)]);
  return offsets.map(offset=>root+offset);
}
function sound(ctx,dest,time,duration,pitch,drum=false,beat=60/project().bpm){if(drum){
  if(duration<=0)return;
  const envelope=ctx.createGain(), chord=rhythmChordMidi(project());
  const length=duration*.92,attack=Math.min(.012,length/4),release=Math.min(.045,length/3);
  const volume=.06/chord.length;
  envelope.gain.setValueAtTime(0,time);
  envelope.gain.linearRampToValueAtTime(volume,time+attack);
  envelope.gain.setValueAtTime(volume,time+length-release);
  envelope.gain.linearRampToValueAtTime(0,time+length);
  envelope.connect(dest);
  for(const midiNote of chord){
    const tone=ctx.createOscillator();
    tone.type='sine';
    tone.frequency.value=440*2**((midiNote-69)/12);
    tone.connect(envelope);
    tone.start(time);
    tone.stop(time+length);
  }
  // A quiet pair of damped resonances gives the onset a rounded wooden knock.
  const knockLength=Math.min(.085,length);
  for(const [frequency,volume] of [[565,.38],[890,.17],[1440,.06]]){
    const resonance=ctx.createOscillator(), decay=ctx.createGain();
    resonance.type='triangle';
    resonance.frequency.setValueAtTime(frequency,time);
    resonance.frequency.exponentialRampToValueAtTime(frequency*.91,time+knockLength);
    decay.gain.setValueAtTime(0,time);
    decay.gain.linearRampToValueAtTime(volume,time+Math.min(.002,knockLength/4));
    decay.gain.exponentialRampToValueAtTime(.0001,time+knockLength);
    resonance.connect(decay).connect(dest);
    resonance.start(time);resonance.stop(time+knockLength);
  }

}else{const freq=440*2**((midi(pitch)-69)/12);[1,2,3,4].forEach((h,i)=>{const osc=ctx.createOscillator(),g=ctx.createGain();osc.type='sine';osc.frequency.value=freq*h;g.gain.setValueAtTime(0,time);g.gain.linearRampToValueAtTime(.24/[1,3,7,12][i],time+.008);g.gain.exponentialRampToValueAtTime(.001,time+Math.max(.04,duration)+.15);osc.connect(g).connect(dest);osc.start(time);osc.stop(time+duration+.2);});}}
function soundEvent(ctx,dest,time,e,drum,beat){
 if(!audibleEvent(e,drum))return;
 const duration=e.d*beat*(e.staccato&&!drum?.4:1);
 let output=dest;
 if(e.followedByRest){const gate=ctx.createGain(),end=time+e.d*beat;gate.gain.setValueAtTime(1,time);gate.gain.setValueAtTime(1,Math.max(time,end-.015));gate.gain.linearRampToValueAtTime(0,end);gate.connect(dest);output=gate;}
 sound(ctx,output,time,duration,!drum&&e.alter!==undefined?{midi:eventMidi(e)}:e.p??28,e.kit||drum,beat);
}
function showPlaybackPosition(state,preview){
 const track=document.createElement('progress');
 track.setAttribute('aria-label','播放进度');
 track.style.cssText='display:block;width:100%;height:4px;accent-color:#39765e;pointer-events:none';
 const host=preview?.parentElement||document.querySelector('#modal[open],#scoreArea,#stage');
 if(!host)return;
 const scope=preview||host;
 const dots=[...scope.querySelectorAll('[data-dot-beat]')];
 const offsets=new Map();
 for(const event of state.events){
  if(event.li===undefined||offsets.has(event.li))continue;
  const local=lineEvents(project().lines[event.li]).find(n=>n.i===event.i&&(n.si??0)===(event.si??0));
  offsets.set(event.li,event.t-(local?.t??0));
 }
 const timings=dots.map(dot=>{
  const line=dot.dataset.dotLine;
  const start=Number(dot.dataset.dotBeat)+(preview||line===''?0:(offsets.get(Number(line))??Infinity));
  return {dot,start,end:start+Number(dot.dataset.dotLength)};
 });
 if(!dots.length&&!preview)host.prepend(track);
 const marker=document.createElementNS('http://www.w3.org/2000/svg','line');
 marker.setAttribute('stroke','#39765e');
 marker.setAttribute('stroke-width','2');
 marker.setAttribute('pointer-events','none');
 function frame(){
  if(playState!==state){track.remove();marker.remove();for(const dot of dots)dot.classList.remove('sounding-dot');return;}
  const elapsed=Math.max(0,audio.currentTime-state.start);
  const beatNow=elapsed*state.bpm/60;
  for(const {dot,start,end} of timings)dot.classList.toggle('sounding-dot',beatNow>=start&&beatNow<end);
  track.max=state.total||1;track.value=elapsed;
  let svg=preview,x,y1,y2;
  if(preview?.hasAttribute("data-sentence-tape")){x=Number(preview.dataset.inset)+Number(preview.dataset.unit)*Math.min(elapsed,state.total)*state.bpm/60;y1=53;y2=78;}
  else if(preview){x=18+48*Math.min(elapsed,state.total)*state.bpm/60;y1=-11;y2=3;}
  else{
   const beat=elapsed*state.bpm/60;
   const event=state.events.find(e=>e.li!==undefined&&e.t<=beat&&beat<e.t+e.d);
   const target=event&&document.querySelector('.note[data-li="'+event.li+'"][data-i="'+event.i+'"][data-si="'+(event.si||0)+'"]');
   const box=target?.querySelector('rect');
   if(box){svg=target.closest('svg');x=Number(box.getAttribute('x'))+17;y1=79;y2=202;}
  }
  if(svg&&!dots.length){if(marker.parentNode!==svg)svg.append(marker);for(const [k,v] of Object.entries({x1:x,x2:x,y1,y2}))marker.setAttribute(k,v);}
  else marker.remove();
  requestAnimationFrame(frame);
 }
 frame();
}
function schedulePlayTimers(state){
 const elapsed=audio.currentTime-state.start,beat=60/state.bpm;
 state.timers.forEach(clearTimeout);state.timers=[];
 const highlight=e=>{if(playState!==state)return;$$('.note.playing,.user-rest.playing').forEach(n=>n.classList.remove('playing'));$$(`.${e.rest?'user-rest':'note'}[data-li="${e.li}"][data-i="${e.i}"][data-si="${e.si??0}"]`).forEach(n=>n.classList.add('playing'));};
 let current=null;
 for(const e of state.events){if(e.li===undefined)continue;const delay=e.t*beat-elapsed;if(delay<=0)current=e;else state.timers.push(setTimeout(()=>highlight(e),delay*1000));}
 if(current)highlight(current);
 state.timers.push(setTimeout(()=>{if(playState===state)stop();},Math.max(0,state.total-elapsed+(state.drum?1.4:.3))*1000));
}
// Start the output inside the player's gesture. WebKit can suspend it again after a call.
async function readyPlayback(request){
 if(typeof stopInterfaceSound==='function')stopInterfaceSound();
 let timeout;
 try{
  if(!audio||audio.state==='closed'){
   const Context=window.AudioContext||window.webkitAudioContext;
   if(!Context){
    toast('当前浏览器不支持乐谱发声，请用系统浏览器打开。');
    return null;
   }
   try{
    if(navigator.audioSession)navigator.audioSession.type='playback';
   }catch{} // Embedded browsers may expose a read-only audio session.
   audio=new Context();
   audio.onstatechange=()=>{
    if(playState&&audio.state!=='running'&&(!playState.paused||audio.state==='closed'))stop();
   };
  }
  const ctx=audio;
  if(ctx.state!=='running'){
   const resume=ctx.resume();
   const silent=ctx.createBufferSource();
   silent.buffer=ctx.createBuffer(1,1,ctx.sampleRate);
   silent.connect(ctx.destination);
   silent.onended=()=>silent.disconnect();
   silent.start();
   await Promise.race([resume,new Promise((_,reject)=>{
    timeout=setTimeout(()=>reject(new Error('Audio output is still suspended')),3500);
   })]);
  }
  if(ctx.state!=='running')throw new Error('Audio output is unavailable');
  return ctx;
 }catch{
  if(request===playRequest)toast('声音未能启动，请再点一次播放；若仍无声，可用系统浏览器打开。');
  return null;
 }finally{
  clearTimeout(timeout);
 }
}
function audibleEvent(event,drum){
 return !event.rest&&event.d>0&&(drum?event.assigned!==false:event.p!=null);
}
async function playEvents(events,drum=false,bpm=project().bpm,preview=null,fromBeat=0){
 stop();
 const request=playRequest;
 if(!events.some(e=>e.t+e.d>fromBeat&&audibleEvent(e,drum))){
  const hasLyrics=events.some(e=>!e.rest&&e.d>0&&e.t+e.d>fromBeat);
  toast(hasLyrics?(drum?'先给歌词安排节奏，再试听。':'先给五线谱上的音符选音高，再试听旋律。'):'这里是休止，没有可试听的音符。');
  return;
 }
 const ctx=await readyPlayback(request);
 if(!ctx||request!==playRequest)return;
 const gain=ctx.createGain();
 gain.gain.value=.65;
 gain.connect(ctx.destination);
 const t=ctx.currentTime+.04,beat=60/bpm;
 for(const e of events){
  const onset=Math.max(e.t,fromBeat),duration=e.t+e.d-onset;
  if(duration>0)soundEvent(ctx,gain,t+(onset-fromBeat)*beat,{...e,d:duration},drum,beat);
 }
 const total=events.reduce((end,e)=>Math.max(end,e.t+e.d),0)*beat;
 playState={gain,events,drum,bpm,start:t-fromBeat*beat,total,paused:false,timers:[]};
 schedulePlayTimers(playState);
 showPlaybackPosition(playState,preview);
 updatePlay();
}
document.addEventListener('contextmenu',event=>{
 const dot=event.target.closest('.rhythm-dot-strip circle');
 const strip=dot?.closest('svg[data-sentence-tape],svg.unified-score');
 if(!strip)return;
 event.preventDefault();
 const li=Number(strip.dataset.sentenceTape??dot.dataset.dotLine);
 const line=project().lines[li];
 const tick=Math.round(Number(dot.dataset.dotBeat)*12),beat=Math.floor(tick/12);
 const triplet=line.tripletBeats?.includes(beat);
 const menu=$('#modal');
 menu.innerHTML='<h2>节奏条节点</h2><div class="actions"></div>';
 const actions=menu.querySelector('.actions');
 function option(label,change){
  const button=document.createElement('button');
  button.textContent=label;
  button.onclick=()=>{menu.close();if(change){mutate(change);render();}};
  actions.append(button);
 }
 const quarter=(Math.floor(tick/6)*6+3)/12;
 if(!triplet&&quarter<lineBeats(line,project())){
  if(line.quarterNodes?.includes(quarter))
   option('取消 1/4 拍节点',()=>{line.quarterNodes=line.quarterNodes.filter(t=>t!==quarter);});
  else option('添加 1/4 拍节点',()=>{line.quarterNodes=[...(line.quarterNodes||[]),quarter];});
 }
 if(tick%12===0||triplet){
  if(triplet)option('恢复 1/2 拍节点',()=>{line.tripletBeats=line.tripletBeats.filter(t=>t!==beat);});
  else option('将 1/2 拍节点改为三连音（1/3 拍）',()=>{line.tripletBeats=[...(line.tripletBeats||[]),beat];});
 }
 option('关闭');
 menu.showModal();
});
document.addEventListener('pointerdown',event=>{
 const endHandle=event.target.closest('[data-rhythm-end]');
 const score=event.target.closest('svg.unified-score');
 const tape=event.target.closest('svg[data-sentence-tape]')||score;
 if(!tape||!event.isPrimary||event.button!==0)return;
 const hit=event.target.closest('[data-dot-beat]');
 if(score&&!hit&&!endHandle)return;
 const matrix=tape.getScreenCTM();if(!matrix)return;
 if(!score&&!endHandle&&new DOMPoint(event.clientX,event.clientY).matrixTransform(matrix.inverse()).y>79)return;
 const at=e=>new DOMPoint(e.clientX,e.clientY).matrixTransform(matrix.inverse()).x;
 const li=Number(tape.dataset.sentenceTape??(endHandle||hit)?.dataset.dotLine);
 const cells=[...tape.querySelectorAll('.rhythm-dot-strip circle')].filter(c=>!score||+c.dataset.dotLine===li);
 if(!cells.length)return;
 const nearest=x=>cells.reduce((a,b)=>Math.abs(+b.getAttribute('cx')-x)<Math.abs(+a.getAttribute('cx')-x)?b:a);
 const origin=endHandle||hit||nearest(at(event));
 if(!endHandle&&(origin.dataset.onset!=='true'||Math.abs(+origin.getAttribute('cx')-at(event))>11))return;
 const line=project().lines[li],events=lineEvents(line);
 const index=endHandle?events.findLastIndex(e=>!e.rest)+1:events.findIndex(e=>Math.abs(e.t-Number(origin.dataset.dotBeat))<1e-8&&!e.rest&&(score||e.assigned));
 if(index<=0)return;
 const previous=events[index-1],note=endHandle?null:events[index];
 const step=rhythmDragStep(),regular=getRhythmPreference(project())==='regular';
 const valid=endHandle?[]:cells.filter(c=>{
  const beat=Number(c.dataset.dotBeat);
  const extra=beat%step!==0&&rhythmGridTick(line,Math.round(beat*12));
  const minimum=(extra||previous.t%step||(note.t+note.d)%step) ? .25 : step;
  const dx=beat-note.t;
  if(regular&&previous.i!==note.i&&(!previous.rest&&(writtenLyricDuration(line,previous.i)??previous.d)+dx<.5-1e-8||!note.rest&&(writtenLyricDuration(line,note.i)??note.d)-dx<.5-1e-8))return false;
  return rhythmGridTick(line,Math.round(beat*12))&&beat-previous.t>=minimum-1e-8&&note.t+note.d-beat>=minimum-1e-8;
 });
 let endDelta=0;
 let active=false,target=origin;
 // Mouse and trackpad start a drag on movement; fingers wait for a hold.
 const desktop=event.pointerType==='mouse';
 function activate(){active=true;stop();origin.classList.add('drag-origin');}
 const timer=desktop?null:setTimeout(activate,350);
 tape.setPointerCapture(event.pointerId);
 function move(e){
  if(e.pointerId!==event.pointerId)return;
  if(!active){
   const distance=Math.hypot(e.clientX-event.clientX,e.clientY-event.clientY);
   if(desktop&&distance>=3)activate();
   else{if(!desktop&&distance>8)finish();return;}
  }
  const x=at(e);
  if(endHandle){
   const unit=Math.max(1,Number(origin.dataset.unit));
   const movement=(x-at(event))/unit;
   const tailEnd=events.at(-1).t+events.at(-1).d;
   const syllable=writtenLyricDuration(line,previous.i)??previous.d;
   const limit=regular?previous.d+regularBudget(project())-tailEnd:8-syllable+previous.d;
   const min=regular?Math.max(.25,previous.d+.5-syllable):.25;
   const wanted=previous.t+previous.d+movement;
   const ends=[];
   for(let tick=Math.round((previous.t+min)*12);tick<=Math.round((previous.t+limit)*12);tick++){
    if(rhythmGridTick(line,tick))ends.push(tick/12);
   }
   const current=previous.t+previous.d;
   const closest=ends.reduce((best,beat)=>Math.abs(beat-wanted)<Math.abs(best-wanted)?beat:best,current);
   endDelta=closest-current;
   origin.setAttribute('transform',`translate(${endDelta*unit} 0)`);
   return;
  }
  target.classList.remove('drag-target');
  target=valid.reduce((a,b)=>Math.abs(+b.getAttribute('cx')-x)<Math.abs(+a.getAttribute('cx')-x)?b:a,origin);
  target.classList.add('drag-target');
 }
 function finish(e){
  if(e&&e.pointerId!==event.pointerId)return;
  if(active&&e?.type==='pointerup')move(e);
  clearTimeout(timer);
  tape.removeEventListener('pointermove',move);
  for(const type of ['pointerup','pointercancel','lostpointercapture'])tape.removeEventListener(type,finish);
  if(tape.hasPointerCapture(event.pointerId))tape.releasePointerCapture(event.pointerId);
  origin.classList.remove('drag-origin');target.classList.remove('drag-target');
  if(endHandle)origin.removeAttribute('transform');
  if(!active||e?.type!=='pointerup'||(endHandle?!endDelta:target===origin))return;
  const delta=endHandle?endDelta:Number(target.dataset.dotBeat)-note.t;
  function resize(part,amount){
   if(part.addedGap){line.restsAfter[part.i]+=amount;return;}
   const segment=line.melody?.[part.i]?.[part.si];
   if(segment)segment.d=Math.round((segment.d+amount)*12)/12;
   line.durations[part.i]=Math.round(((line.durations[part.i]??part.d)+amount)*12)/12;
  }
  mutate(()=>{resize(previous,delta);if(note)resize(note,-delta);line.dragRhythm=true;});
  render();
 }
 tape.addEventListener('pointermove',move);
 for(const type of ['pointerup','pointercancel','lostpointercapture'])tape.addEventListener(type,finish);
});
function playAll(drum=false,line=null,fromBeat=0){const p=project(),events=getEvents(line),end=line===null?p.lines.reduce((s,l)=>s+lineBeats(l,p),0):lineBeats(p.lines[line],p);events.push({t:end,d:0,p:null,assigned:false});return playEvents(events,drum,p.bpm,line===null?null:document.querySelector('[data-sentence-tape="'+line+'"]'),fromBeat);}
function stop(){playRequest++;if(playState){playState.gain.disconnect();playState.timers.forEach(clearTimeout);playState=null;}$$('.note.playing,.user-rest.playing').forEach(n=>n.classList.remove('playing'));updatePlay();}
function updatePlay(){
 const action=playState?(playState.paused?'▶ 继续':'Ⅱ 暂停'):null;
 const main=$('#playAll'),finish=$('#finishPlay');
 if(main)main.textContent=action||'▶ 播放';
 if(finish)finish.textContent=action||'▶ 整首播放';
 const preview=$('#hearMeterTempo');if(preview)preview.textContent=playState?.events?.[0]?.preview==='meter-tempo'?'■ 停止试听':`▶ 试听 ${project().meter||'4/4'} 拍 · ♩ = ${project().bpm}`;}
async function togglePlay(){
 if(!playState)return playAll(!sentenceLesson()&&project().step===3&&project().level!==0&&project().level!==2);
 const state=playState,request=playRequest;
 if(state.switching)return;
 state.switching=true;
 try{
  if(state.paused){
   const ctx=await readyPlayback(request);
   if(!ctx||playState!==state)return;
   state.paused=false;
   schedulePlayTimers(state);
  }else{
   state.paused=true;
   state.timers.forEach(clearTimeout);
   state.timers=[];
   await audio.suspend();
  }
 }catch{
  if(playState===state){stop();toast('播放已中断，请重新点播放。');}
 }finally{
  state.switching=false;
  updatePlay();
 }
}
async function audition(p){
 stop();
 const request=playRequest,ctx=await readyPlayback(request);
 if(ctx&&request===playRequest)sound(ctx,ctx.destination,ctx.currentTime+.01,.25,p);
}
function download(blob,name){const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);}
function backup(){download(new Blob([JSON.stringify({format:'melody-garden',version:1,project:project()},null,2)],{type:'application/json'}),project().title+'.melody.json');toast('工程已下载，可通过“打开乐谱或工程”继续编辑');}
function varlen(n){const a=[n&127];while(n>>=7)a.unshift((n&127)|128);return a;}
function midiBytes(){const p=project(),tempo=Math.round(60000000/p.bpm),track=[0,255,81,3,(tempo>>16)&255,(tempo>>8)&255,tempo&255,0,255,88,4,meterParts()[0],Math.log2(meterParts()[1]),24,8,0,192,xiaoMode(p)?77:0],events=[];getEvents().filter(e=>!e.rest&&e.p!==null).forEach(e=>{events.push({t:Math.round(e.t*480),b:[144,eventMidi(e),90],order:1});events.push({t:Math.round((e.t+e.d*(e.staccato?.4:1))*480),b:[128,eventMidi(e),0],order:0});});events.sort((a,b)=>a.t-b.t||a.order-b.order);let last=0;events.forEach(e=>{track.push(...varlen(e.t-last),...e.b);last=e.t;});track.push(...varlen(Math.max(0,p.lines.reduce((s,l)=>s+lineBeats(l,p)*480,0)-last)),255,47,0);const n=track.length;return new Uint8Array([77,84,104,100,0,0,0,6,0,0,0,1,1,224,77,84,114,107,(n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255,...track]);}
function exportMidi(){download(new Blob([midiBytes()],{type:'audio/midi'}),project().title+'.mid');toast('MIDI 已下载');}
async function exportMp3(button){
 if(!window.lamejs)throw new Error('MP3 编码器未加载，请刷新后重试');
 const old=button.innerHTML,p=project(),title=p.title,xiao=xiaoMode(p),events=getEvents(),beat=60/p.bpm,length=p.lines.reduce((s,l)=>s+lineBeats(l,p),0)*beat+1,sr=44100;
 button.disabled=true;button.textContent='正在生成 MP3…';
 try{
  const ctx=new OfflineAudioContext(1,Math.ceil(length*sr),sr);
  events.forEach(e=>soundEvent(ctx,ctx.destination,e.t*beat,e,false,beat));
  const buffer=await ctx.startRendering(),data=buffer.getChannelData(0),pcm=new Int16Array(data.length);
  for(let i=0;i<data.length;i++)pcm[i]=Math.round(Math.max(-1,Math.min(1,data[i]))*32767);
  const enc=new lamejs.Mp3Encoder(1,sr,128),out=[];
  for(let i=0;i<pcm.length;i+=1152){const bytes=enc.encodeBuffer(pcm.subarray(i,i+1152));if(bytes.length)out.push(bytes);if(i%(1152*200)===0)await new Promise(r=>setTimeout(r,0));}
  out.push(enc.flush());download(new Blob(out,{type:'audio/mpeg'}),title+'.mp3');toast('MP3 已生成，音色与网页'+(xiao?'洞箫':'钢琴')+'试听一致');
 }finally{button.disabled=false;button.innerHTML=old;}
}
async function svgImage(svg,w,h){const image=new Image(),url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));try{await new Promise((res,rej)=>{image.onload=res;image.onerror=rej;image.src=url;});const canvas=document.createElement('canvas');canvas.width=w*2;canvas.height=h*2;const c=canvas.getContext('2d');c.fillStyle='white';c.fillRect(0,0,canvas.width,canvas.height);c.drawImage(image,0,0,canvas.width,canvas.height);return canvas.toDataURL('image/png');}finally{URL.revokeObjectURL(url);}}
function validProject(p){return p&&validStudioData(p)&&Number.isInteger(p.level)&&p.level>=0&&p.level<CHAPTER_KEYS.length&&Number.isFinite(p.bpm)&&p.bpm>=30&&p.bpm<=240&&typeof p.title==='string'&&p.title.length<100&&Number.isInteger(p.step)&&p.step>=0&&p.step<=(p.saveFlow?saveStep(p):p.level===2?3:p.level===4?7:p.flowVersion===4?6:p.flowVersion===3?5:4)&&Array.isArray(p.lines)&&p.lines.length>0&&p.lines.length<=200&&p.lines.every(l=>typeof l.text==='string'&&lyricUnits(l.text).length>0&&lyricUnits(l.text).length<=100&&Array.isArray(l.pitches)&&Array.isArray(l.durations)&&Array.isArray(l.cuts)&&l.pitches.length===lyricUnits(l.text).length&&l.durations.length===l.pitches.length&&l.cuts.length===l.pitches.length-1&&l.cuts.every(v=>typeof v==='boolean')&&groups(l).every(g=>g.end-g.start<=4)&&l.pitches.every(v=>v===null||Number.isInteger(v)&&v>=14&&v<=49)&&l.durations.every(v=>v===null||(Number.isFinite(v)&&v>=.25&&v<=256&&Math.abs(v*12-Math.round(v*12))<1e-8)))&&(getRhythmPreference(p)!=='regular'||!regularTimingError(p));}
$('#journey').onclick=home;$('.brand').onclick=e=>{e.preventDefault();home();};$('#studio').onclick=studioHome;
function newSong(){const m=$('#modal');m.innerHTML='<div class="eyebrow">新的歌曲</div><h2>贴上你的歌词</h2><input id="songTitle" maxlength="80" placeholder="歌曲名字（可以先不填）"><p>每一行是一句歌词，逗号、句号不会另起乐句。空一行划分段落，每句独立起小节。</p><textarea id="lyrics" placeholder="晚风经过小窗\n带来一片月光"></textarea><div class="actions"><button id="cancel">取消</button><button id="create" class="primary">开始创作</button></div>';$('#cancel').onclick=()=>m.close();$('#create').onclick=()=>{const parsed=parseLyrics($('#lyrics').value),lines=parsed.map(l=>l.text);if(!lines.length){toast('先写一句歌词吧');return;}if(lines.length>200||lines.some(s=>[...s].length>100)){toast('当前版本每句最多100字、最多200句，请拆分长句');return;}
 const candidate=fresh(0,lines);
 if(getRhythmPreference(candidate)==='regular'){
  const error=regularTimingError(candidate);
  if(error){toast(error+' 也可以切换为自由节奏。');return;}
 }
 const previous=db;let next;
 try{db=clone(previous);archiveStudio();db.studio=candidate;db.studio.title=$('#songTitle').value.trim()||lines[0].slice(0,20);db.studio.uiVersion=2;db.studio.barsPerRow=0;db.studio.lines.forEach((l,i)=>{l.punct=parsed[i].punct;l.section=parsed[i].section??0;});db.studio.lines.forEach(l=>l.cuts=lyricUnits(l.text).slice(0,-1).map((_,i)=>(i+1)%2===0));db.active='studio';migrateV2();db.view='editor';next=db;}
 catch(err){toast('无法创建这首作品，当前作品保持不变');return;}finally{db=previous;}
 if(!saveLibraryChange(next))return;
 stop();selected=null;groupIndex=0;undo=[];redo=[];m.close();$('#saved').textContent='✓ 已保存到此设备';render();
 };m.showModal();}
$('#import').onclick=()=>$('#file').click();$('#file').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;if(/\.(musicxml|xml|mxl|mid|midi)$/i.test(f.name)){await openExternalScore(f);return;}if(f.size>2000000)throw Error('工程文件过大');const data=JSON.parse(await f.text());if(typeof installPublicRelease==='function'&&publicReleaseKnowledgeProject(data.project))throw Error('此工程属于进阶模式，无法在 1.0 打开');data.project=normalizeLessonOrderProject(data.project);if(typeof migrateKnowledgeProject==='function')data.project=migrateKnowledgeProject(data.project);if(data.format!=='melody-garden'||data.version!==1||!validProject(data.project))throw Error('不是有效的工程文件');const key=typeof knowledgeLesson==='function'&&knowledgeLesson(data.project)?'knowledge'+data.project.knowledgeLesson:data.project.advancedReview!==undefined?'review'+data.project.advancedReview:data.project.level===0?'studio':CHAPTER_KEYS[data.project.level];const m=$('#modal');m.innerHTML='<h2>打开工程</h2><p>将替换当前对应关卡的进度。建议先下载现有工程备份。</p><div class="actions"><button id="cancelImport">取消</button><button id="confirmImport" class="primary">打开并替换</button></div>';$('#cancelImport').onclick=()=>m.close();$('#confirmImport').onclick=()=>{
 const previous=db;let next;
 // Archive and migrate an isolated candidate before changing the current work.
 try{db=clone(previous);if(key==='studio')archiveStudio();db[key]=clone(data.project);db.active=key;migrateV2();db.view='editor';next=db;}
 catch(err){toast('无法恢复这个工程，当前作品保持不变');return;}finally{db=previous;}
 if(!saveLibraryChange(next))return;
 stop();selected=null;groupIndex=0;undo=[];redo=[];m.close();$('#saved').textContent='✓ 已保存到此设备';render();toast('工程已恢复');
 };m.showModal();}catch(err){toast(err.message);}e.target.value='';};
document.addEventListener('keydown',e=>{if(e.isComposing||e.target.isContentEditable||['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName)||$('#modal').open)return;if(db.view!=='editor')return;if((e.ctrlKey||e.metaKey)&&e.code==='KeyZ'){e.preventDefault();history(!e.shiftKey);return;}if((e.ctrlKey||e.metaKey)&&e.code==='KeyY'){e.preventDefault();history(false);return;}if(e.ctrlKey||e.metaKey||e.altKey)return;if(e.code==='Space'){
 if(e.target.closest('button[data-rhythm-pref]'))return;
 const play=$('#playAll');
 if(play){e.preventDefault();play.click();}
 else if(!$('.sentence-substeps')){e.preventDefault();togglePlay();}
 return;
}if(!selected||!$('#scoreArea')||$('#scoreArea').dataset.readonly==='true')return;const p=project(),{li,i,si=0}=selected,l=p.lines[li];const v=keyboardPitch(e.code,e.shiftKey,notePitch(li,i,si));if(v!==null){e.preventDefault();if(allowed(li,i,v)){mutate(()=>setNotePitch(li,i,si,v));refreshScore();audition(v);}return;}if(['ArrowLeft','ArrowRight'].includes(e.code)){e.preventDefault();const flat=p.lines.flatMap((l,li)=>melodyEnabled(p)?lineEvents(l).filter(n=>!n.rest).map(n=>({li,i:n.i,si:n.si})):l.pitches.map((_,i)=>({li,i}))),idx=flat.findIndex(n=>n.li===li&&n.i===i&&(n.si??0)===si),next=flat[idx+(e.code==='ArrowRight'?1:-1)];if(next){selected=next;refreshScore();}}});
window.addEventListener('beforeunload',e=>{if(!saveOK){e.preventDefault();e.returnValue='';}});installSentenceFlow();installCurriculum();installAdvancedLessons();installStudioSetup();installLaterLessons();installSectionCompose();installRests();installLyricRests();installScoreKeys();installNewLessons();installHarmonicLessons();installTonalGuides();installStrongBeats();installLessonCovers();installScoreCheck();installRewriteWork();if(typeof installKnowledgeJourney==='function')installKnowledgeJourney();installScoreLayout();installLessonStepNavigation();installTouchControls();if(typeof installPublicRelease==='function')installPublicRelease();migrateV2();save();render();
