/* Early lessons compose one complete phrase at a time. Studio stays a whole-song editor. */
function sentenceLesson(p=project()){return p.level>=1&&p.level<=10&&p.sentenceFlow===1;}
function sentenceLabels(p){if(p.level===2)return ['旋律的重复','中间的停顿','整首作品调整','完成作品','保存作品'];return ['选择节拍','选择速度','选择调式',...(p.level===2?['复制前两句旋律','更改第二句旋律结尾','整首作品调整']:p.lines.map((_,i)=>`创作第${['一','二','三','四','五','六','七','八'][i]||i+1}句旋律`)),...(p.level===3?['整首作品调整']:p.level===4?['加入跳音']:[]),'完成作品','保存作品'];}
function sentenceCredit(p){return p.level===2?3:3+p.lines.length+([3,4].includes(p.level)?1:0);}
function sentenceIndex(p=project()){return p.step-3;}
function inSentence(p=project()){return sentenceLesson(p)&&p.level!==2&&p.step>=3&&p.step<3+p.lines.length;}
function migrateSentenceFlow(p){
  if(p.level===0){if(p.controlOrder!==2){const order=[3,0,1,2,4,5,6];p.step=order[p.step]??p.step;p.maxStep=p.step<4?3:Math.max(p.maxStep??0,p.step);p.controlOrder=2;}return;}
  if(p.level<1||p.level>10)return;
  const oldStep=p.step;
  if(p.level===2&&p.lines.length===2)p.lines.push(...p.lines.map((l,i)=>({...clone(l),text:POEM[i+2],punct:i===0?'，':'。'})));
  if(p.sentenceFlow!==1){
    p.sentenceStages=p.lines.map(l=>l.pitches.every(v=>v!==null)?2:l.durations.every(v=>v!==null)?2:0);
    p.sentenceCompleted=p.lines.map(l=>l.pitches.every(v=>v!==null)&&l.durations.every(v=>v!==null));
    if(p.complete)p.step=sentenceCredit(p)+(p.creditsConfirmed?1:0);
    else if(p.level===2)p.step=4;
    else if(oldStep===0)p.step=3;
    else if(oldStep===1)p.step=0;
    else if(oldStep===2)p.step=1;
    else if(oldStep===4)p.step=2;
    else {const unfinished=p.sentenceCompleted.findIndex(v=>!v);p.step=3+(unfinished<0?p.lines.length-1:unfinished);}
    p.maxStep=p.step;p.sentenceFlow=1;
  }
  p.sentenceStages??=p.lines.map(()=>0);p.sentenceCompleted??=p.lines.map(()=>false);
  while(p.sentenceStages.length<p.lines.length)p.sentenceStages.push(0);
  while(p.sentenceCompleted.length<p.lines.length)p.sentenceCompleted.push(false);
  if(p.level===2&&!p.repeatFlow){
    const map=[0,1,2,3,4,5,5,6,7];
    p.repeatedMelody=p.complete||p.step>3;
    p.step=p.complete?6+(p.creditsConfirmed?1:0):(map[p.step]??3);
    p.maxStep=Math.max(p.step,map[p.maxStep]??p.step);p.repeatFlow=1;
  }
  if(p.level===2&&p.repeatFlow!==2){
    p.step=p.complete?3+(p.creditsConfirmed?1:0):Math.max(0,p.step-3);
    p.maxStep=Math.max(p.step,Math.max(0,(p.maxStep??0)-3));p.repeatFlow=2;
  }
  if(p.level===3&&p.regroupFlow!==1){if(p.step>=3+p.lines.length){p.step++;p.maxStep=Math.max(p.maxStep??0,p.step);}p.meter='4/4';p.regroupFlow=1;}
  if(p.level===4&&p.earlyMeterVersion!==1){p.meter='4/4';p.earlyMeterVersion=1;}
  p.controlOrder=2;
}
function sentenceError(li){const p=project(),l=p.lines[li];if(groups(l).some(g=>g.end-g.start>2))return '先把这句分成每组 1～2 个字';if(l.durations.some(d=>d===null))return '这句还有歌词缺少时长';if(l.pitches.some(v=>v===null))return '这句还有字没选音高';if(li===p.lines.length-1&&![28,35].includes(l.pitches.at(-1)))return '最后一个字请选择灰色标出的 C 音';if(p.level===2&&li===1&&![1,4,6].includes(l.pitches.at(-1)%7))return '试试灰色标出的 G、D 或 B';return '';}
function advanceSentence(li){const p=project(),error=sentenceError(li);if(error){toast(error);return;}if(li===p.lines.length-1){for(let i=0;i<p.lines.length;i++){const issue=sentenceError(i);if(issue){toast(`第 ${i+1} 句：${issue}`);return;}}}mutate(()=>{p.sentenceCompleted[li]=true;p.step=li+1<p.lines.length?4+li:3+p.lines.length;p.maxStep=Math.max(p.maxStep??0,p.step);if(li===p.lines.length-1&&p.level<3)p.complete=true;});stop();selected=null;render();}
function sentenceScoreHTML(editable=true){const p=project(),li=sentenceIndex(p),stage=p.sentenceStages[li]??0,upto=stage===2?li:li-1;if(upto<0)return '';return systemModel(p,Array.from({length:upto+1},(_,i)=>i)).map(row=>scoreRowHTML(row,editable,`前面的旋律${stage===2?'与当前句':''}`)).join('');}

let sentenceGroup=0;
function renderSentence(){
  const p=project(),li=sentenceIndex(p),l=p.lines[li],stage=p.sentenceStages[li]??0,gs=groups(l);sentenceGroup=Math.min(sentenceGroup,gs.length-1);const g=gs[sentenceGroup];
  const sub=['划分歌词节奏','安排歌词节奏','安排歌词音高'];
  let content='';
  if(stage===0)content=`${p.level===1&&li===0?'<p class="sentence-group-intro">这是我的一个概念，我认为歌词中，会有词组的划分，证明它们是一起的。比如如果“是一”“起的”这样划分来创作，会比较怪。所以我自己的习惯会先把一起的词打个包，提醒自己别给它们拆开。一句话由“字”和“词组”作为细胞穿起来。按你的感觉，觉得哪些字“应该”是一组呢？</p>':''}<p class="hint">先划分成每组 1～2 个字。</p><div class="groups-line">${lyricUnits(l.text).map((c,i)=>`<span class="character ${/[A-Za-z]/.test(c)?'english-syllable':''}">${esc(c)}</span>${i<lyricUnits(l.text).length-1?`<button class="divider ${l.cuts[i]?'on':''}" data-sentence-cut="${i}" aria-label="${esc(c)}后${l.cuts[i]?'合并':'分组'}">│</button>`:''}`).join('')}</div>`;
  if(stage===1){
    fillLyricDurations(l,p);
    content=rhythmLessonTape(li,'id="sentenceDrum"');
  }
  const pitchIntro=p.level===1&&li===0&&stage===2?'<p class="sentence-pitch-intro">哈哈～这是传说中的五线谱。你暂时不需要懂它。你只需要知道，往上音就会变高，往下音就会变低。创作过程中，每一个音的音高你都可以反复试听和修改。现在，通过试听和修改，选出你满意的音高就可以～</p>':'';
  $('#stage').innerHTML=heading(stepNames(p)[p.step],l.text,'')+`<div class="sentence-substeps">${sub.map((text,i)=>`<button data-sentence-phase="${i}" class="${i===stage?'active':''}" ${i>stage?'disabled':''}>${['1️⃣','2️⃣','3️⃣'][i]} ${text}</button>`).join('')}</div>`+pitchIntro+(stage===0?'':editingControls())+`<div id="scoreArea">${sentenceScoreHTML()}</div><div class="sentence-work">${content}</div>${p.level>=3&&li>0&&stage===0?`<div class="copy-phrase"><label for="copyPhraseNumber">复制第 <input id="copyPhraseNumber" type="number" min="1" max="${li}" value="${li}" step="1"> 句旋律</label><button id="copyPhrase" class="primary">直接下一步 →</button></div>`:''}<div class="actions">${stage>0?`<button id="sentenceBack">← ${sub[stage-1]}</button>`:''}<button id="sentenceNext" class="primary">${stage<2?'继续：'+sub[stage+1]:li+1<p.lines.length?'下一步：'+stepNames(p)[p.step+1]:'下一步：'+stepNames(p)[p.step+1]} →</button></div>`;
  bindPlayback();
  if(stage>0)$('#playAll').onclick=()=>{
    if(playState)return togglePlay();
    if(stage===1)return playAll(true,li);
    const events=getEvents().filter(e=>e.li<=li);
    if(events.length)playEvents(events);
  };
  $$('[data-sentence-cut]').forEach(b=>b.onclick=()=>{mutate(()=>l.cuts[+b.dataset.sentenceCut]=!l.cuts[+b.dataset.sentenceCut]);render();});
  $$('[data-sentence-phase]').forEach(b=>b.onclick=()=>{mutate(()=>p.sentenceStages[li]=+b.dataset.sentencePhase);render();});
  if($('#sentenceBack'))$('#sentenceBack').onclick=()=>{mutate(()=>p.sentenceStages[li]--);render();};
  if(stage===1){$('#selection')?.remove();$('#sentenceDrum').onclick=()=>playAll(true,li);}
  if($('#copyPhrase'))$('#copyPhrase').onclick=()=>{const source=Number($('#copyPhraseNumber').value)-1;if(!Number.isInteger(source)||source<0||source>=li){toast(`请选择第 1～${li} 句`);return;}const from=p.lines[source];mutate(()=>{l.durations=l.durations.map((_,i)=>from.durations[i]??1);l.pitches=l.pitches.map((_,i)=>from.pitches[i]??null);l.cuts=l.cuts.map((_,i)=>i<from.cuts.length?from.cuts[i]:true);l.staccato=l.pitches.map((_,i)=>!!from.staccato?.[i]);if(from.melody)l.melody=l.pitches.map((_,i)=>from.melody[i]?clone(from.melody[i]):null);else delete l.melody;if(boundedLesson(p))normalizeLessonLine(l,p);markCopyRepairs(l);p.sentenceCompleted[li]=false;p.sentenceStages[li]=2;});stop();selected=null;render();requestAnimationFrame(()=>{const note=document.querySelector(`#scoreArea .note[data-li="${li}"]`);(note?.closest('.score-system')||$('#stage')).scrollIntoView({block:'start',behavior:'smooth'});});};
  $('#sentenceNext').onclick=()=>{if(stage===0){if(gs.some(g=>g.end-g.start>2)){toast('先把这句分成每组 1～2 个字');return;}mutate(()=>{fillLyricDurations(l,p);l.dragRhythm=true;p.sentenceStages[li]=1;});}else if(stage===1){if(l.durations.some(d=>d===null)){toast('这句还有歌词缺少时长');return;}mutate(()=>p.sentenceStages[li]=2);}else{advanceSentence(li);return;}stop();render();};
}
function renderOrderedLesson(){const p=project();if(p.level===2){if(p.step<3)return renderRepeatLesson();return renderFinish();}if(p.step===0){if(p.level>=3)laterMeter();else renderMeter();$('#next').onclick=()=>{if(!(p.level>=3?p.meterChosen:p.meter))return;mutate(()=>p.step=1);render();};return;}if(p.step===1){renderTempo();return;}if(p.step===2){renderMode();$('#next').onclick=()=>{if(!p.mode)return;mutate(()=>p.step=3);render();};return;}if(p.level===2&&p.step>=3&&p.step<=5)return renderRepeatLesson();if(inSentence(p))return renderSentence();if(p.level===3&&p.step===3+p.lines.length)return renderRegroupLesson();if(p.level===4&&p.step===3+p.lines.length){renderStaccato();$('#next').onclick=()=>{for(let li=0;li<p.lines.length;li++){const error=sentenceError(li);if(error){toast(error);return;}}if(!staccatoDone())return;mutate(()=>{p.step=creditStep(p);p.complete=true;});render();};return;}renderFinish();}
function installSentenceFlow(){
  const oldMigrate=migrateV2,oldSteps=stepNames,oldCredit=creditStep,oldScore=scoreHTML,oldStudio=renderStudioStep;
  migrateV2=function(){oldMigrate();for(const key of ['one','two','three','four','five','six','seven','eight','nine','ten','studio'])if(db[key]){migrateSentenceFlow(db[key]);migrateLessonRhythm(db[key]);}};
  stepNames=function(p=project()){if(sentenceLesson(p))return sentenceLabels(p);if(p.level===0&&p.controlOrder===2)return ['选择节拍','选择速度','选择调式','划分歌词节奏','开始创作','完成作品','保存作品'];return oldSteps(p);};
  creditStep=function(p=project()){return sentenceLesson(p)?sentenceCredit(p):oldCredit(p);};
  scoreHTML=function(editable=true){return editable&&inSentence()?sentenceScoreHTML(editable):oldScore(editable);};
  renderStudioStep=function(){const p=project();if(p.controlOrder!==2)return oldStudio();if(p.step===0)return renderStudioMeter();if(p.step===1)return renderTempo();if(p.step===2)return renderStudioMode();if(p.step===3){renderFreeGroups();const stage=$('#stage'),rows=[...stage.querySelectorAll('.groups-line')],grid=document.createElement('div');grid.className='studio-group-grid';rows.forEach(row=>{if(row.querySelectorAll('.character').length>8)row.classList.add('long-phrase');grid.append(row);});stage.querySelector('.section-head').after(grid);return;}if(p.step===4)return renderStudioCompose();renderFinish();};
}

function renderRepeatLesson(){
  const p=project(),title=stepNames(p)[p.step];
  if(p.step===0){
    $('#stage').innerHTML=heading(title,p.step===0?'重复可以让人记忆深刻，尝试下吧～':p.step===1?'作品中的分句，尝试使用这些音增加停顿感～':title,'')+`<div class="poem-transfer"><span>春眠不觉晓，处处闻啼鸟。</span><span>↓ 复制旋律</span><strong>夜来风雨声，花落知多少。</strong></div><button id="copyRepeat" class="primary">${p.repeatedMelody?'已复制旋律':'复制到后两句'}</button>`+editingControls()+`<div id="scoreArea">${scoreHTML()}</div>`;
    bindPlayback();$('#copyRepeat').disabled=!!p.repeatedMelody;
    $('#copyRepeat').onclick=()=>{mutate(()=>{for(let i=0;i<2;i++)p.lines[i+2]={...clone(p.lines[i]),text:POEM[i+2],punct:i===0?'，':'。'};p.repeatedMelody=true;});render();};
    nav(true,'',()=>{if(!p.repeatedMelody)return;mutate(()=>p.step=1);stop();render();});$('#next').disabled=!p.repeatedMelody;return;
  }
  $('#stage').innerHTML=heading(title,p.step===0?'重复可以让人记忆深刻，尝试下吧～':p.step===1?'作品中的分句，尝试使用这些音增加停顿感～':title,'')+editingControls()+`<div id="scoreArea">${scoreHTML()}</div>`;bindPlayback();
  nav(true,'',()=>{if(p.step===1){if(!pitchTaskDone()){toast('试试灰色标出的 G、D 或 B');return;}mutate(()=>p.step=2);}else{const error=validate(p);if(error){toast(error);return;}mutate(()=>{p.step=3;p.complete=true;});}stop();render();});
}

function renderRegroupLesson(){const p=project();$('#stage').innerHTML=heading('整首作品调整','听听你的作品','')+editingControls()+`<div id="scoreArea">${scoreHTML()}</div>`;bindPlayback();nav(true,'完成作品',()=>{const error=validate(p);if(error){toast(error);return;}mutate(()=>{p.step=creditStep(p);p.complete=true;});render();});$('#next').disabled=!!validate(p);}
