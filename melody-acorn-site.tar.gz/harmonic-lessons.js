function harmonicLesson(p=project()){return p&&[26,27].includes(p.level);}
function forceHarmonic(p){if(harmonicLesson(p)){p.tonic='A';p.scale='和声小调';p.mode='A 和声小调';}}
// Two separate attacks at the same G position, never two fragments of a tie.
function harmonicPair(p=project(),restored=false){
 for(const m of measureModel(p)){
  const notes=m.notes.filter(n=>!n.rest&&n.first&&n.p!==null&&n.p%7===4);
  for(let i=0;i<notes.length;i++)for(let j=i+1;j<notes.length;j++){
   const a=notes[i],b=notes[j];if(a.p!==b.p)continue;
   if((a.alter??scorePitchAlter(a.p,p))!==1)continue;
   if((b.alter??scorePitchAlter(b.p,p))!==(restored?0:1))continue;
   if(restored&&noteAlter(p.lines[b.li],b.i,b.si??0)!==0)continue;
   return {first:a,second:b};
  }
 }
 return null;
}
function harmonicScaleSVG(p=project()){
 let svg=studioScaleSVG(p),cursor=85+keySignatureEntries(p).length*17,marks='',first=true;
 const key=studioKeyAccidentals(p);
 for(const pitch of scalePitches(p)){
  const alter=scorePitchAlter(pitch,p),extra=alter!==(key.get(pitch%7)||0);
  if(extra)cursor+=MUSIC_GLYPHS[scaleAccidentalName(alter)].width+5;
  const x=cursor,y=scaleNoteY(pitch);cursor+=38;
  if(pitch%7!==4)continue;
  marks+=`<ellipse class="harmonic-seventh" cx="${x-9}" cy="${y}" rx="26" ry="14" fill="none" stroke="#bd8524" stroke-width="2"/>`;
  if(first){marks+=`<text x="${x}" y="77" text-anchor="middle" font-size="16" fill="#8b641e">和声小调会升高第7个音</text><path d="M${x} 84V${y-19}m-5 -7l5 7 5 -7" fill="none" stroke="#bd8524" stroke-width="2"/>`;first=false;}
 }
 return svg.replace('</svg>',marks+'</svg>');
}
function renderHarmonicMode(){
 const p=project();forceHarmonic(p);
 $('#stage').innerHTML=heading('选择调式','这次试试 a 和声小调～','')+'<div class="mode-fields"><label>主音<select disabled><option>A</option></select></label><label>调式<select disabled><option>和声小调</option></select></label></div>'+`<div class="score-scroll">${harmonicScaleSVG(p)}</div><button id="hearHarmonic">▶ 试听音阶</button>`;
 $('#hearHarmonic').onclick=async()=>{scalePreview=true;try{await playEvents(scalePitches(p).map((pitch,t)=>({t,d:.9,p:pitch})),false,180);}finally{scalePreview=false;}};
 nav(true,'',advanceAdvanced);
}
function renderNaturalLesson(){
 const p=project();$('#stage').innerHTML=heading('添加还原记号','让第二个 G 回到原来的高度吧～','点击框出的第二个 G 音，选择还原号（♮）。还原号把升高的音降回去，把降低的音升回去，回到本位音，所以叫“还原”。')+editingControls()+`<div id="scoreArea">${advancedScoreHTML()}</div>`;bindPlayback();
 nav(true,'',()=>{if(!harmonicPair(p,true)){toast('在同一小节保留第一个升 G，把第二个 G 加上还原号');return;}advanceAdvanced();});$('#next').disabled=!harmonicPair(p,true);
}
function installHarmonicLessons(){
 const oldRender=render,oldChoose=chooseMode,oldModes=modeChoices,oldOrdered=renderOrderedLesson,oldSteps=advancedSteps,oldIssue=sectionComposeIssue,oldHint=cadenceStepReminder,oldSVG=engravingSVG,oldRefresh=refreshScore;
 render=function(){forceHarmonic(project());return oldRender();};
 chooseMode=function(p,name){if(harmonicLesson(p)){forceHarmonic(p);return;}return oldChoose(p,name);};
 modeChoices=p=>harmonicLesson(p)?['和声小调']:oldModes(p);
 advancedSteps=function(p=project()){const steps=oldSteps(p);if(p.level!==27)return steps;const at=steps.findIndex(s=>s.kind==='review');if(at>=0)steps.splice(at,0,{kind:'natural',name:'添加还原记号'});return steps;};
 renderOrderedLesson=function(){const p=project();forceHarmonic(p);if(harmonicLesson(p)&&advancedStep(p).kind==='mode')return renderHarmonicMode();if(p.level===27&&advancedStep(p).kind==='natural')return renderNaturalLesson();return oldOrdered();};
 sectionComposeIssue=function(stage,p=project()){const issue=oldIssue(stage,p);if(issue)return issue;if(p.level===27&&stage===sectionRanges(p).length*2-1&&!harmonicPair(p)&&!harmonicPair(p,true))return '在同一小节写两个同一位置的 G 音，系统会自动升高 G。';return '';};
 cadenceStepReminder=function(k){return [oldHint(k),project().level===27&&advancedStep().kind==='section-compose'?'在同一小节写两个同一位置的 G 音；a 和声小调会自动把它们升高。':''].filter(Boolean).join(' ');};
 refreshScore=function(){oldRefresh();if(project().level===27&&advancedStep().kind==='natural'&&$('#next'))$('#next').disabled=!harmonicPair(project(),true);};
 engravingSVG=function(row,mode='combined',editable=true){let svg=oldSVG(row,mode,editable);const p=project();if(!editable||p.level!==27||!['section-compose','natural'].includes(advancedStep(p).kind))return svg;
 const pair=harmonicPair(p)||harmonicPair(p,true);if(!pair)return svg;
 const marks=[pair.first,pair.second].map((target,i)=>{const n=row.measures.flatMap(m=>m.notes).find(n=>n.first&&n.li===target.li&&n.i===target.i&&n.si===target.si);if(!n)return '';return `<rect class="natural-teaching-target" x="${n.x-27}" y="${noteY(n.p)-19}" width="50" height="40" rx="12" fill="none" stroke="#bd8524" stroke-width="2" pointer-events="none"/>${i===1&&advancedStep(p).kind==='natural'?`<text class="natural-teaching-help" data-hint-li="${n.li}" x="${n.x}" y="110" text-anchor="middle" font-size="13" fill="#8b641e">点击这个 G，添加还原号 ↓</text>`:''}`;}).join('');return svg.replace('</g></svg>',marks+'</g></svg>');};
}
