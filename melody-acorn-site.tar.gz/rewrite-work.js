/* Rewriting is a single undoable edit of the current work, never a new project. */
function rewriteWorkStep(p){
 if(typeof advancedLesson==='function'&&advancedLesson(p)){
  const first=advancedSteps(p).findIndex(step=>step.kind==='pair'||step.kind==='section-compose');
  return first<0?0:Math.min(p.step??0,first);
 }
 if(p.level===2)return 0;
 if(p.level>0)return Math.min(p.step??0,3);
 const first=stepNames(p).indexOf('开始创作');
 return first<0?0:Math.min(p.step??0,first);
}
function clearWorkMusic(p){
 const nextStep=rewriteWorkStep(p);
 p.lines.forEach(line=>{
  const count=lyricUnits(line.text).length;
  line.durations=Array(count).fill(null);
  line.pitches=Array(count).fill(null);
  line.staccato=Array(count).fill(false);
  for(const key of ['melody','restsAfter','accidentals','copyRepairs'])delete line[key];
 });
 for(const key of ['pickupBeats','pickupMeter','pickupDone','sequenceDone','sequenceCopies','sequenceShifts','sectionCopies','regroupDone','accidentalPractice','rhythmBaseline','rhythmFirstBaseline'])delete p[key];
 if(p.level===2)p.repeatedMelody=false;
 p.complete=false;p.creditsConfirmed=false;p.showWholeScore=false;
 p.sentenceStages=p.lines.map(line=>groups(line).every(g=>g.end-g.start<=2)?1:0);
 p.sentenceCompleted=p.lines.map(()=>false);
 if(typeof sectionComposeLesson==='function'&&sectionComposeLesson(p)){
  const first=sectionRanges(p)[0]||[];
  const stage=first.length&&first.every(li=>p.sentenceStages[li]===1)?1:0;
  p.sectionComposeVersion=1;p.sectionComposeStage=stage;p.sectionComposeMaxStage=stage;
 }
 p.step=nextStep;p.maxStep=nextStep;
}
function rewriteWork(){
 const p=project();if(!p||!Array.isArray(p.lines))return;
 stop();
 // mutate records the whole project before any music or progress is cleared.
 mutate(()=>clearWorkMusic(p));
 selected=null;groupIndex=0;
 if(typeof sentenceGroup!=='undefined')sentenceGroup=0;
 if(typeof scoreCheckRequests!=='undefined')scoreCheckRequests.delete(p);
 const modal=$('#modal');if(modal?.open)modal.close();
 render();toast('已清空节奏和旋律，点击“后退”可以恢复');
}
let rewriteWorkInstalled=false;
function installRewriteWork(){
 if(rewriteWorkInstalled)return;
 rewriteWorkInstalled=true;
 const oldRenderEditor=renderEditor;
 renderEditor=function(){
  oldRenderEditor();
  const backup=$('#backup');if(!backup)return;
  let button=$('#rewriteWork');
  if(!button){button=document.createElement('button');button.id='rewriteWork';button.type='button';button.textContent='重写作品';button.title='保留歌词与作品设置，重新写节奏和旋律；可用后退恢复';backup.before(button);}
  button.onclick=rewriteWork;
 };
}
