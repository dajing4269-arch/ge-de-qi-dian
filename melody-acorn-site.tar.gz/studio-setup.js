/* Shared meter/tempo controls and the free composition setup page. */
function mergedStudio(p=project()){return p.level===0&&p.setupVersion===1;}
function migrateStudioSetup(p){if(!p||p.level!==0||p.setupVersion===1)return;const map=[0,0,0,1,2,3,4];const step=p.step,max=p.maxStep??step;p.step=map[step]??0;p.maxStep=Math.max(p.step,map[max]??p.step);p.setupVersion=1;}
// Conventional treble-clef positions, in the only order used by key signatures:
// sharps F5 C5 G5 D5 A4 E5 B4; flats B4 E5 A4 D5 G4 C5 F4.
const TREBLE_KEY_POSITIONS={sharp:[38,35,39,36,33,37,34],flat:[34,37,33,36,32,35,31]};
const MODE_KEY_FIFTHS={
 '大调':0,'自然小调':-3,'和声小调':-3,'旋律小调（上行）':-3,
 '多利亚':-2,'弗里几亚':-4,'利底亚':1,'混合利底亚':-1,'洛克里亚':-5,
 '宫调式（五声）':0,'商调式（五声）':-2,'角调式（五声）':-4,'徵调式（五声）':-1,'羽调式（五声）':-3,
 '宫调式（六声·加清角）':0,'宫调式（六声·加变宫）':0,'清乐宫调式（七声）':0,'雅乐宫调式（七声）':1,'燕乐宫调式（七声）':-1
};
function keySignatureFifths(p){
 const tonic=p.tonic||'C',letter='CDEFGAB'.indexOf(tonic[0]),alter=[...tonic.slice(1)].reduce((n,c)=>n+('♯#'.includes(c)?1:'♭b'.includes(c)?-1:0),0);
 return [0,2,4,-1,1,3,5][letter]+7*alter+(MODE_KEY_FIFTHS[p.scale||'大调']??0);
}
function keySignatureEntries(p){
 const fifths=keySignatureFifths(p),alter=Math.sign(fifths);
 // Rare spellings beyond seven signs retain their written pitches. Any extra
 // alteration is engraved on the affected note, never in an eighth key slot.
 return TREBLE_KEY_POSITIONS[fifths<0?'flat':'sharp'].slice(0,Math.min(7,Math.abs(fifths))).map(pitch=>({pitch,alter}));
}
function studioKeyAccidentals(p){return new Map(keySignatureEntries(p).map(({pitch,alter})=>[pitch%7,alter]));}
function scaleNoteY(pitch){return 178-(pitch-30)*6;}
function scaleAccidentalName(delta){return ({'-2':'accidentalDoubleFlat','-1':'accidentalFlat',0:'accidentalNatural',1:'accidentalSharp',2:'accidentalDoubleSharp'})[delta];}
function scaleKeySignatureSVG(p){
 return `<g class="scale-key-signature" aria-label="调号">${keySignatureEntries(p).map(({pitch,alter},i)=>`<g class="scale-key-accidental" data-pitch="${pitch}" data-alter="${alter}">${glyph(scaleAccidentalName(alter),66+i*17,scaleNoteY(pitch))}</g>`).join('')}</g>`;
}
function studioScaleSVG(p=project()){
 const notes=scalePitches(p),acc=studioKeyAccidentals(p),signature=keySignatureEntries(p);
 let cursor=85+signature.length*17;
 const layout=notes.map(pitch=>{const natural=12*(Math.floor(pitch/7)+1)+SEMI[pitch%7],alter=studioMidi(pitch,p)-natural,extra=alter!==(acc.get(pitch%7)||0),name=extra?scaleAccidentalName(alter):null;if(extra)cursor+=MUSIC_GLYPHS[name].width+5;const x=cursor;cursor+=38;return {pitch,alter,extra,name,x,y:scaleNoteY(pitch)};});
 const w=cursor,mark=d=>d===2?'𝄪':d===-2?'𝄫':d>0?'♯':d<0?'♭':'';
 let s=`<svg class="mode-scale" viewBox="0 55 ${w} 215" role="img" aria-label="${esc(studioModeLabel(p))}音阶，调号位于高音谱号右侧" xmlns="http://www.w3.org/2000/svg">`;
 for(let y=130;y<=178;y+=12)s+=`<path d="M15 ${y}H${w-10}" stroke="#a4af9a"/>`;s+=glyph('clef',28,scaleNoteY(32))+scaleKeySignatureSVG(p);
 for(const {pitch,alter,extra,name,x,y} of layout){
  for(let ly=190;ly<=y;ly+=12)s+=`<path d="M${x-12} ${ly}h24" stroke="#365b45"/>`;for(let ly=118;ly>=y;ly-=12)s+=`<path d="M${x-12} ${ly}h24" stroke="#365b45"/>`;
  if(extra)s+=`<g class="scale-note-accidental" data-pitch="${pitch}" data-alter="${alter}">${glyph(name,x-MUSIC_GLYPHS.whole.width/2-5-MUSIC_GLYPHS[name].width,y)}</g>`;
  s+=`<g class="scale-note" data-pitch="${pitch}">${glyph('whole',x-MUSIC_GLYPHS.whole.width/2,y)}</g><text x="${x}" y="244" text-anchor="middle" font-size="11">${NAMES[pitch%7]}${mark(alter)}${Math.floor(pitch/7)}</text>`;
 }
 return s+'</svg>';
}
function meterTempoEvents(meter){
 const [n,d]=meter.split('/').map(Number),unit=4/d,compound=d===8&&n>3&&n%3===0;
 return Array.from({length:n*4},(_,i)=>{const beat=i%n;return {t:i*unit,d:Math.min(.25,unit*.8),p:28,kit:beat===0?'kick':compound&&beat%3===0||!compound&&n===4&&beat===2?'snare':'hat',preview:'meter-tempo'};});
}
function previewMeterTempo(meter=project().meter||'4/4',bpm=project().bpm){return playEvents(meterTempoEvents(meter),true,bpm);}
function meterTempoHTML(p,{meters,tempos,custom=false,title=true}){
 const meter=p.meter||'4/4';
 return `<section class="initial-section meter-tempo-panel" aria-label="节拍和速度">${title?'<h3>节拍和速度</h3>':''}<div class="meter-tempo-row"><span class="meter-tempo-label">节拍</span><div class="meter-tempo-options"><div class="meter-tempo-presets">${meters.map(m=>`<button data-initial-meter="${m}" class="${meter===m?'primary':''}" aria-pressed="${meter===m}">${m} 拍</button>`).join('')}</div>${custom?`<div class="custom-meter compact-custom-meter"><span>自定：</span><input id="initialMeterN" aria-label="节拍分子" type="number" min="1" max="32" value="${meterParts(p)[0]}"><span>/</span><select id="initialMeterD" aria-label="节拍分母">${[2,4,8,16].map(d=>`<option ${meterParts(p)[1]===d?'selected':''}>${d}</option>`).join('')}</select><span>拍</span><button id="useInitialMeter">使用</button></div>`:''}</div></div><div class="meter-tempo-row"><span class="meter-tempo-label">速度</span><div class="meter-tempo-options"><div class="initial-tempos">${tempos.map(b=>`<button data-initial-bpm="${b}" class="${p.bpm===b?'primary':''}" aria-pressed="${p.bpm===b}">♩ = ${b}</button>`).join('')}</div>${custom?`<label class="custom-bpm">自定义 BPM <input id="initialBpm" type="number" min="30" max="240" value="${p.bpm}"></label>`:''}</div></div><div class="meter-tempo-preview"><button id="hearMeterTempo">▶ 试听 ${esc(meter)} 拍 · ♩ = ${p.bpm}</button></div></section>`;
}
function bindMeterTempo(p,{custom=false,onMeterChange=()=>{}}={}){
 const update=fn=>{stop();mutate(fn);render();};
 const setMeter=meter=>update(()=>{if(p.meter!==meter){p.meter=meter;onMeterChange();}p.meterChosen=true;});
 $$('[data-initial-meter]').forEach(b=>b.onclick=()=>setMeter(b.dataset.initialMeter));
 $$('[data-initial-bpm]').forEach(b=>b.onclick=()=>update(()=>p.bpm=+b.dataset.initialBpm));
 if(custom){
  $('#useInitialMeter').onclick=()=>{const n=+$('#initialMeterN').value;if(!Number.isInteger(n)||n<1||n>32){toast('分子请输入 1～32 的整数');return;}setMeter(n+'/'+$('#initialMeterD').value);};
  $('#initialBpm').onchange=()=>{const value=+$('#initialBpm').value;if(!Number.isFinite(value)||value<30||value>240){toast('BPM 请输入 30～240');$('#initialBpm').value=p.bpm;return;}update(()=>p.bpm=value);};
 }
 $('#hearMeterTempo').onclick=()=>{if(playState?.events?.[0]?.preview==='meter-tempo')stop();else previewMeterTempo(p.meter,p.bpm);};
}
function renderStudioSetup(){const p=project();
 $('#stage').innerHTML=heading('设置作品初始信息','设置作品初始信息','')+meterTempoHTML(p,{meters:['4/4','3/4','2/4','6/8'],tempos:[60,72,80,92,108,120,144,160],custom:true})+`<section class="initial-section initial-mode"><h3>选择调式</h3><div class="mode-fields"><label>主音<select id="initialTonic">${Object.keys(STUDIO_TONICS).map(t=>`<option ${t===p.tonic?'selected':''}>${t}</option>`).join('')}</select></label><label>调式<select id="initialScale">${Object.keys(STUDIO_MODES).map(m=>`<option value="${esc(m)}" ${m===p.scale?'selected':''}>${modeDisplayName(m)}</option>`).join('')}</select></label></div><p class="hint">不同调式给人不同的感觉，选择调式后，相邻的音连续向上，向下走会产生“音阶片段”，让“调”的特征更加明确。</p><div class="score-scroll">${studioScaleSVG(p)}</div><button id="hearInitialScale">▶ 试听音阶</button></section>`;
 bindMeterTempo(p,{custom:true});
 const update=fn=>{stop();mutate(fn);render();};
 $('#initialTonic').onchange=e=>update(()=>{p.tonic=e.target.value;chooseMode(p,p.scale);});$('#initialScale').onchange=e=>update(()=>chooseMode(p,e.target.value));
 $('#hearInitialScale').onclick=async()=>{scalePreview=true;try{await playEvents(scalePitches(p).map((pitch,t)=>({t,d:.9,p:pitch})),false,180);}finally{scalePreview=false;}};
 nav(false,'',()=>{mutate(()=>{p.meter??='4/4';chooseMode(p,p.scale);p.step=1;});stop();render();});
}
function studioPhraseTools(li,editable=true){
 if(!editable)return `<div class="phrase-buttons"><button data-play-line="${li}">▶ 第 ${li+1} 句</button></div>`;
 const p=project(),section=sectionRanges(p).findIndex(a=>a[0]===li),count=p.lines.length,free=p.level===0,locked=!free&&advancedStep(p).kind==='pair'&&sequencePending(li);
 const phraseCopy=!locked&&(free||li>0)?`<div class="copy-phrase"><label>复制第 <input data-copy-source="${li}" aria-label="第 ${li+1} 句的复制来源" type="number" min="1" max="${free?count:li}" value="${li?li:Math.min(2,count)}"> 句旋律</label><button data-copy-phrase="${li}" ${count<2?'disabled':''}>复制</button></div>`:'';
 const teaching=!free&&advancedStep(p)?.kind==='repeat'&&advancedStep(p).section===section;
 const sectionCopy=!locked&&section>0?`<div class="studio-section-copy copy-phrase ${teaching?'paragraph-copy-target':''}"><label>复制第 <input data-section-source="${section}" type="number" min="1" max="${section}" value="${section}"> 段旋律</label><button data-copy-section="${section}">复制</button></div>`:'';
 return `<div class="studio-phrase-tools aligned-phrase-tools"><div class="studio-phrase-play"><button data-play-line="${li}">▶ 第 ${li+1} 句</button></div><div class="aligned-action-row"><div>${phraseCopy}</div><button data-regroup-line="${li}">调整第 ${li+1} 句歌词划分</button></div><div class="aligned-action-row"><div>${sectionCopy}${teaching?'<p class="paragraph-copy-hint">歌词字数一致时，新的一段可以选择复制之前一段全部的旋律</p>':''}</div><div class="phrase-shift ${locked?'sequence-focus':''}"><button data-shift-line="${li}" data-direction="1" aria-label="第 ${li+1} 句整句上移">↑</button><button data-shift-line="${li}" data-direction="-1" aria-label="第 ${li+1} 句整句下移">↓</button></div></div></div>`;
}
function installStudioSetup(){
 const oldMigrate=migrateV2,oldSteps=stepNames,oldCredit=creditStep,oldStudio=renderStudioStep,oldButtons=phraseButtons,oldBind=bindScore,oldControls=phraseControls;
 migrateV2=function(){oldMigrate();migrateStudioSetup(db.studio);};
 stepNames=function(p=project()){return mergedStudio(p)?['设置作品初始信息','划分歌词节奏','开始创作','完成作品','保存作品']:oldSteps(p);};
 creditStep=function(p=project()){return mergedStudio(p)?3:oldCredit(p);};
 renderStudioStep=function(){const p=project();if(!mergedStudio(p))return oldStudio();if(p.step===0)return renderStudioSetup();if(p.step===1){renderFreeGroups();const stage=$('#stage'),rows=[...stage.querySelectorAll('.groups-line')],grid=document.createElement('div');grid.className='studio-group-grid';rows.forEach(row=>{if(row.querySelectorAll('.character').length>8)row.classList.add('long-phrase');grid.append(row);});stage.querySelector('.section-head').after(grid);return;}if(p.step===2){renderStudioCompose();$('#next').onclick=()=>{mutate(()=>{p.step=3;p.complete=true;p.creditsConfirmed=false;});stop();render();};return;}renderFinish();if($('#creditBack'))$('#creditBack').onclick=()=>{mutate(()=>p.step=2);stop();render();};};
 phraseControls=function(row,editable=true){if(project().level!==0&&!advancedLesson())return oldControls(row,editable);return [...new Set(row.measures.filter(m=>m.bar===0).map(m=>m.li))].map(li=>{const ms=row.measures.filter(m=>m.li===li),start=ms[0]===row.measures[0]?15:ms[0].x,end=ms.at(-1).x+ms.at(-1).width;return `<div class="phrase-control-slot" data-phrase-controls="${li}" style="left:${start/row.width*100}%;width:${(end-start)/row.width*100}%">${phraseButtons(li,editable)}</div>`;}).join('');};
 phraseButtons=function(li,editable=true){return project().level===0||advancedLesson()?studioPhraseTools(li,editable):oldButtons(li,editable);};
 bindScore=function(){oldBind();if(project().level!==0){if(advancedLesson())bindAdvancedCopies();
 if(paragraphCopyPending()){
  selected=null;const area=$('#scoreArea'),target=advancedStep().section;
  if(area?.querySelectorAll){area.querySelectorAll('button,input').forEach(el=>{if(!el.matches(`[data-copy-section="${target}"],[data-section-source="${target}"],[data-play-line]`))el.disabled=true;});
   for(const event of ['pointerdown','click','contextmenu','keydown'])area.addEventListener(event,e=>{if(!e.target.closest(`[data-copy-section="${target}"],[data-section-source="${target}"],[data-play-line]`)){e.preventDefault();e.stopImmediatePropagation();}},true);
  }
 }
 return;}$$('[data-copy-phrase]').forEach(b=>b.onclick=()=>{const p=project(),li=+b.dataset.copyPhrase,source=+$(`[data-copy-source="${li}"]`).value-1;if(!Number.isInteger(source)||source<0||source>=p.lines.length||source===li){toast('请选择作品中的其他一句');return;}mutate(()=>copyPhraseData(p.lines[source],p.lines[li]));stop();render();});};
}
