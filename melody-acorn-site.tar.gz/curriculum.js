/* Ten-lesson curriculum. Shared controls also serve the free composition editor. */
const NEW_LESSONS={
  5:{title:'登鹳雀楼',author:'王之涣',lines:['白日依山尽','黄河入海流','欲穷千里目','更上一层楼']},
  6:{title:'纸飞机',author:'Chat gpt',lines:['纸飞机飞得高','顺着微风轻轻飘','碰到树叶摇一摇','逗得爸爸眯眼笑']},
  7:{title:'望庐山瀑布',author:'李白',lines:['日照香炉生紫烟','遥看瀑布挂前川','飞流直下三千尺','疑是银河落九天']},
  8:{title:'月下',author:'Chat gpt',lines:['窗前月色微微凉','一封家书读几行','忽听远处笛声起','梦里又闻稻花香']},
  9:{title:'静夜思',author:'李白',lines:['床前明月光','疑是地上霜','举头望明月','低头思故乡']},
  10:{title:'早发白帝城',author:'李白',lines:['朝辞白帝彩云间','千里江陵一日还','两岸猿声啼不住','轻舟已过万重山']}
};
const MODE_DEGREES={
 '宫调式（五声）':[0,1,2,4,5],'商调式（五声）':[0,1,3,4,6],'角调式（五声）':[0,2,3,5,6],'徵调式（五声）':[0,1,3,4,5],'羽调式（五声）':[0,2,3,4,6],
 '宫调式（六声·加清角）':[0,1,2,3,4,5],'宫调式（六声·加变宫）':[0,1,2,4,5,6]
};
function curriculum(p=project()){return p.curriculumVersion===1;}
function modeDegrees(p=project()){return MODE_DEGREES[p.scale]||[0,1,2,3,4,5,6];}
function modeAllowed(pitch,p=project()){const letter=STUDIO_TONICS[p.tonic||'C'][0];return modeDegrees(p).includes(((pitch-letter)%7+7)%7);}
function snapModePitch(pitch,direction=0,p=project()){
 if(!curriculum(p)&&p.level!==0)return pitch;
 if(modeAllowed(pitch,p))return pitch;
 for(let d=1;d<7;d++){if(direction>=0&&modeAllowed(pitch+d,p))return pitch+d;if(direction<=0&&modeAllowed(pitch-d,p))return pitch-d;}return pitch;
}
function endingPitches(p=project()){return p.tonic==='A'?[26,33,40]:[28,35];}
function middleDegrees(p=project()){return p.level===9?[2,4]:[8,9,10].includes(p.level)&&p.tonic==='A'?[2,4,6]:p.level===2?[1,4,6]:[];}
function endingIssue(p,li){const l=p.lines[li];if(li===p.lines.length-1&&!endingPitches(p).includes(l.pitches.at(-1)))return `最后一个字请选择灰色标出的 ${p.tonic||'C'} 音`;const middle=middleDegrees(p);if(li===1&&middle.length&&!middle.includes(l.pitches.at(-1)%7))return `中间的停顿试试 ${middle.map(d=>NAMES[d]).join('／')} 音`;return '';}
function operationName(p){return p.level===3?'更改歌词划分':p.level===4?'加入跳音':'自由修改';}
function lessonBudget(p=project()){return Infinity;}
function lessonGroupLimit(p=project()){return p.meter==='3/4'?3:2;}
function triplePhraseBeats(l,p){const first=p.lines[0],ready=first.durations.every(d=>d!==null),total=first.durations.reduce((s,d)=>s+(d??.5),0);const base=ready&&total<=6?6:12;return Math.max(base,Math.ceil(l.durations.reduce((s,d)=>s+(d??.5),0)/3)*3);}
function xiaoMode(p=project()){return /五声|六声|七声/.test(p.scale||'');}
let scalePreview=false;
function scalePitches(p=project()){const [letter,semitone]=STUDIO_TONICS[p.tonic||'C'];const root=(60+semitone>66?21:28)+letter,degrees=modeDegrees(p),up=[...degrees,...degrees.map(d=>d+7),14].map(d=>root+d);return [...up,...up.slice(0,-1).reverse()];}
function modeScaleSVG(p=project()){return studioScaleSVG(p);}
function modeChoices(p){if(p.level===0)return Object.keys(STUDIO_MODES);if(p.level<=4)return ['大调'];if(p.level===5)return ['大调','宫调式（五声）'];if(p.level===8)return ['自然小调'];if(p.level===9)return ['羽调式（五声）'];return p.level===10?['大调','宫调式（五声）','自然小调','羽调式（五声）']:['大调','宫调式（五声）'];}
function chooseMode(p,name){p.scale=name;if(p.level)p.tonic=['自然小调','羽调式（五声）'].includes(name)?'A':'C';p.mode=studioModeLabel(p);p.lines.forEach(l=>{l.pitches.forEach((v,i)=>{if(v!==null)l.pitches[i]=snapModePitch(v,0,p);});Object.values(l.melody||{}).forEach(parts=>parts?.forEach(n=>{if(n.p!==null)n.p=snapModePitch(n.p,0,p);}));});}
function markRequiredChoice(control, instruction){
 const hint=document.createElement('span');
 hint.className='required-choice-hint';
 hint.id='required-choice-hint';
 hint.textContent=instruction;
 control.setAttribute('aria-describedby',hint.id);
 const wrap=document.createElement('span');
 wrap.className='required-choice-wrap';
 control.before(wrap);
 wrap.append(control,hint);
}
function renderCurriculumMode(){
 const p=project(),choices=modeChoices(p),title=p.level===5?'尝试做个“中国味道”的旋律吧':p.level===8?'听听 a 小调的旋律':p.level===9?'再试试 a 羽五声调式':p.level===0?'选个你喜欢的调式':p.level<=4?'这次我们就选C大调啦':'选个你喜欢的调式';
 const info=p.level===5||p.level===9||xiaoMode(p)?`<p>${esc(studioModeLabel(p))}包含 ${modeDegrees(p).length} 个音（一个八度）。选择后，旋律创作中只能使用这些音。</p>`:p.level===8?'<p>a 小调的音是 A、B、C、D、E、F、G。听听从 A 出发，再回到 A 的感觉。</p><p>之前我们一直是C调，所以结束在C，现在是A调所以结束在A音。</p>':'';
 $('#stage').innerHTML=heading('选择调式',title,'不同调式给人不同的感觉，选择调式后，相邻的音连续向上，向下走会产生“音阶片段”，让“调”的特征更加明确。')+`<div class="mode-fields"><label>主音<select id="modeTonic" ${p.level?'disabled':''}>${Object.keys(STUDIO_TONICS).map(t=>`<option ${t===(p.tonic||'C')?'selected':''}>${t}</option>`).join('')}</select></label><label>调式<select id="modeScale">${choices.map(name=>`<option value="${esc(name)}" ${name===p.scale?'selected':''}>${modeDisplayName(name)}</option>`).join('')}</select></label></div><div class="mode-info">${info}</div><div class="score-scroll">${modeScaleSVG(p)}</div><button id="hearMode">▶ 试听音阶</button>`;
 $('#modeTonic').onchange=e=>{stop();mutate(()=>{p.tonic=e.target.value;chooseMode(p,p.scale);});render();};$('#modeScale').onchange=e=>{stop();mutate(()=>chooseMode(p,e.target.value));render();};$('#hearMode').onclick=async()=>{scalePreview=true;try{await playEvents(scalePitches(p).map((v,i)=>({t:i,d:.9,p:v})),false,180);}finally{scalePreview=false;}};
 nav(true,'',()=>{if(p.level===5&&p.scale!=='宫调式（五声）'){toast('这次选择宫调式，试试五声的声音');return;}mutate(()=>{chooseMode(p,p.scale);p.step=p.level===0?3:3;});stop();render();});$('#next').disabled=p.level===5&&p.scale!=='宫调式（五声）';
 if($('#next').disabled)markRequiredChoice($('#modeScale'),'打开下拉菜单，选择「宫调式（五声）」。');
}
function renderCurriculumMeter(){const p=project(),choices=p.level<6?['4/4']:['4/4','3/4'];$('#stage').innerHTML=heading('选择节拍',p.level===6?'感受一下三拍子的律动':p.level<6?'这次帮你选好4/4拍啦':'选个你想要的节拍',p.level===1?'不同的节拍会产生不同的强弱组合。当然～我们现在只需要知道，这是一首曲子需要有的一个“数”。之后我们将在创作能力愈发精进的过程中，慢慢解锁不同节拍，来体验不同节拍的魅力。':'')+`<div class="choices">${choices.map(m=>`<button data-curriculum-meter="${m}" class="${p.meter===m?'primary':''}">${m} 拍</button>`).join('')}</div>`+(p.level===6?'<p>前面我们用的4/4拍，听起来是：强、弱、次强、弱，会比较平稳。</p><p>3/4拍的律动不同，是：强、弱、弱，会更有跳跃感，舞曲中经常使用这种节拍。</p><p>下面可以播放试听一下他们的区别～</p><div class="actions meter-preview-actions"><button id="hearFour">▶ 4/4 拍</button><button id="hearThree">▶ 3/4 拍</button></div>':'');
 $$('[data-curriculum-meter]').forEach(b=>b.onclick=()=>{mutate(()=>{p.meter=b.dataset.curriculumMeter;p.meterChosen=true;p.lines.forEach(l=>normalizeLessonLine(l,p));});stop();render();});if(p.level===6){$('#hearFour').onclick=()=>previewMeter(4);$('#hearThree').onclick=()=>previewMeter(3);}nav(false,'',()=>{if(p.level===6&&p.meter!=='3/4'){toast('这次选择3/4拍，感受三拍子的律动');return;}mutate(()=>{p.meterChosen=true;p.step=1;});stop();render();});$('#next').disabled=p.level===6&&p.meter!=='3/4';if($('#next').disabled)markRequiredChoice($('[data-curriculum-meter="3/4"]'),'点选「3/4 拍」。');}
function previewMeter(beats){const events=[];for(let bar=0;bar<4;bar++)for(let i=0;i<beats;i++){const t=bar*beats+i;events.push({t,d:.25,p:28,kit:i===0?'kick':beats===4&&i===2?'snare':'hat'});}return playEvents(events,true,100);}
function renderOperation(){const p=project();if(p.level===3)return renderRegroupLesson();const jump=p.level===4;$('#stage').innerHTML=heading(operationName(p),jump?'让「滴滴答答」跳起来':'最后看看有哪里需要调整～','')+editingControls()+`<div id="scoreArea">${scoreHTML()}</div>`;bindPlayback();nav(true,'完成作品',()=>{const error=validate(p);if(error){toast(error);return;}if(jump&&!staccatoDone()){toast('给「滴滴答答」四个音符加入跳音点');return;}mutate(()=>{p.complete=true;p.step=creditStep(p);});stop();render();});}
function synthXiao(ctx,dest,time,duration,pitch){const freq=440*2**((midi(pitch)-69)/12),gain=ctx.createGain();gain.gain.setValueAtTime(0,time);gain.gain.linearRampToValueAtTime(.16,time+.045);gain.gain.setValueAtTime(.13,time+Math.max(.05,duration-.04));gain.gain.linearRampToValueAtTime(0,time+duration+.09);gain.connect(dest);[1,2,3].forEach((h,i)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=freq*h;g.gain.value=[1,.18,.07][i];o.connect(g).connect(gain);o.start(time);o.stop(time+duration+.1);});const b=ctx.createBuffer(1,Math.ceil((duration+.1)*ctx.sampleRate),ctx.sampleRate),data=b.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*.11;const noise=ctx.createBufferSource(),filter=ctx.createBiquadFilter();noise.buffer=b;filter.type='bandpass';filter.frequency.value=1200;filter.Q.value=.8;noise.connect(filter).connect(gain);noise.start(time);noise.stop(time+duration+.1);}
function synthKit(ctx,dest,time,kind){const g=ctx.createGain();g.connect(dest);g.gain.setValueAtTime(kind==='kick'?.65:kind==='snare'?.25:.10,time);g.gain.exponentialRampToValueAtTime(.001,time+(kind==='kick'?.25:.12));if(kind==='kick'){const o=ctx.createOscillator();o.frequency.setValueAtTime(130,time);o.frequency.exponentialRampToValueAtTime(45,time+.16);o.connect(g);o.start(time);o.stop(time+.3);}else{const b=ctx.createBuffer(1,Math.ceil(ctx.sampleRate*.18),ctx.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;const n=ctx.createBufferSource(),f=ctx.createBiquadFilter();n.buffer=b;f.type='highpass';f.frequency.value=kind==='hat'?6500:1200;n.connect(f).connect(g);n.start(time);n.stop(time+.18);}}
function installCurriculum(){
 CHAPTER_KEYS.push('five','six','seven','eight','nine','ten');for(let n=5;n<=10;n++)CHAPTER_TITLES[n]=NEW_LESSONS[n].title;
 Object.assign(STUDIO_MODES,{'宫调式（六声·加清角）':[0,2,4,5,7,9],'宫调式（六声·加变宫）':[0,2,4,7,9,11],'清乐宫调式（七声）':[0,2,4,5,7,9,11],'雅乐宫调式（七声）':[0,2,4,6,7,9,11],'燕乐宫调式（七声）':[0,2,4,5,7,9,10]});
 const oldStart=startChapter,oldMigrate=migrateV2,oldAllowed=allowed,oldLineBeats=lineBeats,oldPatterns=lessonPatterns,oldNormalize=normalizeLessonLine,oldValidate=validate,oldSentenceError=sentenceError,oldRender=renderOrderedLesson,oldSound=sound,oldModeLabel=studioModeLabel,oldPlay=playEvents;
 currentChapter=()=>{for(let n=1;n<=10;n++)if(!db[CHAPTER_KEYS[n]]?.complete)return n;return 10;};
 startChapter=function(n){if(n<5)return oldStart(n);if(n>10)return;const key=CHAPTER_KEYS[n];if(!db[key]){const content=NEW_LESSONS[n],p=fresh(n,content.lines);Object.assign(p,{title:content.title,lyricist:content.author,meter:'4/4',barsPerRow:'auto-phrases',layoutVersion:4,maxStep:0,uiVersion:2,sentenceFlow:1});p.lines.forEach((l,i)=>{l.cuts=l.cuts.map((_,j)=>(j+1)%2===0);l.punct=i%2?'。':'，';});db[key]=p;}start(key);};
 migrateV2=function(){oldMigrate();for(const key of [...CHAPTER_KEYS.slice(1),'studio']){const p=db[key];if(!p)continue;if(p.level>=5){migrateSentenceFlow(p);migrateLessonRhythm(p);}if(!curriculum(p)){p.curriculumVersion=1;p.tonic=p.level===8||p.level===9?'A':p.tonic||'C';p.scale=p.level===8?'自然小调':p.level===9?'羽调式（五声）':p.scale||'大调';if(p.level>0&&p.level<=5)p.meter='4/4';if(p.level===5&&p.step>2)p.scale='宫调式（五声）';p.mode=studioModeLabel(p);if(p.level>0){p.lines.forEach(l=>normalizeLessonLine(l,p));chooseMode(p,p.scale);}}}};
 studioModeLabel=p=>{p??=project();return curriculum(p)||p.level===0?(p.tonic||'C')+' '+modeDisplayName(p.scale||'大调'):oldModeLabel(p);};
 studioMidi=function(pitch,p){const [letter,root]=STUDIO_TONICS[p.tonic||'C'],degree=((pitch-letter)%7+7)%7,oct=Math.floor((pitch-letter)/7),degrees=modeDegrees(p),scale=STUDIO_MODES[p.scale||'大调'],idx=degrees.indexOf(degree);return 12*(oct+1)+root+(idx>=0?scale[idx]:SEMI[degree]);};
 allowed=function(li,i,pitch){return oldAllowed(li,i,pitch)&&(!(curriculum()||project().level===0)||modeAllowed(pitch));};
 lessonPatterns=function(n,p=project()){if(!curriculum(p))return oldPatterns(n);const out=[],limit=lessonGroupLimit(p);function add(ds,total){if(ds.length===n){out.push(ds);return;}for(let d=.5;d<=limit;d+=.5)if(total+d<=limit)add([...ds,d],total+d);}add([],0);const rarity=ds=>{const total=ds.reduce((s,d)=>s+d,0);return (ds.includes(2.5)||total===2.5?100:0)+ds.reduce((s,d)=>s+(d===1?0:d===.5||d===2?1:d===3?2:4),0);};return out.sort((a,b)=>rarity(a)-rarity(b));};
 normalizeLessonLine=function(l,p){if(l.dragRhythm)return;if(!curriculum(p))return oldNormalize(l,p);for(const g of groups(l)){const ds=l.durations.slice(g.start,g.end);if(ds.every(d=>d===null))continue;const opts=lessonPatterns(g.end-g.start,p);if(!opts.length)continue;const best=opts.sort((a,b)=>a.reduce((s,d,i)=>s+Math.abs(d-(ds[i]??.5)),0)-b.reduce((s,d,i)=>s+Math.abs(d-(ds[i]??.5)),0))[0];best.forEach((d,j)=>l.durations[g.start+j]=d);}while(l.durations.reduce((s,d)=>s+(d??.5),0)>lessonBudget(p)){const i=l.durations.findLastIndex(d=>d>.5);if(i<0)break;l.durations[i]-=.5;}};
 lineBeats=function(l,p=project()){if(curriculum(p)&&p.level>0)return p.meter==='3/4'?triplePhraseBeats(l,p):8;return oldLineBeats(l,p);};
 validate=function(p){if(!curriculum(p)||p.level===0)return oldValidate(p);for(let li=0;li<p.lines.length;li++){const l=p.lines[li];if(l.durations.some(d=>d===null)||!l.dragRhythm&&groups(l).some(g=>!lessonPatterns(g.end-g.start,p).some(ds=>JSON.stringify(ds)===JSON.stringify(l.durations.slice(g.start,g.end))))||l.durations.reduce((s,d)=>s+d,0)>lessonBudget(p))return '请检查本句歌词的时长';if(l.pitches.some(v=>v===null))return '还有字没选音高';if(l.pitches.some(v=>!modeAllowed(v,p)))return '请使用当前调式中的音';const issue=endingIssue(p,li);if(issue)return issue;}return '';};
 sentenceError=function(li){if(!curriculum())return oldSentenceError(li);const p=project(),l=p.lines[li];if(groups(l).some(g=>g.end-g.start>2))return '先把这句分成每组 1～2 个字';if(l.durations.some(d=>d===null))return '这句还有歌词缺少时长';if(l.pitches.some(v=>v===null))return '这句还有字没选音高';return endingIssue(p,li);};
 sentenceLabels=function(p){if(p.level===2)return ['旋律的重复','中间的停顿','整首作品调整','完成作品','保存作品'];return ['选择节拍','选择速度','选择调式',...p.lines.map((_,i)=>`创作第${['一','二','三','四'][i]||i+1}句旋律`),...(p.level>=3?[operationName(p)]:[]),'完成作品','保存作品'];};
 sentenceCredit=p=>p.level===2?3:3+p.lines.length+(p.level>=3?1:0);
 renderOrderedLesson=function(){const p=project();if(p.level===2)return oldRender();if(p.step===0)return renderCurriculumMeter();if(p.step===2)return renderCurriculumMode();if(p.level>=3&&p.step===7)return renderOperation();return oldRender();};
 renderStudioMode=renderCurriculumMode;
 staccatoDone=(p=project())=>[0,1,2,3].every(i=>p.lines[1].staccato?.[i]);
 playEvents=function(events,drum=false,bpm=project().bpm,preview=null,fromBeat=0){return scalePreview&&!drum?playLegatoScale(events,bpm):oldPlay(events,drum,bpm,preview,fromBeat);};
 sound=function(ctx,dest,time,duration,pitch,drum=false,beat){if(typeof drum==='string')return synthKit(ctx,dest,time,drum);if(!drum&&(scalePreview||xiaoMode()))return synthXiao(ctx,dest,time,duration,pitch);return oldSound(ctx,dest,time,duration,pitch,drum,beat);};
}

// A single breath and continuous oscillators: pitch changes do not retrigger the envelope.
function synthLegatoScale(ctx,dest,time,events,beat){
 const total=(events.at(-1).t+1)*beat,voice=ctx.createGain();voice.gain.setValueAtTime(0,time);voice.gain.linearRampToValueAtTime(.14,time+.06);voice.gain.setValueAtTime(.14,time+total);voice.gain.linearRampToValueAtTime(0,time+total+.14);voice.connect(dest);
 [1,2,3].forEach((h,i)=>{const osc=ctx.createOscillator(),g=ctx.createGain();g.gain.value=[1,.18,.07][i];events.forEach((e,j)=>{const t=time+e.t*beat,f=440*2**((midi(e.p)-69)/12)*h;if(!j)osc.frequency.setValueAtTime(f,t);else{const previous=440*2**((midi(events[j-1].p)-69)/12)*h;osc.frequency.setValueAtTime(previous,t);osc.frequency.exponentialRampToValueAtTime(f,t+.015);}});osc.connect(g).connect(voice);osc.start(time);osc.stop(time+total+.16);});
 const buffer=ctx.createBuffer(1,Math.ceil((total+.16)*ctx.sampleRate),ctx.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*.09;const breath=ctx.createBufferSource(),filter=ctx.createBiquadFilter();breath.buffer=buffer;filter.type='bandpass';filter.frequency.value=1200;filter.Q.value=.8;breath.connect(filter).connect(voice);breath.start(time);breath.stop(time+total+.16);return total;
}
async function playLegatoScale(events,bpm=180){
 stop();
 if(!events.length)return;
 const request=playRequest,ctx=await readyPlayback(request);
 if(!ctx||request!==playRequest)return;
 const gain=ctx.createGain(),start=ctx.currentTime+.04;
 gain.gain.value=.65;
 gain.connect(ctx.destination);
 const total=synthLegatoScale(ctx,gain,start,events,60/bpm);
 playState={gain,events,drum:false,bpm,start,total:total+.16,paused:false,timers:[]};
 schedulePlayTimers(playState);
 updatePlay();
}

// These cues describe the same ending requirements used by validation.
function cadenceRequirement(p,li){if(!p.level)return null;if(li===p.lines.length-1)return {names:p.tonic||'C',ending:true};const degrees=middleDegrees(p);return li===1&&degrees.length?{names:degrees.map(d=>NAMES[d]).join('／'),ending:false}:null;}
function cadenceStepReminder(k){const p=project();if(!p.level||p.level===12&&k==='自由修改')return '';let ids=[];if(k.startsWith('创作')){if(advancedLesson(p))ids=advancedStep(p).lines||[];else ids=[sentenceIndex(p)];}else if(['写出旋律','中间的停顿','整首作品调整','更改歌词划分','自由修改','加入跳音','旋律的模进','一字多音','整段重复','整段重复与微调'].includes(k)){ids=advancedLesson(p)&&advancedStep(p).lines?advancedStep(p).lines:p.lines.map((_,i)=>i);}return ids.map(li=>{const rule=cadenceRequirement(p,li);if(!rule)return '';return `第 ${li+1} 句最后的「${lyricUnits(p.lines[li].text).at(-1)}」${rule.ending?'请回到':'请停在'} ${rule.names} 音，调整乐谱中框出的最后一个音。`;}).filter(Boolean).join(' ');}
function isCadenceNote(p,n){return !!cadenceRequirement(p,n.li)&&n.i===p.lines[n.li].pitches.length-1&&n.last&&(n.si??0)===(p.lines[n.li].melody?.[n.i]?.length??1)-1;}
