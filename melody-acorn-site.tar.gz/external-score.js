// External scores are opened locally, independently of the current composition.
const scoreLibraries=new Map();
function loadScoreLibrary(src){
  if(!scoreLibraries.has(src)){
    scoreLibraries.set(src,new Promise((resolve,reject)=>{
      const script=document.createElement('script');
      script.src=src;
      script.onload=resolve;
      script.onerror=()=>{scoreLibraries.delete(src);reject(Error('乐谱组件加载失败，请重新打开'));};
      document.head.append(script);
    }));
  }
  return scoreLibraries.get(src);
}

async function openExternalScore(file){
  if(file.size>16*1024*1024)throw Error('请选择 16 MB 以内的乐谱');
  const dialog=document.createElement('dialog');
  dialog.style.cssText='width:min(95vw,1100px);max-width:95vw;max-height:90vh;overflow:auto';
  dialog.innerHTML='<button autofocus>关闭乐谱</button><h2></h2><div class="score-reader">正在读谱…</div>';
  dialog.querySelector('h2').textContent=file.name;
  dialog.querySelector('button').onclick=()=>dialog.close();
  dialog.onclose=()=>dialog.remove();
  document.body.append(dialog);
  dialog.showModal();
  const view=dialog.querySelector('.score-reader');
  try{
    if(/\.midi?$/i.test(file.name)){
      await loadScoreLibrary('vendor/tone-midi.js');
      const midi=new Midi(await file.arrayBuffer());
      renderMidiRoll(midi,view);
    }else{
      await loadScoreLibrary('vendor/opensheetmusicdisplay.min.js');
      view.replaceChildren();
      const score=new opensheetmusicdisplay.OpenSheetMusicDisplay(view,{autoResize:false,backend:'svg'});
      const data=/\.mxl$/i.test(file.name)?await file.arrayBuffer():new DOMParser().parseFromString(await file.text(),'application/xml');
      await score.load(data);
      if(dialog.open)score.render();
    }
  }catch(error){
    view.textContent='无法显示这份乐谱。'+(error.message||'请检查文件格式。');
  }
}

function renderMidiRoll(midi,view){
  const tracks=midi.tracks.filter(track=>track.notes.length);
  if(!tracks.length)throw Error('MIDI 文件中没有音符');
  view.innerHTML='<label>音轨 <select></select></label> <button>上一段</button> <button>下一段</button> <span></span><div style="overflow:auto"><canvas style="width:100%;min-width:560px"></canvas></div>';
  const select=view.querySelector('select'),canvas=view.querySelector('canvas');
  const [prev,next]=view.querySelectorAll('button');
  tracks.forEach((track,i)=>select.add(new Option(track.name||'音轨 '+(i+1),String(i))));
  let page=0;
  function draw(){
    const track=tracks[+select.value],span=midi.header.ppq*16,start=page*span;
    const low=track.notes.reduce((v,n)=>Math.min(v,n.midi),127);
    const high=track.notes.reduce((v,n)=>Math.max(v,n.midi),0);
    const end=track.notes.reduce((v,n)=>Math.max(v,n.ticks+n.durationTicks),0);
    const row=16,left=44,beat=48;
    canvas.width=left+16*beat;canvas.height=(high-low+1)*row+24;
    const ctx=canvas.getContext('2d');
    for(let i=0;i<16;i++)ctx.fillText(String(page*16+i+1),left+i*beat+2,14);
    for(let pitch=high;pitch>=low;pitch--){
      const y=24+(high-pitch)*row;
      ctx.fillStyle=[1,3,6,8,10].includes(pitch%12)?'#e7eadd':'#faf9f2';
      ctx.fillRect(0,y,canvas.width,row-1);
      ctx.fillStyle='#33483b';
      ctx.fillText(['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'][pitch%12]+(Math.floor(pitch/12)-1),4,y+12);
    }
    ctx.fillStyle='#c5cebf';
    for(let i=0;i<16;i++)ctx.fillRect(left+i*beat,24,1,canvas.height-24);
    ctx.fillStyle='#44694e';
    for(const n of track.notes){
      const from=Math.max(start,n.ticks),to=Math.min(start+span,n.ticks+n.durationTicks);
      if(to>from)ctx.fillRect(left+(from-start)/midi.header.ppq*beat,25+(high-n.midi)*row,Math.max(1,(to-from)/midi.header.ppq*beat-1),row-3);
    }
    prev.disabled=page===0;next.disabled=start+span>=end;
    view.querySelector('span').textContent='第 '+(page*16+1)+'–'+(page*16+16)+' 拍';
  }
  select.onchange=()=>{page=0;draw();};prev.onclick=()=>{page--;draw();};next.onclick=()=>{page++;draw();};draw();
}
