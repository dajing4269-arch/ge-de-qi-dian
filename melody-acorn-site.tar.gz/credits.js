/* Copyright © 2026 大晶 — original product contributions; third-party licenses apply. */
(function(){
 const footer=document.querySelector('footer');
 if(!footer)return;
 const credits=document.createElement('div');credits.className='product-credits';
 credits.innerHTML='<span>大晶出品 · ChatGPT 辅助开发</span><span>有建议和需求请联系我：dajing4269</span><button type="button" id="aboutSongOrigin">关于与使用说明</button>';
 footer.append(credits);
 document.querySelector('#aboutSongOrigin').onclick=()=>{
  const modal=document.querySelector('#modal');
  modal.innerHTML='<h2>歌的起点 · 网页版 1.0</h2><p>大晶出品 · ChatGPT 辅助开发</p><p>有建议和需求请联系我：dajing4269</p><p>© 2026 大晶。原创设计、教程编排及依法享有权利的内容保留所有权利。第三方组件遵循各自许可。</p><p>允许个人试玩、创作并分享自己的作品；请勿冒名发行或未经授权复制本产品的原创代码、教程与素材。</p><p>本产品非 OpenAI 官方产品；“ChatGPT 辅助开发”不表示官方合作。</p><p>无需登录。作品保存在当前设备，请定期备份重要作品；浏览器版和安装版的存档不会自动互通。</p><p>第三方组件：Electron（MIT）、jsPDF（MIT）、lamejs / LAME（LGPL）、Bravura 字形、Ma Shan Zheng 与霞鹜文楷字体（SIL OFL）。第三方组件权利不属于本产品的专有声明范围。</p><div class="actions"><button id="closeSongAbout">返回</button></div>';
  document.querySelector('#closeSongAbout').onclick=()=>modal.close();modal.showModal();
 };
})();
