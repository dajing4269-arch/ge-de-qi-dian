/* Loaded only by the public web build. Keep unreleased progress dormant. */
function publicReleaseKnowledgeProject(p){
 return !!p&&typeof p==='object'&&(p.advancedReview!==undefined||p.knowledgeLesson!==undefined||p.knowledgeVersion!==undefined);
}
function publicReleaseRoute(){
 const unavailable=/^knowledge/.test(db.active||'')||publicReleaseKnowledgeProject(project());
 const oldColumn=['knowledge-column','advanced-review'].includes(db.view);
 if(unavailable){
  db.active=[...CHAPTER_KEYS.slice(1),'studio'].find(key=>db[key]&&!publicReleaseKnowledgeProject(db[key]))||'one';
 }
 if(unavailable||oldColumn){db.view='home';selected=null;undo=[];redo=[];}
 return unavailable||oldColumn;
}
function installPublicRelease(){
 const oldMigrate=migrateV2,oldStart=start,oldRender=render,oldValid=validProject;
 migrateV2=function(){
  publicReleaseRoute();
  // Legacy/imported account backups may contain future projects in regular
  // slots. Exclude them from basic-lesson migrations, then restore unchanged.
  const hidden=[];
  for(const store of [db,db.journeyBackup,db.rhythmBackups]){
   if(!store||typeof store!=='object')continue;
   for(const [key,p] of Object.entries(store))if(publicReleaseKnowledgeProject(p)){
    hidden.push([store,key,p]);delete store[key];
   }
  }
  try{return oldMigrate();}finally{for(const [store,key,p] of hidden)store[key]=p;}
 };
 start=function(key){
  if(/^knowledge/.test(key)||publicReleaseKnowledgeProject(db[key])){
   stop();publicReleaseRoute();db.view='home';save();render();toast('知识串烧待更新');return;
  }
  return oldStart(key);
 };
 render=function(){
  if(publicReleaseRoute())save();
  setHomePage(db.view==='home');
  return oldRender();
 };
 validProject=function(p){return !publicReleaseKnowledgeProject(p)&&oldValid(p);};
}
