/* Canonical key signatures and measure-scoped accidentals on the main score. */
const SCORE_ACCIDENTAL_SCALE=1.05;
function scoreKeyInset(p=project()){const count=keySignatureEntries(p).length;return count?count*18+10:0;}
function scorePitchAlter(pitch,p=project()){
 const natural=12*(Math.floor(pitch/7)+1)+SEMI[((pitch%7)+7)%7];
 return studioMidi(pitch,p)-natural;
}
function scorePitchName(pitch,p=project()){
 const alter=scorePitchAlter(pitch,p),sign=alter===2?'𝄪':alter===-2?'𝄫':alter===1?'♯':alter===-1?'♭':'';
 return NAMES[((pitch%7)+7)%7]+sign+Math.floor(pitch/7);
}
function scoreMeasureAccidentals(measure,p=project()){
 const key=studioKeyAccidentals(p),state=new Map();
 return measure.notes.map(n=>{
  if(n.rest||n.p===null||n.p===undefined)return null;
  const alter=n.alter??scorePitchAlter(n.p,p),previous=state.has(n.p)?state.get(n.p):(key.get(n.p%7)||0);
  // A tied continuation retains its pitch, but does not alter later untied notes
  // in the new measure. Only a fresh attack establishes an accidental there.
  if(!n.first)return null;
  state.set(n.p,alter);
  return (alter!==previous||n.explicitAccidental)?{alter,name:scaleAccidentalName(alter)}:null;
 });
}
function scoreKeySignatureSVG(p=project()){
 const entries=keySignatureEntries(p);if(!entries.length)return '';
 return `<g class="score-key-signature" aria-label="${esc(studioModeLabel(p))}调号">${entries.map(({pitch,alter},i)=>`<g class="score-key-accidental" data-pitch="${pitch}" data-alter="${alter}">${glyph(scaleAccidentalName(alter),66+i*18,noteY(pitch),SCORE_ACCIDENTAL_SCALE)}</g>`).join('')}</g>`;
}
function installScoreKeys(){
 const oldModel=systemModel,oldSVG=engravingSVG;
 systemModel=function(p=project(),focusLi=null){
  const rows=oldModel(p,focusLi),inset=scoreKeyInset(p);
  for(const row of rows){
   for(const m of row.measures){
    m.x+=inset;
    const marks=scoreMeasureAccidentals(m,p);
    m.notes.forEach((n,i)=>{n.x+=inset;n.scoreAccidental=marks[i];});
   }
   row.scoreKeyInset=inset;row.endX+=inset;row.width+=inset;
  }
  // Keep all systems at one scale, including those with extra temporary signs.
  const uniform=Math.max(0,...rows.map(row=>row.width));rows.forEach(row=>row.width=uniform);
  return rows;
 };
 engravingSVG=function(row,mode='combined',editable=true){
  let svg=oldSVG(row,mode,editable);if(mode==='jianpu')return svg;
  const p=project(),inset=row.scoreKeyInset??scoreKeyInset(p),signature=scoreKeySignatureSVG(p);
  // These old font-based symbols represented every altered scale note. The key
  // signature now supplies those alterations; only genuine exceptions remain.
  svg=svg.replace(/<text x="[^"]+" y="[^"]+" font-size="18">(?:♭|♯|𝄪|𝄫)<\/text>/gu,'');
  const clef=glyph('clef',24,186);
  svg=svg.replace(clef,clef+signature);
  if(inset&&(row.first||editable&&row.showTimeSignature)){
   svg=svg.replace('<g class="time-signature"',`<g transform="translate(${inset} 0)" class="time-signature"`);
   if(row.first)svg=svg.replace('transform="translate(76 104) scale(1)"',`transform="translate(${76+inset} 104) scale(1)"`);
  }
  const byX=new Map();let temporary='';
  for(const m of row.measures){
   const marks=scoreMeasureAccidentals(m,p);
   m.notes.forEach((n,i)=>{
    if(n.rest||n.p===null||n.p===undefined)return;
    byX.set(String(n.x),n.alter===undefined?scorePitchName(n.p,p):NAMES[n.p%7]+({1:'♯',0:'♮','-1':'♭'}[n.alter])+Math.floor(n.p/7));
    const mark=marks[i];if(!mark)return;
    const selectedNote=editable&&selected?.li===n.li&&selected?.i===n.i&&(selected.si??0)===(n.si??0);
    const headWidth=MUSIC_GLYPHS[n.d>=4?'whole':n.d>=2?'half':'black'].width;
    const x=n.x-headWidth/2-6-MUSIC_GLYPHS[mark.name].width*SCORE_ACCIDENTAL_SCALE;
    temporary+=`<g class="score-note-accidental" data-li="${n.li}" data-i="${n.i}" data-si="${n.si??0}" data-pitch="${n.p}" data-alter="${mark.alter}" pointer-events="none" color="${selectedNote?'#bc842b':'#263e35'}">${glyph(mark.name,x,noteY(n.p),SCORE_ACCIDENTAL_SCALE)}</g>`;
   });
  }
  svg=svg.replace(/(<text class="pitch-name" x="([^"]+)"[^>]*>)[^<]*(<\/text>)/g,(all,start,x,end)=>byX.has(x)?start+esc(byX.get(x))+end:all);
  // Continuation ties begin after the repeated key signature, never through it.
  if(inset)svg=svg.replace(/<path d="M90 ([\d.-]+)Q([\d.-]+) ([\d.-]+) ([\d.-]+) ([\d.-]+)" fill="none" stroke="currentColor"\/>/g,(_,y,cx,cy,x2,y2)=>`<path d="M${90+inset} ${y}Q${Number(cx)+inset/2} ${cy} ${x2} ${y2}" fill="none" stroke="currentColor"/>`);
  return svg.replace('</g></svg>',temporary+'</g></svg>');
 };
}
