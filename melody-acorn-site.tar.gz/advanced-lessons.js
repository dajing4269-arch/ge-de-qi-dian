/* Lessons 11–15: paired phrases, diatonic sequence and paragraph repetition. */
const LYRIC_CHOICES=[
 {title:'沿河走',lines:['晚风陪我沿河走','河边垂柳拂衣袖','一轮月亮随桥瘦','几盏街灯在身后','走到长街灯尽头','买束鲜花带回楼']},
 {title:'过山',lines:['一条山路绕斜阳','一阵松风过肩膀','云从山顶奔远方','我从山脚向上望','走过弯弯小石岗','回头灯火满山乡']}
];
const ADVANCED_LESSONS={
 11:{...LYRIC_CHOICES[0],author:'Chat gpt'},
 12:{title:'浣溪沙',author:'晏殊',lines:['一曲新词酒一杯','去年天气旧亭台','夕阳西下几时回','无可奈何花落去','似曾相识燕归来','小园香径独徘徊']},
 13:{title:'窗边四季',author:'Chat gpt',lines:['春风轻轻推开窗','燕子双双过院墙','我把新茶分两盏','等你归来话家常','秋风轻轻推开窗','桂子纷纷落院墙','我把陈茶分两盏','等你归来话秋凉'],sections:[0,0,0,0,1,1,1,1]},
 14:{title:'山路',author:'Chat gpt',lines:['背着旧行囊走过小山岗','鞋底沾着泥衣角沾着香','路边有人问要去什么地方','我指着云说还想走一趟','等到炊烟起就借一晚月光','明早推开门再向远方'],sections:[0,0,1,1,2,2]},
 15:{title:'旧照片',author:'Chat gpt',lines:['抽屉深处有张旧照片','你站在风里眯着双眼','那年我们还不懂告别','总说明天还会再见','如今又走过那家小店','门前的树已高过屋檐','我把照片轻轻翻一面','背后是你写的那个夏天']}
};
function advancedLesson(p=project()){return p.level>=11&&p.level<=30;}
function melodyEnabled(p=project()){return p.level===0||p.level>=12;}
function advancedSteps(p){
 const pair=(a,b)=>({kind:'pair',name:a===b?`创作第${a+1}句旋律`:`创作${a+1}-${b+1}句旋律`,lines:Array.from({length:b-a+1},(_,i)=>a+i)});
 const base=[...(p.level>=16?[{kind:'meter-tempo',name:'节拍和速度'}]:[{kind:'meter',name:'选择节拍'},{kind:'tempo',name:'选择速度'}]),{kind:'mode',name:'选择调式'}];
 if(p.level===11)base.unshift({kind:'lyrics',name:'选择歌词'});
 if(p.level>=13)base.push({kind:'sections',name:p.level>=16?'编辑歌词与分段':'歌词分段'});
 if(p.level===13)base.push(pair(0,1),pair(2,3),{kind:'repeat',name:'整段重复',lines:[4,5,6,7],section:1});
 else if(p.level===14)base.push(pair(0,1),{kind:'repeat',name:'整段重复与微调',lines:[2,3],section:1},{kind:'repeat',name:'整段重复与微调',lines:[4,5],section:2});
 else for(let i=0;i<p.lines.length;i+=2)base.push(pair(i,Math.min(i+1,p.lines.length-1)));
 base.push(p.level===23?{kind:'pickup',name:'弱起小节'}:p.level===22?{kind:'rests',name:'加入休止'}:{kind:'review',name:'自由修改'});


 return [...base,{kind:'credits',name:'完成作品'},{kind:'save',name:'保存作品'}];
}
function migrateSplitReview(p){if(p.level!==12||p.splitReviewVersion)return;for(const key of ['step','maxStep'])if(p[key]>=7)p[key]--;p.splitReviewVersion=1;}
function splitReview(p=project()){return p.level===12&&advancedStep(p)?.kind==='review';}
function advancedStep(p=project()){return advancedSteps(p)[p.step];}
function sectionRanges(p=project()){const out=[];p.lines.forEach((l,i)=>{if(!i||(l.section??0)!==(p.lines[i-1].section??0))out.push([]);out.at(-1).push(i);});return out;}
function markCopyRepairs(l){l.copyRepairs=l.durations.map((d,i)=>d===null||l.pitches[i]===null||l.melody?.[i]?.some(n=>n.p===null&&!n.rest)?i:-1).filter(i=>i>=0);if(!l.copyRepairs.length)delete l.copyRepairs;}
function needsCopyRhythm(l,g){return l.durations.some((d,i)=>i>=g.start&&i<g.end&&d===null&&l.copyRepairs?.includes(i));}
function needsCopyRepair(l,i,p=project()){return !!((l.copyRepairs?.includes(i)||p.level===14)&&(l.durations[i]===null||l.pitches[i]===null||l.melody?.[i]?.some(n=>n.p===null&&!n.rest)));}
function copyPhraseData(from,to){
 const n=lyricUnits(to.text).length,shared=Math.min(lyricUnits(from.text).length,n);
 to.durations=Array.from({length:n},(_,i)=>i<shared?from.durations[i]??null:null);
 to.pitches=Array.from({length:n},(_,i)=>i<shared?from.pitches[i]??null:null);
 to.cuts=Array.from({length:n-1},(_,i)=>i<shared-1?!!from.cuts[i]:true);
 to.staccato=Array.from({length:n},(_,i)=>i<shared&&!!from.staccato?.[i]);
 to.melody={};for(let i=0;i<shared;i++)if(from.melody?.[i])to.melody[i]=clone(from.melody[i]);
 // A shorter target leaves its final syllable empty so its new cadence is rewritten.
 if(n<lyricUnits(from.text).length){to.durations[n-1]=null;to.pitches[n-1]=null;delete to.melody[n-1];to.staccato[n-1]=false;}
 markCopyRepairs(to);
}
function copySection(source,target,p=project()){
 const ranges=sectionRanges(p);if(!Number.isInteger(source)||source<0||source>=target||!ranges[target])return false;
 const originals=ranges[source].map(i=>clone(p.lines[i]));ranges[target].forEach((li,j)=>{if(originals[j])copyPhraseData(originals[j],p.lines[li]);else{const line=p.lines[li];line.durations.fill(null);line.pitches.fill(null);line.staccato=line.pitches.map(()=>false);for(const key of ['melody','restsAfter','accidentals'])delete line[key];markCopyRepairs(line);}p.sentenceStages??=[];p.sentenceStages[li]=2;});
 p.sectionCopies??={};p.sectionCopies[target]=source;return true;
}
function shiftPhrase(li,direction,p=project()){
 const l=p.lines[li],values=[...l.pitches,...Object.values(l.melody||{}).flat().map(n=>n.p)].filter(v=>v!==null);
 if(!values.length)return '先为这句写几个音，再试试上下平移';
 const shift=v=>v===null?null:snapModePitch(v+direction,direction,p),min=p.level?25:14,max=p.level?43:49;
 if(values.some(v=>shift(v)<min||shift(v)>max))return '已经到可用音域的边缘了，试试另一个方向';
 l.pitches=l.pitches.map(shift);Object.values(l.melody||{}).forEach(a=>a.forEach(n=>n.p=shift(n.p)));p.sequenceDone=true;if(p.level===11&&[1,3].includes(li)&&p.sequenceCopies?.[li]){p.sequenceShifts??={};p.sequenceShifts[li]=true;}return '';
}
function advanceAdvanced(){stop();selected=null;mutate(()=>project().step++);render();}
function advancedScoreHTML(){const p=project(),step=advancedStep(p);let indices=p.lines.map((_,i)=>i);if(step.kind==='pair'||step.kind==='repeat'){const last=step.lines.at(-1);indices=indices.filter(i=>i<=last&&(!step.lines.includes(i)||p.sentenceStages[i]===2||step.kind==='repeat'));}return systemModel(p,indices).map(row=>scoreRowHTML(row,true)).join('');}
function copyControls(li,sectionOnly=false){
 const p=project(),ranges=sectionRanges(p),section=ranges.findIndex(a=>a[0]===li);
 return `${!sectionOnly&&li>0?`<div class="copy-phrase"><label>复制第 <input data-copy-source="${li}" type="number" min="1" max="${li}" value="${li}"> 句旋律</label><button data-copy-phrase="${li}">复制</button></div>`:''}${section>0?`<div class="copy-phrase"><label>复制第 <input data-section-source="${section}" type="number" min="1" max="${section}" value="${section}"> 段旋律</label><button data-copy-section="${section}">复制</button></div>`:''}`;
}
function bindAdvancedCopies(){
 $$('[data-copy-phrase]').forEach(b=>b.onclick=()=>{const li=+b.dataset.copyPhrase,source=sequenceRequired(li)?li-1:+$(`[data-copy-source="${li}"]`).value-1;if(sequenceRequired(li)&&sentenceError(li-1)){toast('先完成前一句旋律');return;}if(!Number.isInteger(source)||source<0||source>=li){toast('请选择前面的一句');return;}mutate(()=>{copyPhraseData(project().lines[source],project().lines[li]);project().sentenceStages[li]=2;if(sequenceRequired(li)){project().sequenceCopies??={};project().sequenceCopies[li]=true;project().sequenceShifts??={};project().sequenceShifts[li]=false;}selected=null;});stop();render();});
 $$('[data-copy-section]').forEach(b=>b.onclick=()=>{const target=+b.dataset.copySection,source=+$(`[data-section-source="${target}"]`).value-1;if(!Number.isInteger(source)||source<0||source>=target){toast('请选择前面的一个段落');return;}mutate(()=>copySection(source,target));stop();render();});
}
function sequenceRequired(li,p=project()){return p.level===11&&[1,3].includes(li);}
function sequencePending(li,p=project()){return sequenceRequired(li,p)&&!p.sequenceShifts?.[li];}
function pairWork(li){
 const p=project(),l=p.lines[li],validGroups=groups(l).every(g=>g.end-g.start<=2),ready=l.durations.every(d=>d!==null)&&!l.pairTapeOpen,required=sequenceRequired(li),pending=sequencePending(li);
 let html=`<section class="pair-phrase" data-pair-line="${li}"><h3>第 ${li+1} 句 · ${esc(l.text)}</h3>`;
 if(required&&!p.sequenceCopies?.[li]){
  const sourceReady=!sentenceError(li-1);
  return html+`<div class="sequence-focus copy-phrase"><span>复制第 ${li} 句旋律</span><input type="hidden" data-copy-source="${li}" value="${li}"><button data-copy-phrase="${li}" ${sourceReady?'':'disabled'}>复制</button></div>${sourceReady?'':`<p class="hint">完成第 ${li} 句后，就可以复制它的旋律。</p>`}</section>`;
 }
 if(pending)html+='<p class="sequence-instruction">将同样的旋律向上/向下平移，叫模进。感受模进带来的上下句呼应。</p>';
 if(!pending){
  if(!ready||!validGroups)html+=copyControls(li);
  if(!ready||!validGroups)html+=`<p class="hint">先划分成每组 1～2 个字。</p><div class="groups-line">${lyricUnits(l.text).map((c,i)=>`<span class="character ${/[A-Za-z]/.test(c)?'english-syllable':''}">${esc(c)}</span>${i<lyricUnits(l.text).length-1?`<button class="divider ${l.cuts[i]?'on':''}" data-pair-cut="${li}:${i}" aria-label="${esc(c)}后分组">│</button>`:''}`).join('')}</div>`;
  if(validGroups&&!ready){l.pairTapeOpen=true;fillLyricDurations(l,p);l.dragRhythm=true;html+=rhythmLessonTape(li,`data-play-rhythm="${li}"`)+`<button data-pair-tape-done="${li}">继续：安排歌词音高 →</button>`;}

 }
 if(ready&&(validGroups||pending))html+=systemModel(p,[li]).map(row=>scoreRowHTML(row,true)).join('');
 return html+'</section>';
}
function pairPhase(p,lines){return Math.min(...lines.map(i=>p.lines[i].durations.every(d=>d!==null)?2:groups(p.lines[i]).every(g=>g.end-g.start<=2)?1:0));}
function renderPair(){const p=project(),step=advancedStep(p);
 step.lines.forEach(li=>p.sentenceStages[li]=p.lines[li].durations.every(d=>d!==null)?2:1);
 const previous=p.lines.map((_,i)=>i).filter(i=>i<step.lines[0]);
 $('#stage').innerHTML=heading(step.name,step.name,'')+editingControls()+`<div id="scoreArea">${previous.length?`<details class="previous-phrases"><summary>查看前面的旋律</summary>${systemModel(p,previous).map(row=>scoreRowHTML(row,true)).join('')}</details>`:''}<div class="pair-work">${step.lines.map(pairWork).join('')}</div></div>`;
 bindPlayback();bindAdvancedCopies();
 $$('[data-pair-cut]').forEach(b=>b.onclick=()=>{const [li,i]=b.dataset.pairCut.split(':').map(Number);mutate(()=>p.lines[li].cuts[i]=!p.lines[li].cuts[i]);render();});
 $$('[data-pair-tape-done]').forEach(b=>b.onclick=()=>{mutate(()=>delete p.lines[+b.dataset.pairTapeDone].pairTapeOpen);render();});
 if(!$('#scoreArea .note'))$('#selection')?.remove();
 $$('[data-play-rhythm]').forEach(b=>b.onclick=()=>playAll(true,+b.dataset.playRhythm));
 nav(true,'',()=>{for(const li of step.lines){if(sequencePending(li)){toast('复制前一句旋律后，用上下箭头平移这句旋律');return;}const error=sentenceError(li);if(error){toast(`第 ${li+1} 句：${error}`);return;}}advanceAdvanced();});
 $('#next').disabled=step.lines.some(li=>sequencePending(li)||!!sentenceError(li));
}
function renderLyricChoice(){const p=project();$('#stage').innerHTML=heading('选择歌词','选一首你想谱曲的歌词','')+`<div class="lyric-choice-grid">${LYRIC_CHOICES.map((c,i)=>`<button class="lyric-choice ${p.lyricChoice===i?'selected':''}" data-lyric-choice="${i}" aria-pressed="${p.lyricChoice===i}"><h3>${c.title}</h3><p>${c.lines.map(esc).join('<br>')}</p></button>`).join('')}</div>`;
 $$('[data-lyric-choice]').forEach(b=>b.onclick=()=>{const i=+b.dataset.lyricChoice;if(p.lyricChoice===i)return;mutate(()=>{p.lyricDrafts??={};if(p.lyricChoice!==undefined)p.lyricDrafts[p.lyricChoice]={lines:clone(p.lines),stages:clone(p.sentenceStages),sequenceDone:p.sequenceDone,sequenceCopies:clone(p.sequenceCopies||{}),sequenceShifts:clone(p.sequenceShifts||{})};const draft=p.lyricDrafts[i];p.lines=draft?clone(draft.lines):fresh(11,LYRIC_CHOICES[i].lines).lines;p.lines.forEach(l=>{if(!draft)l.cuts=l.cuts.map((_,j)=>(j+1)%2===0);l.section=0;});p.sentenceStages=draft?clone(draft.stages):p.lines.map(()=>0);p.sequenceDone=draft?.sequenceDone??false;p.sequenceCopies=draft?.sequenceCopies||{};p.sequenceShifts=draft?.sequenceShifts||{};p.title=LYRIC_CHOICES[i].title;p.lyricChoice=i;p.complete=false;p.creditsConfirmed=false;p.maxStep=p.step;});render();});nav(false,'',advanceAdvanced);$('#next').disabled=p.lyricChoice===undefined;
}
function sectionText(p=project()){return p.lines.map((l,i)=>(i&&(l.section??0)!==(p.lines[i-1].section??0)?'\n':'')+l.text).join('\n');}
function applySectionText(text,p=project()){
 const lines=text.replace(/\r/g,'').split('\n'),content=lines.filter(s=>s.trim()).map(s=>s.replace(/[\s，。！？；,.!?;]/g,''));
 if(content.length!==p.lines.length||content.some((s,i)=>s!==p.lines[i].text))return false;
 let section=0,index=0,gap=false;for(const s of lines){if(!s.trim()){if(index)gap=true;continue;}if(gap){section++;gap=false;}p.lines[index++].section=section;}p.sectionsByUser=true;return true;
}
function renderSections(){const p=project(),editable=p.level===15;$('#stage').innerHTML=heading('歌词分段',editable?'用空行给歌词分段吧':'看看歌词分成了哪几段','自由创作模式时，歌词需要通过间隔一行来划分段落。')+(editable?`<p class="hint">在两句之间空一行；保留原来的歌词和每句换行。</p><textarea id="sectionLyrics" class="section-lyrics">${esc(sectionText())}</textarea>`:`<div class="section-lyrics readonly">${esc(sectionText())}</div>`);nav(true,'',()=>{if(editable){let ok=false;mutate(()=>ok=applySectionText($('#sectionLyrics').value));if(!ok){toast('保留每句歌词，用空行调整段落即可');return;}}advanceAdvanced();});}
function paragraphCopyPending(p=project()){if(!advancedLesson(p))return false;const step=advancedStep(p);return step?.kind==='repeat'&&p.sectionCopies?.[step.section]===undefined;}
function renderAdvancedOperation(){const p=project(),step=advancedStep(p),repeat=step.kind==='repeat';let title=step.kind==='sequence'?'试试把整句旋律移高或移低':step.kind==='split'?'让一个字唱出两个音':repeat?step.name:'最后看看有哪里需要调整～';let hint=step.kind==='sequence'?'点击每句右上方的 ↑ 或 ↓，听听同样的旋律换个高度。':step.kind==='split'?'点击乐谱上方的歌词节奏音符，拆成两个音，再调整它们的音高。':repeat&&p.level===14?'圈出的字和音需要补齐；改节奏、改音高或拆成多个音都可以，完成后继续。':'';
 if(step.kind==='review'&&p.level>=12&&p.level<=15)hint='点击歌词节奏中的音符，可以将对应时长的音符拆成多个，将一字一音改成一字多音，并赋予新的节奏。';
 $('#stage').innerHTML=heading(step.name,title,hint)+editingControls()+`<div id="scoreArea">${advancedScoreHTML()}</div>`;bindPlayback();bindAdvancedCopies();
 nav(true,'',()=>{if(step.kind==='sequence'&&!p.sequenceDone){toast('试着用 ↑ 或 ↓ 平移一句旋律');return;}if(splitReview(p)&&!p.lines.some(l=>Object.values(l.melody||{}).some(a=>a.length>1))){toast('点击上方歌词节奏，为一个字拆出两个音');return;}if(repeat&&p.sectionCopies?.[step.section]===undefined){toast('先复制前面一段的旋律');return;}for(const li of repeat?step.lines:p.lines.map((_,i)=>i)){const issue=sentenceError(li);if(issue){toast(`第 ${li+1} 句：${issue}`);return;}}if(advancedSteps(p)[p.step+1].kind==='credits')mutate(()=>p.complete=true);advanceAdvanced();});
 if(paragraphCopyPending(p))$('#next').disabled=true;
}
function installAdvancedLessons(){
 CHAPTER_KEYS.push('eleven','twelve','thirteen','fourteen','fifteen');Object.entries(ADVANCED_LESSONS).forEach(([n,v])=>CHAPTER_TITLES[n]=n==='11'?'沿河走 / 过山':v.title);
 const oldStart=startChapter,oldMigrate=migrateV2,oldLesson=sentenceLesson,oldSteps=stepNames,oldCredit=creditStep,oldRender=renderOrderedLesson,oldScore=scoreHTML,oldRefresh=refreshScore,oldBind=bindScore,oldButtons=phraseButtons,oldMode=modeChoices,oldParse=parseLyrics,oldValidate=validStudioData,oldError=sentenceError,oldEnding=endingIssue,oldBeats=lineBeats,oldNormalize=normalizeLessonLine;
 currentChapter=()=>{for(let n=1;n<CHAPTER_KEYS.length;n++)if(!db[CHAPTER_KEYS[n]]?.complete)return n;return CHAPTER_KEYS.length-1;};
 startChapter=function(n){if(n<11)return oldStart(n);if(n>=CHAPTER_KEYS.length)return;const key=CHAPTER_KEYS[n],c=ADVANCED_LESSONS[n];if(!db[key]){const p=fresh(n,c.lines);Object.assign(p,{...(n>=16?{meterTempoVersion:1}:{}),...(n>=19?{lessonOrderVersion:3}:{}),title:c.title,lyricist:c.author,splitReviewVersion:1,meter:'4/4',tonic:'C',scale:'大调',curriculumVersion:1,lessonRhythmVersion:2,layoutVersion:4,barsPerRow:'auto-phrases',sentenceFlow:1,controlOrder:2,uiVersion:2,maxStep:0,sentenceStages:c.lines.map(()=>0),sentenceCompleted:c.lines.map(()=>false)});p.lines.forEach((l,i)=>{l.section=n>=15&&!c.defaultSections?0:c.sections?.[i]??0;l.cuts=l.cuts.map((_,j)=>(j+1)%2===0);l.punct=c.punctuation?.[i]??(i%2?'。':'，');});db[key]=p;}start(key);};
 migrateV2=function(){oldMigrate();for(const key of [...CHAPTER_KEYS,'studio']){const p=db[key];if(!p)continue;for(const [i,l] of p.lines.entries())if(!l.copyRepairs&&(p.sentenceStages?.[i]===2||p.level===0&&l.pitches.some(v=>v!==null)))markCopyRepairs(l);}for(const key of CHAPTER_KEYS){const p=db[key];if(p&&[3,4,6,8,11,13,14,15].includes(p.level)&&(!p.lyricist||/^原创/.test(p.lyricist)))p.lyricist='Chat gpt';}for(const key of CHAPTER_KEYS.slice(11)){const p=db[key];if(!p)continue;migrateSplitReview(p);p.sentenceStages??=p.lines.map(()=>0);p.sentenceCompleted??=p.lines.map(()=>false);p.maxStep??=p.step;p.curriculumVersion=1;p.sentenceFlow=1;p.lines.forEach((l,i)=>l.section??=p.level>=15?0:ADVANCED_LESSONS[p.level].sections?.[i]??0);}};
 normalizeLessonLine=function(l,p){if(l.dragRhythm)return;oldNormalize(l,p);for(const [i,a] of Object.entries(l.melody||{}))if(Math.abs(a.reduce((s,n)=>s+n.d,0)-(l.durations[i]??0))>.001)delete l.melody[i];};
 lineBeats=function(l,p=project()){const base=oldBeats(l,p),bar=barBeats(p),actual=l.durations.reduce((sum,d,i)=>sum+(melodyEnabled(p)&&l.melody?.[i]?l.melody[i].reduce((t,n)=>t+n.d,0):(d??(boundedLesson(p)?.5:1))),0);return Math.max(base,Math.ceil(actual/bar)*bar);};
 sentenceLesson=p=>advancedLesson(p)||oldLesson(p);
 stepNames=function(p=project()){return advancedLesson(p)?advancedSteps(p).map(s=>s.name):oldSteps(p);};
 creditStep=function(p=project()){return advancedLesson(p)?advancedSteps(p).findIndex(s=>s.kind==='credits'):oldCredit(p);};
 modeChoices=p=>p.level>=11?['大调','宫调式（五声）','自然小调','羽调式（五声）']:oldMode(p);
 renderOrderedLesson=function(){const p=project();if(!advancedLesson(p))return oldRender();const step=advancedStep(p);if(step.kind==='lyrics')return renderLyricChoice();if(step.kind==='sections')return renderSections();if(step.kind==='pair')return renderPair();if(['repeat','review','sequence','split'].includes(step.kind))return renderAdvancedOperation();if(step.kind==='credits'||step.kind==='save')return renderFinish();if(step.kind==='meter'){renderCurriculumMeter();$('#next').onclick=advanceAdvanced;}if(step.kind==='tempo')renderTempo();if(step.kind==='mode'){renderCurriculumMode();$('#next').onclick=advanceAdvanced;}};
 scoreHTML=function(editable=true){return advancedLesson()&&editable?advancedScoreHTML():oldScore(editable);};
 refreshScore=function(){if(advancedLesson()&&advancedStep().kind==='pair'){const el=$('#modal');if(!el?.open){render();return;}}oldRefresh();};
 phraseButtons=function(li,editable=true){return oldButtons(li,editable)+(editable&&(project().level===0||project().level>=11)?`<div class="phrase-shift ${advancedLesson()&&advancedStep().kind==='pair'&&sequencePending(li)?'sequence-focus':''}"><button data-shift-line="${li}" data-direction="1" aria-label="第 ${li+1} 句整句上移">↑</button><button data-shift-line="${li}" data-direction="-1" aria-label="第 ${li+1} 句整句下移">↓</button></div>`:'')+(editable&&project().level===0?copyControls(li,true):'')+(editable&&advancedLesson()&&advancedStep().kind==='repeat'?copyControls(li):'');};
 bindScore=function(){oldBind();
 if(advancedLesson()&&advancedStep().kind==='pair'){
  for(const li of advancedStep().lines)if(sequencePending(li)&&project().sequenceCopies?.[li]){
   selected=null;const section=$(`[data-pair-line="${li}"]`);
   if(section){section.querySelectorAll('svg').forEach(el=>el.setAttribute('inert',''));section.querySelectorAll('button').forEach(el=>{if(!el.hasAttribute('data-shift-line')&&!el.hasAttribute('data-play-line'))el.disabled=true;});
    for(const event of ['pointerdown','click','contextmenu','keydown'])section.addEventListener(event,e=>{if(!e.target.closest('[data-shift-line],[data-play-line]')){e.preventDefault();e.stopImmediatePropagation();}},true);
   }
  }
 }
$$('[data-shift-line]').forEach(b=>b.onclick=()=>{let error='';mutate(()=>error=shiftPhrase(+b.dataset.shiftLine,+b.dataset.direction));if(error)toast(error);else{stop();refreshScore();}});if(project().level===0||advancedLesson()&&advancedStep().kind==='repeat')bindAdvancedCopies();};
 parseLyrics=text=>text.trim().split(/\r?\n\s*\r?\n/).flatMap((part,section)=>oldParse(part).map(l=>({...l,section})));
 validStudioData=function(p){return oldValidate(p.level>=12?{...p,level:0}:p)&&p.lines.every(l=>l.section===undefined||Number.isInteger(l.section)&&l.section>=0&&l.section<200);};
 endingIssue=function(p,li){const last=p.lines[li].melody?.[p.lines[li].pitches.length-1];if(last?.length){const copy={...p,lines:p.lines.map((l,i)=>i===li?{...l,pitches:l.pitches.map((v,j)=>j===l.pitches.length-1?(last.findLast(n=>!n.rest)?.p??null):v)}:l)};return oldEnding(copy,li);}return oldEnding(p,li);};
 sentenceError=function(li){const error=oldError(li);if(error)return error;const l=project().lines[li];if(advancedLesson()&&(l.durations.reduce((s,d)=>s+d,0)>lessonBudget()||!l.dragRhythm&&groups(l).some(g=>!lessonPatterns(g.end-g.start).some(ds=>JSON.stringify(ds)===JSON.stringify(l.durations.slice(g.start,g.end))))))return '请点击歌词，调整这句的歌词节奏';if(Object.values(l.melody||{}).some(a=>a.some(n=>n.p===null&&!n.rest)))return '这句还有拆分后的音没选音高';return '';};
}
