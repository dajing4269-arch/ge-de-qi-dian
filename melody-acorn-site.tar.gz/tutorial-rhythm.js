/* Restrained first two chapters; later chapters and free composition stay open. */
function isTutorialRhythm(p=project()){return [1,2].includes(p.level)&&p.lines.every(l=>lyricUnits(l.text).length===5);}
const INTRO_GROUPS=[[2,2,1],[2,1,2],[2,1,1,1],[1,1,2,1],[1,1,1,2],[1,1,1,1,1],[1,2,2],[1,2,1,1]];
function groupingLengths(l){return groups(l).map(g=>g.end-g.start);}
function cutsFor(lengths){let sum=0;const cuts=[false,false,false,false];lengths.slice(0,-1).forEach(n=>{sum+=n;cuts[sum-1]=true;});return cuts;}
function introChoices(l,g){
  const key=g.start+'-'+g.end;
  return ({'0-1':[[1]],'1-2':[[1]],'1-3':[[1,1]],'3-4':[[1]],'0-2':[[1,1],[1.5,.5]],'2-4':[[1,1],[1.5,.5]],'4-5':[[4],[2]],'2-5':[[1,1,4],[1.5,.5,4],[1,1,2],[1.5,.5,2]],'2-3':[[1]],'3-5':[[1,4],[1,2]]})[key]||[];
}
function rhythmChoices(l,g,p=project()){if(boundedLesson(p)){const used=l.durations.reduce((s,d,i)=>s+(i>=g.start&&i<g.end?0:d??.5),0);return lessonPatterns(g.end-g.start,p).filter(ds=>used+ds.reduce((s,d)=>s+d,0)<=lessonBudget(p));}return p.level>=3?laterRhythms(g.end-g.start,p):isTutorialRhythm(p)?introChoices(l,g):options(g.end-g.start);}
function normalizeIntroLine(l){if(l.dragRhythm)return;
  if(!INTRO_GROUPS.some(pattern=>JSON.stringify(pattern)===JSON.stringify(groupingLengths(l))))l.cuts=cutsFor(INTRO_GROUPS[0]);
  for(const g of groups(l)){
    const ds=l.durations.slice(g.start,g.end);if(ds.every(d=>d===null))continue;
    const choices=introChoices(l,g);if(!choices.some(c=>JSON.stringify(c)===JSON.stringify(ds)))choices[0].forEach((d,j)=>l.durations[g.start+j]=d);
  }
}
function migrateTutorialRhythm(){
  for(const key of ['one','two']){
    const p=db[key];if(!p||p.rhythmRuleVersion===1||!isTutorialRhythm(p))continue;
    const before=clone(p);p.lines.forEach(normalizeIntroLine);
    const changed=JSON.stringify(before.lines)!==JSON.stringify(p.lines);
    if(changed&&before.lines.some(l=>l.durations.some(d=>d!==null))){db.rhythmBackups??={};db.rhythmBackups[key]=before;}
    p.rhythmRuleVersion=1;
    if(p.level===2&&p.lines.length===4)p.rhythmBaseline=clone(p.lines[3].durations);
  }
}
function backupOldRhythm(){
  const previous=db.rhythmBackups?.[db.active];if(!previous)return;
  const p=clone(previous);p.level=0;p.step=5;p.maxStep=5;p.flowVersion=4;p.title+='（旧节奏）';p.complete=false;
  download(new Blob([JSON.stringify({format:'melody-garden',version:1,project:p},null,2)],{type:'application/json'}),p.title+'.melody.json');toast('修改前的节奏已导出，可在自由创作中继续使用');
}
function renderGroups(){
  if(project().level===1)return renderFreeGroups();
  if(!isTutorialRhythm())return renderFreeGroups();
  const p=project();$('#stage').innerHTML=heading('划分词组','你感觉一句话里面的字/词该怎么划分？','')+
    p.lines.map((l,li)=>`<div class="intro-group-row"><h3>${esc(l.text)}</h3><div class="intro-group-options">${INTRO_GROUPS.map((pattern,k)=>{let at=0;const words=pattern.map(n=>{const w=l.text.slice(at,at+n);at+=n;return w;});return `<button data-intro-line="${li}" data-intro-group="${k}" class="${JSON.stringify(pattern)===JSON.stringify(groupingLengths(l))?'active':''}"><strong>${words.map(esc).join(' ｜ ')}</strong><small>${pattern.join(' + ')}</small></button>`;}).join('')}</div></div>`).join('')+
    '';
  $$('[data-intro-group]').forEach(b=>b.onclick=()=>{mutate(()=>{const l=p.lines[+b.dataset.introLine];l.cuts=cutsFor(INTRO_GROUPS[+b.dataset.introGroup]);normalizeIntroLine(l);});render();});nav(false,'选择节拍');
}
function validateIntroRhythm(p){
  if(boundedLesson(p)){for(const l of p.lines){if(!l.dragRhythm&&groups(l).some(g=>!lessonPatterns(g.end-g.start).some(ds=>JSON.stringify(ds)===JSON.stringify(l.durations.slice(g.start,g.end)))))return '词组时长超出本关范围';}return '';}
  if(!isTutorialRhythm(p))return '';
  for(const l of p.lines){if(!INTRO_GROUPS.some(a=>JSON.stringify(a)===JSON.stringify(groupingLengths(l))))return '先选择一种本关的歌词分组';for(const g of groups(l)){if(!l.dragRhythm&&!introChoices(l,g).some(ds=>JSON.stringify(ds)===JSON.stringify(l.durations.slice(g.start,g.end))))return '词组时长不符合本关要求';}}
  return '';
}

function migrateSmallGroups(){
  for(const key of ['one','two','three','four']){const p=db[key];if(!p||p.groupingVersion===1)continue;p.groupingVersion=1;
    for(const l of p.lines){for(const g of groups(l)){for(let i=g.start+2;i<g.end;i+=2)l.cuts[i-1]=true;}}
  }
}

function checkGroups(){const p=project(),max=p.level===0?4:2;if(p.lines.some(l=>groups(l).some(g=>g.end-g.start>max))){toast(`先把词组分成每组 1～${max} 个字，再继续`);return false;}return true;}

function boundedLesson(p=project()){return p.level>0&&p.lessonRhythmVersion===2;}
function lessonPatterns(n){const out=[];function walk(ds,total){if(ds.length===n){out.push(ds);return;}for(const d of [.5,1,1.5,2])if(total+d<=2)walk([...ds,d],total+d);}walk([],0);return out;}
function normalizeLessonLine(l,p){if(l.dragRhythm)return;
  for(const g of groups(l)){const ds=l.durations.slice(g.start,g.end);if(ds.every(d=>d===null))continue;const opts=lessonPatterns(g.end-g.start);if(!opts.length)continue;const best=opts.sort((a,b)=>a.reduce((s,d,i)=>s+Math.abs(d-(ds[i]??.5)),0)-b.reduce((s,d,i)=>s+Math.abs(d-(ds[i]??.5)),0))[0];best.forEach((d,i)=>l.durations[g.start+i]=d);}

}
function migrateLessonRhythm(p){if(p.level===0||p.lessonRhythmVersion===2)return;db.rhythmBackups??={};if(p.lines.some(l=>l.durations.some(d=>d!==null)))db.rhythmBackups[CHAPTER_KEYS[p.level]]=clone(p);p.lessonRhythmVersion=2;p.lines.forEach(l=>normalizeLessonLine(l,p));}
