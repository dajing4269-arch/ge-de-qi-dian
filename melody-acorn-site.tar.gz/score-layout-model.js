/* Saved system boundaries are independent of note, rhythm and engraving data. */
function scoreLayoutMeasureKey(measure){
 const key=typeof measure==='string'?measure:measure?.layoutKey??measure?.key;
 if(typeof key==='string'&&/^(0|[1-9]\d*):(0|[1-9]\d*)$/.test(key))return key;
 return Number.isInteger(measure?.li)&&measure.li>=0&&Number.isInteger(measure?.bar)&&measure.bar>=0?`${measure.li}:${measure.bar}`:null;
}
function validScoreLayout(layout){
 if(layout===undefined||layout===null)return true;
 return typeof layout==='object'&&!Array.isArray(layout)&&layout.version===1&&!!layout.breaks&&typeof layout.breaks==='object'&&!Array.isArray(layout.breaks)&&Object.entries(layout.breaks).every(([key,value])=>scoreLayoutMeasureKey(key)===key&&typeof value==='boolean');
}
function scoreLayoutBreaks(p){
 return validScoreLayout(p?.scoreLayout)&&p?.scoreLayout?.breaks?p.scoreLayout.breaks:{};
}
function scoreLayoutBarsForDevice(p,portrait){
 const value=p?.barsPerRow||0;
 // Legacy automatic layouts may adapt to the device; explicit choices and
 // saved barline boundaries always retain their original base layout.
 if (p?.scoreLayoutExplicit || Object.keys(scoreLayoutBreaks(p)).length || (value && value !== 'auto-phrases')) return value;
 return portrait ? 0 : 'two-phrases';
}
function scoreLayoutForceBreak(row,endMeasure,p){
 const key=scoreLayoutMeasureKey(endMeasure),measures=row?.measures||[],index=measures.findIndex(m=>scoreLayoutMeasureKey(m)===key);
 if(key===null||index<0||index===measures.length-1)return null;
 return {version:1,breaks:{...scoreLayoutBreaks(p),[key]:true}};
}
function scoreLayoutCancelBreak(row,nextMeasure,p){
 const measures=row?.measures||[],end=scoreLayoutMeasureKey(measures.at(-1)),next=scoreLayoutMeasureKey(nextMeasure);
 if(!end||!next||measures.some(m=>scoreLayoutMeasureKey(m)===next))return null;
 // Metadata comes from this exact systemModel call, including its phrase scope.
 // A focused editor must never borrow a measure from a different score view.
 if(Object.prototype.hasOwnProperty.call(row,'layoutNextMeasure')&&scoreLayoutMeasureKey(row.layoutNextMeasure)!==next)return null;
 return {version:1,breaks:{...scoreLayoutBreaks(p),[end]:false,[next]:true}};
}
function scoreLayoutChunks(defaultChunks,p){
 const overrides=scoreLayoutBreaks(p);
 if(!Object.keys(overrides).length)return defaultChunks;
 const ends=new Set(defaultChunks.filter(row=>row.length).map(row=>scoreLayoutMeasureKey(row.at(-1)))),result=[];
 let row=[];
 for(const measure of defaultChunks.flat()){
  row.push(measure);
  const key=scoreLayoutMeasureKey(measure),isEnd=Object.prototype.hasOwnProperty.call(overrides,key)?overrides[key]:ends.has(key);
  if(isEnd){result.push(row);row=[];}
 }
 if(row.length)result.push(row);
 return result;
}
if(typeof module!=='undefined'&&module.exports)module.exports={scoreLayoutMeasureKey,validScoreLayout,scoreLayoutBarsForDevice,scoreLayoutForceBreak,scoreLayoutCancelBreak,scoreLayoutChunks};
