/* Top step controls delegate to the current page, including sentence/section phases. */
function lessonStepTargets(){
 const first=ids=>ids.map(id=>document.getElementById(id)).find(Boolean);
 return {previous:first(['sentenceBack','creditBack','prev','taskBack','editAgain','previousStep']),next:first(['sentenceNext','creditNext','next','taskNext'])};
}
// Older pages validate only on click. Give those same checks a disabled state.
// null means the page already owns its button's gate.
function lessonStepBlocked(p=project()){
 if(p.level<=10&&inSentence(p)){
  const li=sentenceIndex(p),line=p.lines[li],phase=p.sentenceStages[li]??0;
  if(phase===0)return groups(line).some(g=>g.end-g.start>2);
  if(phase===1)return line.durations.some(d=>d===null);
  return (li===p.lines.length-1?p.lines.map((_,i)=>i):[li]).some(i=>!!sentenceError(i));
 }
 if(sentenceLesson(p)&&p.level===2){
  if(p.step===1)return !pitchTaskDone();
  if(p.step===2)return !!validate(p);
 }
 if(sentenceLesson(p)&&p.step===3+p.lines.length){
  if(p.level===3)return !!validate(p);
  if(p.level===4)return !staccatoDone(p)||!!validate(p);
  if(p.level>=5&&p.level<=10)return !!validate(p);
 }
 if(!advancedLesson(p))return null;
 const step=advancedStep(p);
 if(step?.kind==='sections'){
  const draft=$('#lessonLyrics');
  if(draft)return !!editedLessonLyrics(draft.value,p).error;
  const sections=$('#sectionLyrics');
  if(sections)return !applySectionText(sections.value,clone(p));
 }
 if(step?.kind==='section-compose'){
  const state=sectionComposeState(p);
  if(state.stage===state.ranges.length*2-1)return state.ranges.some((_,i)=>!!sectionComposeIssue(i*2+1,p));
  return !!sectionComposeIssue(state.stage,p);
 }
 if(['review','repeat','sequence','split','pickup','accidentals','pair'].includes(step?.kind)){
  if(step.kind==='pair'&&step.lines.some(li=>sequencePending(li,p)))return true;
  if(step.kind==='repeat'&&paragraphCopyPending(p))return true;
  if(step.kind==='sequence'&&!p.sequenceDone)return true;
  if(splitReview(p)&&!p.lines.some(l=>Object.values(l.melody||{}).some(parts=>parts.length>1)))return true;
  if(step.kind==='pickup'&&(!pickupActive(p)||!p.pickupDone))return true;
  if(step.kind==='accidentals')return !accidentalPracticeDone(p)||!!validate(p);
  return (step.lines||p.lines.map((_,li)=>li)).some(li=>!!sentenceError(li));
 }
 return null;
}
function syncLessonStepNavigation(){
 const steps=$('#app .compact-steps'),p=project();
 if(db.view!=='editor'||!p?.level||!steps)return;
 let bar=$('#lessonStepbar');
 if(!bar){
  bar=document.createElement('div');bar.id='lessonStepbar';bar.className='lesson-stepbar';steps.before(bar);bar.append(steps);
  const controls=document.createElement('div');controls.className='lesson-step-navigation';controls.setAttribute('role','group');controls.setAttribute('aria-label','步骤导航');
  controls.innerHTML='<button id="topPreviousStep" type="button">← 上一步</button><button id="topNextStep" type="button" class="primary">下一步 →</button>';bar.append(controls);
  $('#topPreviousStep').onclick=()=>{const source=lessonStepTargets().previous;if(source&&!source.disabled)source.click();};
  $('#topNextStep').onclick=()=>{syncLessonStepNavigation();const source=lessonStepTargets().next;if(source&&!source.disabled)source.click();};
 }
 // Keep its original handler as the fallback for a page's first inner phase.
 if($('#previousStep'))$('#previousStep').hidden=true;
 const targets=lessonStepTargets(),blocked=lessonStepBlocked(p);
 if(targets.next&&blocked!==null&&targets.next.disabled!==blocked)targets.next.disabled=blocked;
 for(const [direction,id] of [['previous','topPreviousStep'],['next','topNextStep']]){
  const button=$('#'+id),source=targets[direction],back=direction==='previous';
  const name=source?.textContent.trim().replace(/^[←\s]+/,'').replace(/^(?:上一步|下一步|继续)\s*[:：]\s*/,'').replace(/\s*→$/,'');
  const label=back?'← 上一步'+(name?'：'+name:''):'下一步'+(name?'：'+name:'')+' →';
  if(button.textContent!==label)button.textContent=label;
  if(button.title!==label)button.title=label;
  const disabled=!source||source.disabled;if(button.disabled!==disabled)button.disabled=disabled;
 }
}
function installLessonStepNavigation(){
 const oldRender=render,oldRefresh=refreshScore;
 render=function(){oldRender();syncLessonStepNavigation();};
 refreshScore=function(){oldRefresh();syncLessonStepNavigation();};
 // Quiz answers, credit fields and inline edits can update without a full render.
 const app=$('#app');
 const observer=new MutationObserver(records=>{
  if(records.some(r=>!r.target.closest?.('.lesson-step-navigation')))syncLessonStepNavigation();
 });
 observer.observe(app,{subtree:true,childList:true,attributes:true,attributeFilter:['disabled']});
 app.addEventListener('input',syncLessonStepNavigation);
 app.addEventListener('change',syncLessonStepNavigation);
}
