/* Checking is optional. Red marks describe current omissions, never reference notes. */
const scoreCheckRequests=new WeakMap();
function scoreCheckStage(p=project()){
 return [p.step,p.sectionComposeStage??'',p.level<=10&&inSentence(p)?p.sentenceStages?.[sentenceIndex(p)]??'':''].join(':');
}
function scoreCheckScope(p=project()){
 if(sectionComposeLesson(p)&&advancedStep(p)?.kind==='section-compose'){
  const state=sectionComposeState(p);return state.phase==='compose'?state.lines:[];
 }
 if(p.level<=10&&inSentence(p)){const li=sentenceIndex(p);return p.sentenceStages?.[li]===2?[li]:[];}
 if(advancedLesson(p)){const step=advancedStep(p);if(['pair','repeat'].includes(step?.kind))return step.lines.filter(li=>step.kind==='repeat'||p.sentenceStages?.[li]===2);}
 return p.lines.map((_,li)=>li);
}
function scoreCheckActive(p=project()){return scoreCheckRequests.get(p)===scoreCheckStage(p);}
function scoreCheckFindings(p=project()){
 const marks=[],messages=[],scope=scoreCheckScope(p);
 const add=(li,i,si,zone,reason)=>{if(!marks.some(m=>m.li===li&&m.i===i&&m.si===si&&m.zone===zone))marks.push({li,i,si,zone,reason});};
 const message=text=>{if(text&&!messages.includes(text))messages.push(text);};
 for(const li of scope){
  const l=p.lines[li];if(!l)continue;
  const groupLimit=p.level?2:4;
  for(const group of groups(l))if(group.end-group.start>groupLimit){for(let i=group.start;i<group.end;i++)add(li,i,0,'lyric','请重新划分词组');message(`第 ${li+1} 句：请重新划分词组`);}
  l.durations.forEach((d,i)=>{if(d===null||d===undefined){add(li,i,0,'rhythm','缺少时长');message(`第 ${li+1} 句：有歌词缺少时长`);}});
  l.pitches.forEach((pitch,i)=>{
   const parts=l.melody?.[i]||[{p:pitch}];parts.forEach((n,si)=>{
    if(n.rest)return;
    if(n.p===null||n.p===undefined){add(li,i,si,'pitch','尚未选择音高');message(`第 ${li+1} 句：还有音符没选音高`);}
    else if(p.level>0&&curriculum(p)&&!modeAllowed(n.p,p)){add(li,i,si,'pitch','请使用当前调式的音');message(`第 ${li+1} 句：请使用当前调式的音`);}
   });
  });
  const cadence=endingIssue(p,li);
  if(p.level>0&&cadence){
   message(`第 ${li+1} 句：${cadence}`);
   if(p.level===16){const c=dorianCadences(p).find(c=>c.li===li);for(const n of c?.notes||[])if(scope.includes(n.li))add(n.li,n.i,n.si,'pitch',cadence);}
   else {const i=l.pitches.length-1,parts=l.melody?.[i],si=parts?parts.findLastIndex(n=>!n.rest):0;if(i>=0&&si>=0)add(li,i,si,'pitch',cadence);}
  }
  if(p.level>0){const issue=withSectionComposeProject(p,()=>sentenceError(li));if(issue)message(`第 ${li+1} 句：${issue}`);}
 }
 if(sectionComposeLesson(p)&&advancedStep(p)?.kind==='section-compose'){const issue=sectionComposeIssue(sectionComposeState(p).stage,p);if(issue)message(issue);}
 // New-operation requirements stay explicit, without circling unrelated notes.
 if(p.level===3&&p.step===3+p.lines.length)message(validate(p));
 const step=advancedLesson(p)?advancedStep(p):null;
 if(p.level===4&&p.step===3+p.lines.length&&!staccatoDone(p)){
  for(let i=0;i<4;i++)if(!p.lines[1].staccato?.[i])add(1,i,0,'pitch','请添加跳音');message('给「滴滴答答」四个音符加入跳音点');
 }
 if(splitReview(p)&&!p.lines.some(l=>Object.values(l.melody||{}).some(a=>a.length>1)))message('点击上方歌词节奏音符，试着把一个字拆成多个音');
 if(p.level===22&&step?.kind==='rests'&&!hasWrittenRest(p)){
  const target=restLessonTarget(p);if(target)add(target.li,target.i,target.si??0,'rhythm','请在这个字后加入休止');message('右键歌词节奏区域的大音符，在字后加入休止');
 }
 if(p.level===23&&step?.kind==='pickup'&&(!pickupActive(p)||!p.pickupDone))message('拖动小节线，完成这次弱起练习');
 if(p.level===25&&step?.kind==='accidentals'&&!accidentalPracticeDone(p))message('在作品中选两个音加入升号或降号');
 if(p.level===27&&step?.kind==='natural'&&!harmonicPair(p,true)){
  const pair=harmonicPair(p);if(pair){const n=pair.second;add(n.li,n.i,n.si??0,'pitch','请还原第二个 G');}message('在同一小节保留第一个升 G，把第二个 G 加上还原号');
 }
 if(p.level===27&&step?.kind==='section-compose'&&scope.includes(p.lines.length-1)&&!harmonicPair(p)&&!harmonicPair(p,true))message('在同一小节安排两个同一位置的 G 音');
 if(step?.kind==='repeat'&&paragraphCopyPending(p))message('先完成框出的整段复制操作');
 if(p.level===11&&step?.kind==='pair')for(const li of step.lines)if(sequencePending(li,p))message(`第 ${li+1} 句：先复制前一句，再用箭头平移旋律`);
 return {marks,messages};
}
function stripPersistentNoteChecks(svg){
 return svg.replace(/<(?:rect|ellipse)\b[^>]*class="[^"]*\b(?:cadence-target|scale-cadence-target|copy-repair-note|copy-repair-lyric|review-cadence-target)\b[^"]*"[^>]*\/>/g,'');
}
function scoreCheckOverlay(row,p=project()){
 if(!scoreCheckActive(p))return '';
 const {marks}=scoreCheckFindings(p);let svg='';
 for(const mark of marks){
  const n=row.measures.flatMap(m=>m.notes).find(n=>!n.rest&&n.first&&n.li===mark.li&&n.i===mark.i&&(mark.zone!=='pitch'||(n.si??0)===mark.si));
  if(!n)continue;
  const attrs=`class="score-check-mark" data-check-li="${mark.li}" data-check-i="${mark.i}" data-check-si="${mark.si}" data-check-zone="${mark.zone}" pointer-events="none"`;
  if(mark.zone==='pitch')svg+=`<g ${attrs}><title>${esc(mark.reason)}</title><ellipse cx="${n.x}" cy="${noteY(n.p??28)}" rx="21" ry="17" fill="none" stroke="#bc4141" stroke-width="2"/></g>`;
  else {const y=mark.zone==='rhythm'?5:239,height=mark.zone==='rhythm'?75:39;svg+=`<g ${attrs}><title>${esc(mark.reason)}</title><rect x="${n.x-23}" y="${y}" width="46" height="${height}" rx="10" fill="none" stroke="#bc4141" stroke-width="2"/></g>`;}
 }
 return svg;
}
function bindScoreCheck(){
 const area=$('#scoreArea'),next=$('#next')||$('#sentenceNext');
 if(area&&project().level>=3&&project().level<=7&&area.querySelector('[data-regroup-line]')&&!area.querySelector('.regroup-tip')){
  const tip=document.createElement('p');
  tip.className='hint regroup-tip';
  tip.textContent='想换一种分词方式？可以点「调整歌词划分」，也可以保留现在的划分。';
  area.querySelector('[data-regroup-line]').after(tip);
 }
 const editable=area&&area.dataset.readonly!=='true'&&area.dataset.complete!=='true'&&area.querySelector('svg .note');
 if(db.view!=='editor'||!next||!editable||!scoreCheckScope().length){$('#checkScore')?.remove();$('#scoreCheckResult')?.remove();return;}
 let button=$('#checkScore');
 if(!button){button=document.createElement('button');button.id='checkScore';button.type='button';button.textContent='检查乐谱';next.before(button);}
 button.onclick=()=>{scoreCheckRequests.set(project(),scoreCheckStage());refreshScore();};
 let status=$('#scoreCheckResult');
 if(!status){status=document.createElement('p');status.id='scoreCheckResult';status.className='hint score-check-result';status.setAttribute('role','status');status.setAttribute('aria-live','polite');next.parentElement.before(status);}
 status.hidden=!scoreCheckActive();
 if(!status.hidden){const result=scoreCheckFindings();status.textContent=result.messages.length?result.messages.slice(0,4).join('；')+(result.messages.length>4?'；其余遗漏也已在谱面标出。':''):'当前乐谱没有发现遗漏，可以继续。';status.style.color=result.messages.length?'#a67c19':'#48734c';}
}
function installScoreCheck(){
 const oldSVG=engravingSVG,oldRender=render,oldRefresh=refreshScore;
 engravingSVG=function(row,mode='combined',editable=true){let svg=oldSVG(row,mode,editable);if(editable&&mode==='combined'){svg=stripPersistentNoteChecks(svg);svg=svg.replace('</g></svg>',scoreCheckOverlay(row)+'</g></svg>');}return svg;};
 render=function(){oldRender();bindScoreCheck();};
 refreshScore=function(){oldRefresh();bindScoreCheck();};
}
