/* A single composition workspace, progressing through user-defined sections. */
const sectionComposeExpanded=new Map();
function sectionComposePhaseName(phase){return phase==='groups'?'划分歌词节奏':'创作旋律';}
function sectionComposeStageName(stage){return `第 ${Math.floor(stage/2)+1} 段·${sectionComposePhaseName(stage%2?'compose':'groups')}`;}
function sectionComposeProgressHTML(state){
 return `<div class="section-compose-progress" aria-label="分段创作进度">${state.ranges.map((_,section)=>`<div class="section-compose-progress-item"><span>第 ${section+1} 段</span>${['groups','compose'].map((phase,i)=>{const stage=section*2+i;return `${i?'<span class="section-compose-progress-arrow" aria-hidden="true">›</span>':''}<button data-section-compose-stage="${stage}" class="${stage===state.stage?'current':stage<state.maxStage?'done':''}" ${stage>state.maxStage?'disabled':''} ${stage===state.stage?'aria-current="step"':''}>${sectionComposePhaseName(phase)}</button>`;}).join('')}</div>`).join('')}</div>`;
}
function sectionComposeGroupsHTML(state,p=project()){
 return `<div class="section-compose-group-grid">${state.lines.map(li=>{const l=p.lines[li],letters=lyricUnits(l.text);return `<div class="section-compose-group-row ${letters.length>=8||/[A-Za-z]/.test(l.text)?'long-phrase':''}" data-section-compose-line="${li}"><span class="section-compose-line-number">第 ${li+1} 句</span><div class="groups-line">${letters.map((c,i)=>`<span class="character ${/[A-Za-z]/.test(c)?'english-syllable':''}">${esc(c)}</span>${i<letters.length-1?`<button class="divider ${l.cuts[i]?'on':''}" data-section-compose-cut="${li}:${i}" aria-pressed="${!!l.cuts[i]}" aria-label="${esc(c)}后${l.cuts[i]?'合并':'分组'}">│</button>`:''}`).join('')}</div></div>`;}).join('')}</div>`;
}
function sectionComposeScoreHTML(){
 const p=project(),state=sectionComposeState(p);
 const current=state.phase==='groups'?sectionComposeGroupsHTML(state,p):`<div class="section-compose-current-score" data-section-compose-score="${state.section}">${systemModel(p,state.lines).map(row=>scoreRowHTML(row,true)).join('')}</div>`;
 const previous=state.ranges.slice(0,state.section).map((lines,section)=>`<details class="section-compose-previous previous-phrases" data-section-compose-previous="${section}" ${sectionComposeExpanded.get(`${db.active}:${section}`)?'open':''}><summary>查看第 ${section+1} 段旋律</summary>${systemModel(p,lines).map(row=>scoreRowHTML(row,true)).join('')}</details>`).join('');
 return current+previous;
}
function sectionComposePrevious(){
 const state=sectionComposeState();
 if(state.stage>0)return moveSectionCompose(state.stage-1);
 stop();selected=null;mutate(()=>project().step=Math.max(0,project().step-1));render();
}
function playSectionCompose(){
 const p=project(),state=sectionComposeState(p),indices=new Set(state.lines);
 const offset=p.lines.slice(0,state.lines[0]).reduce((sum,line)=>sum+lineBeats(line,p),0);
 const end=state.lines.reduce((sum,li)=>sum+lineBeats(p.lines[li],p),0);
 const events=getEvents().filter(event=>indices.has(event.li)).map(event=>({...event,t:event.t-offset}));
 events.push({t:end,d:0,p:null,rest:true,assigned:false});return playEvents(events,false,p.bpm);
}
function sectionComposeEditingControls(){
 return editingControls().replace('<button id="stop">■</button>','<button id="stop">■</button><button id="playSectionCompose">▶ 播放本段</button>');
}
function sectionComposeNext(){
 const state=sectionComposeState(),issue=sectionComposeIssue(state.stage,project());
 if(issue){toast(issue);syncSectionComposeGate();return;}
 return state.stage+1<state.ranges.length*2?moveSectionCompose(state.stage+1):finishSectionCompose();
}
function sectionComposeNavigationHTML(state,p=project()){
 const previous=state.stage?sectionComposeStageName(state.stage-1):(advancedSteps(p)[p.step-1]?.name||'选择调式');
 const next=state.stage+1<state.ranges.length*2?sectionComposeStageName(state.stage+1):(advancedSteps(p)[p.step+1]?.name||'自由修改');
 return `<p id="sectionComposeIssue" class="section-compose-issue hint" role="status" aria-live="polite"></p><div class="actions section-compose-actions"><button id="prev">← 上一步：${esc(previous)}</button><button class="primary" id="next">下一步：${esc(next)} →</button></div>`;
}
function bindSectionComposeGroups(){
 $$('[data-section-compose-cut]').forEach(button=>{
  let startX=null,dragged=false;
  const applyCut=(target=null)=>{
   const [li,index]=button.dataset.sectionComposeCut.split(':').map(Number),line=project().lines[li];
   mutate(()=>{const cuts=[...line.cuts];if(target===null)cuts[index]=!cuts[index];else{cuts[index]=false;cuts[target]=true;}line.cuts=cuts;});render();
  };
  button.onpointerdown=e=>{if(e.button!==undefined&&e.button!==0)return;startX=e.clientX;dragged=false;button.setPointerCapture?.(e.pointerId);};
  button.onpointerup=e=>{
   if(startX===null)return;const distance=e.clientX-startX;startX=null;
   if(Math.abs(distance)<=10)return;
   dragged=true;e.preventDefault();
   const [li]=button.dataset.sectionComposeCut.split(':').map(Number);
   const boundaries=[...$$(`[data-section-compose-line="${li}"] [data-section-compose-cut]`)];
   let closest=button,best=Infinity;
   for(const boundary of boundaries){const box=boundary.getBoundingClientRect(),distance=Math.abs(e.clientX-(box.left+box.width/2));if(distance<best){closest=boundary;best=distance;}}
   applyCut(+closest.dataset.sectionComposeCut.split(':')[1]);
  };
  button.onpointercancel=()=>{startX=null;dragged=false;};
  button.onclick=e=>{if(dragged){dragged=false;e.preventDefault();return;}applyCut();};
 });
}
function syncSectionComposeGate(){
 const p=project();if(!sectionComposeLesson(p)||advancedStep(p)?.kind!=='section-compose')return;
 const state=sectionComposeState(p),issue=sectionComposeIssue(state.stage,p),next=$('#next'),status=$('#sectionComposeIssue');
 if(next)next.disabled=!!issue;
 if(status){status.textContent=issue;status.hidden=!issue;}
 $$('[data-section-compose-stage]').forEach(button=>{const target=+button.dataset.sectionComposeStage;button.disabled=target>state.maxStage;button.onclick=()=>{if(target<=sectionComposeState().maxStage)moveSectionCompose(target);};});
 if($('#prev'))$('#prev').onclick=sectionComposePrevious;
 if(next)next.onclick=sectionComposeNext;
 if($('#playSectionCompose'))$('#playSectionCompose').onclick=playSectionCompose;
 bindSectionComposeGroups();
 $$('[data-section-compose-previous]').forEach(detail=>{detail.ontoggle=()=>{sectionComposeExpanded.set(`${db.active}:${detail.dataset.sectionComposePrevious}`,detail.open);if(detail.open&&typeof bindScoreFit==='function')bindScoreFit();};});
}
function renderSectionCompose(){
 const p=project(),state=sectionComposeState(p),phase=sectionComposePhaseName(state.phase);
 if(state.phase==='compose')for(const li of state.lines){const l=p.lines[li];l.durations=l.durations.map(d=>d??1);l.dragRhythm=true;}
 const hint=state.phase==='groups'?'点击或左右拖动分隔线，先分成每组 1～2 个字。':'在五线谱上为这一段写旋律。';
 $('#stage').innerHTML=`<div class="section-compose">${heading('','旋律创作',cadenceStepReminder('旋律创作'))}${sectionComposeProgressHTML(state)}<div class="section-compose-phase"><h3>第 ${state.section+1} 段 · ${phase}</h3><p class="hint">${hint}</p></div>${state.phase==='compose'?sectionComposeEditingControls():''}<div id="scoreArea">${sectionComposeScoreHTML()}</div>${sectionComposeNavigationHTML(state,p)}</div>`;
 bindPlayback();syncSectionComposeGate();
}
