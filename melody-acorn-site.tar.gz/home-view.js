// The language preference applies to the landing page. Scores and lesson text keep their language.
const homeLanguages = ['zh-CN', 'zh-TW', 'en'];
const homeLabels = {
  saved: ['✓ 已保存到此设备', '✓ 已儲存於此裝置', '✓ Saved on this device'],
  failed: ['保存失败 · 请下载工程备份', '儲存失敗 · 請下載工程備份', 'Save failed · Back up your project'],
  guide: ['操作指南', '操作指南', 'Guide'],
  import: ['打开乐谱或工程', '開啟樂譜或工程', 'Open score or project'],
  contact: ['联系我', '聯絡我', 'Contact'],
  title: ['歌的起点，', '歌的起點，', 'Your song'],
  titleEnd: ['从这里开始', '從這裡開始', 'starts here'],
  intro: ['用听觉赋予旋律，', '用聽覺賦予旋律，', 'Find a melody by ear. '],
  introEnd: ['让语言的魅力不止于文字。', '讓語言的魅力不止於文字。', 'Let your words sing.'],
  levels: ['共 30 关 · 可自由选关', '共 30 關 · 可自由選關', '30 levels · Play in any order'],
  challenge: ['闯关模式', '闖關模式', 'Challenges'],
  challengeText: ['从《春晓》开始，给诗句写一段旋律。', '從《春曉》開始，給詩句寫一段旋律。', 'Set a line of Spring Dawn to music.'],
  start: ['开始闯关 →', '開始闖關 →', 'Start →'],
  resume: ['继续闯关 →', '繼續闖關 →', 'Continue →'],
  finished: ['查看我的作品 →', '查看我的作品 →', 'View my work →'],
  choose: ['自由选关', '自由選關', 'Pick a level'],
  restart: ['重新闯关', '重新闖關', 'Restart'],
  restore: ['恢复上次进度', '恢復上次進度', 'Restore progress'],
  lyrics: ['从自己的歌词出发', '從自己的歌詞出發', 'Start with your lyrics'],
  compose: ['自由创作', '自由創作', 'Compose'],
  composeText: ['写一句新的，或接着写上次的歌。', '寫一句新的，或接著寫上次的歌。', 'Start a lyric or return to a song.'],
  newSong: ['新的歌曲 →', '新的歌曲 →', 'New song →'],
  past: ['旧的印迹', '舊的印跡', 'Past songs'],
  backup: ['进度自动保存在此设备。清理浏览器数据前，记得备份工程。', '進度自動儲存於此裝置。清除瀏覽器資料前，記得備份工程。', 'Progress is saved on this device. Back up projects before clearing browser data.'],
  about: ['关于与使用说明', '關於與使用說明', 'About']
};
let homeLanguage = 'zh-CN';
try {
  const savedLanguage = localStorage.getItem('song-origin.language');
  if (homeLanguages.includes(savedLanguage)) homeLanguage = savedLanguage;
} catch {}

function rhythmPreferenceControl(p, language = 'zh-CN') {
  const words = language === 'en' ? ['Rhythm', 'Regular', 'Free'] :
    language === 'zh-TW' ? ['節奏偏好', '工整', '自由'] : ['节奏偏好', '工整', '自由'];
  const value = getRhythmPreference(p);
  return `<span class="rhythm-pref" role="group" aria-label="${words[0]}">
    <span>${words[0]}</span>
    <button type="button" data-rhythm-pref="regular" aria-pressed="${value === 'regular'}">${words[1]}</button>
    <span aria-hidden="true">/</span>
    <button type="button" data-rhythm-pref="free" aria-pressed="${value === 'free'}">${words[2]}</button>
  </span>`;
}

function preferenceProject() {
  if (db.view === 'editor') return project();
  if (db.view === 'lesson-cover') return db[CHAPTER_KEYS[db.coverLevel]];
}

function refreshHeaderPreference(onHome) {
  const slot = document.querySelector(onHome ? '.home-nav .header-rhythm-preference' : '.header-help .header-rhythm-preference');
  slot.innerHTML = rhythmPreferenceControl(preferenceProject(), onHome ? homeLanguage : 'zh-CN');
}

document.addEventListener('click', event => {
  const button = event.target.closest('button[data-rhythm-pref]');
  if (!button || button.getAttribute('aria-pressed') === 'true') return;
  const p = preferenceProject(), value = button.dataset.rhythmPref;
  if (p && value === 'regular') {
    const error = regularTimingError(p);
    if (error) { toast(error); return; }
  }
  if (p && p === project()) {
    stop();
    mutate(() => setRhythmPreference(value, p));
  } else {
    if (!setRhythmPreference(value, p)) return;
    if (p) save();
  }
  render();
});

function updateHomeLabels() {
  refreshHeaderPreference(true);
  const index = homeLanguages.indexOf(homeLanguage);
  document.documentElement.lang = homeLanguage;
  for (const element of document.querySelectorAll('[data-home-label]')) {
    const label = element.dataset.homeLabel;
    element.textContent = homeLabels[label === 'saved' && !saveOK ? 'failed' : label][index];
  }
  for (const button of document.querySelectorAll('[data-lang]')) {
    button.setAttribute('aria-pressed', String(button.dataset.lang === homeLanguage));
  }
}

function setHomePage(active) {
  document.body.classList.toggle('home-page', active);
  if (!active) {
    document.documentElement.lang = 'zh-CN';
    refreshHeaderPreference(false);
  }
}

function renderHome() {
  const current = currentChapter();
  const done = CHAPTER_KEYS.slice(1).every(key => db[key]?.complete);
  const freshStart = current === 1 && db.one.step === 0 && !db.one.coverSeenLevel;
  const action = done ? 'finished' : freshStart ? 'start' : 'resume';
  $('#app').innerHTML = `
    <div class="hero">
      <h1><span data-home-label="title"></span><br><span data-home-label="titleEnd"></span></h1>
      <p><span data-home-label="intro"></span><span class="intro-tail" data-home-label="introEnd"></span></p>
    </div>
    <div class="modes">
      <section class="mode">
        <small data-home-label="levels"></small><h2 data-home-label="challenge"></h2>
        <p data-home-label="challengeText"></p>
        <button id="continue" class="primary" data-home-label="${action}"></button>
        <button id="chooseChapter" class="minor" data-home-label="choose"></button>
        <button id="restartJourney" class="minor" data-home-label="restart"></button>
        ${db.journeyBackup ? '<button id="restoreJourney" class="minor" data-home-label="restore"></button>' : ''}
      </section>
      <section class="mode">
        <small data-home-label="lyrics"></small><h2 data-home-label="compose"></h2>
        <p data-home-label="composeText"></p>
        <button id="homeNew" class="primary" data-home-label="newSong"></button>
        <button id="homeStudio" class="minor" data-home-label="past"></button>
      </section>
    </div>`;
  $('#continue').onclick = () => startChapter(current);
  $('#chooseChapter').onclick = () => chooseChapter();
  $('#restartJourney').onclick = restartJourney;
  if ($('#restoreJourney')) $('#restoreJourney').onclick = restoreJourney;
  $('#homeNew').onclick = newSong;
  $('#homeStudio').onclick = studioHome;
  updateHomeLabels();
}

document.querySelector('.brand-signature').onclick = event => {
  event.preventDefault();
  home();
};
for (const button of document.querySelectorAll('[data-home-control]')) {
  button.onclick = () => document.getElementById(button.dataset.homeControl).click();
}
for (const button of document.querySelectorAll('[data-lang]')) {
  button.onclick = () => {
    homeLanguage = button.dataset.lang;
    try { localStorage.setItem('song-origin.language', homeLanguage); } catch {}
    updateHomeLabels();
  };
}
const homeFooter = document.querySelector('.home-footer');
new ResizeObserver(() => {
  if (document.body.classList.contains('home-page')) {
    document.body.style.setProperty('--footer-space', homeFooter.offsetHeight + 'px');
  }
}).observe(homeFooter);
